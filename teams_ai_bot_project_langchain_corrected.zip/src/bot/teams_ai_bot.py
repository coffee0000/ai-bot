from __future__ import annotations

import logging

from botbuilder.core import ActivityHandler, TurnContext
from botbuilder.schema import ChannelAccount

from src.usecases.chat_usecase import ChatUsecase

logger = logging.getLogger(__name__)

EMPTY_INPUT_MESSAGE = "入力内容が空です。正しい内容を入力してください。"

class TeamsAIBot(ActivityHandler):
    def __init__(self, chat_usecase: ChatUsecase, max_text_length: int) -> None:
        self._chat = chat_usecase
        self._max_len = max_text_length

    async def on_message_activity(self, turn_context: TurnContext) -> None:
        user: ChannelAccount | None = turn_context.activity.from_property
        conversation = turn_context.activity.conversation

        user_id = user.id if user else ""
        conversation_id = conversation.id if conversation else ""

        text = (turn_context.activity.text or "").strip()

        if text == "":
            await turn_context.send_activity(EMPTY_INPUT_MESSAGE)
            return

        if len(text) > self._max_len:
            await turn_context.send_activity(f"最大文字数：{self._max_len} 以内で入力してください。")
            return

        result = await self._chat.handle(user_id=user_id, conversation_id=conversation_id, user_text=text)
        await turn_context.send_activity(result.message)
