from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from src.common.utils import new_uuid, now_utc_iso
from src.infra.cosmos_service import CosmosService

SCHEMA_NAME_AI_PROCESSING_STATUS = "ai_processing_status"

@dataclass(frozen=True)
class ProcessingStatus:
    id: str
    conversation_id: str
    processing_flg: str
    locked_at: str
    create_at: str

class StatusRepository:
    def __init__(self, cosmos: CosmosService) -> None:
        self._cosmos = cosmos

    async def get_by_conversation_id(self, conversation_id: str) -> ProcessingStatus | None:
        q = """
        SELECT TOP 1 c.id, c.conversation_id, c.processing_flg, c.locked_at, c.create_at
        FROM c
        WHERE c.schema_name = @schema_name AND c.conversation_id = @conversation_id
        ORDER BY c.create_at DESC
        """
        params = [
            {"name": "@schema_name", "value": SCHEMA_NAME_AI_PROCESSING_STATUS},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = await self._cosmos.query_items(self._cosmos.business, q, params)
        if not items:
            return None
        it = items[0]
        return ProcessingStatus(
            id=it["id"],
            conversation_id=it["conversation_id"],
            processing_flg=it.get("processing_flg", "0"),
            locked_at=it.get("locked_at", ""),
            create_at=it.get("create_at", ""),
        )

    async def create_if_missing(self, conversation_id: str) -> ProcessingStatus:
        doc: dict[str, Any] = {
            "id": new_uuid(),
            "schema_name": SCHEMA_NAME_AI_PROCESSING_STATUS,
            "conversation_id": conversation_id,
            "processing_flg": "0",
            "locked_at": now_utc_iso(),
            "create_at": now_utc_iso(),
        }
        await self._cosmos.create_item(self._cosmos.business, doc)
        return ProcessingStatus(
            id=doc["id"],
            conversation_id=conversation_id,
            processing_flg="0",
            locked_at=doc["locked_at"],
            create_at=doc["create_at"],
        )

    async def update_processing_flg(self, status: ProcessingStatus, processing_flg: str) -> None:
        # locked_at は更新時点に更新する
        doc: dict[str, Any] = {
            "id": status.id,
            "schema_name": SCHEMA_NAME_AI_PROCESSING_STATUS,
            "conversation_id": status.conversation_id,
            "processing_flg": processing_flg,
            "locked_at": now_utc_iso(),
            "create_at": status.create_at or now_utc_iso(),
        }
        await self._cosmos.upsert_item(self._cosmos.business, doc)
