from __future__ import annotations

from azure.identity import DefaultAzureCredential, ClientSecretCredential

from src.config.settings import Settings

def build_credential(settings: Settings):
    # DEV_FLG=true の場合のみ ClientSecretCredential を利用する（ローカル開発向け）
    if settings.DEV_FLG:
        return ClientSecretCredential(
            tenant_id=settings.AZURE_AUTH_TENANT_ID,
            client_id=settings.AZURE_AUTH_CLIENT_ID,
            client_secret=settings.AZURE_AUTH_CLIENT_SECRET,
        )
    return DefaultAzureCredential()
