from __future__ import annotations

from typing import Any

from azure.cosmos.aio import CosmosClient
from azure.cosmos import exceptions

from src.common.errors import DbError
from src.config.settings import Settings

class CosmosService:
    def __init__(self, settings: Settings, credential) -> None:
        self._endpoint = settings.AZURE_COSMOSDB_ENDPOINT
        self._db_name = settings.AZURE_COSMOSDB_DATABASE_NAME
        self._business_container_name = settings.AZURE_COSMOSDB_CONTAINER_BUSINESS
        self._archive_container_name = settings.AZURE_COSMOSDB_CONTAINER_ARCHIVE
        self._credential = credential
        self._client: CosmosClient | None = None
        self._db = None
        self._business = None
        self._archive = None

    async def open(self) -> None:
        try:
            self._client = CosmosClient(self._endpoint, credential=self._credential)
            self._db = self._client.get_database_client(self._db_name)
            self._business = self._db.get_container_client(self._business_container_name)
            self._archive = self._db.get_container_client(self._archive_container_name)
            # コンテナ情報のreadで接続チェック
            await self._business.read()
            await self._archive.read()
        except Exception as ex:
            raise DbError(str(ex)) from ex

    async def close(self) -> None:
        if self._client is not None:
            await self._client.close()

    @property
    def business(self):
        if self._business is None:
            raise DbError("Cosmos not initialized (business)")
        return self._business

    @property
    def archive(self):
        if self._archive is None:
            raise DbError("Cosmos not initialized (archive)")
        return self._archive

    async def query_items(self, container, query: str, parameters: list[dict[str, Any]]):
        try:
            it = container.query_items(
                query=query,
                parameters=parameters,
                enable_cross_partition_query=True,
            )
            items = []
            async for item in it:
                items.append(item)
            return items
        except exceptions.CosmosHttpResponseError as ex:
            raise DbError(str(ex)) from ex

    async def create_item(self, container, body: dict[str, Any]) -> None:
        try:
            await container.create_item(body=body)
        except exceptions.CosmosHttpResponseError as ex:
            raise DbError(str(ex)) from ex

    async def upsert_item(self, container, body: dict[str, Any]) -> None:
        try:
            await container.upsert_item(body=body)
        except exceptions.CosmosHttpResponseError as ex:
            raise DbError(str(ex)) from ex

    async def delete_item(self, container, item_id: str, partition_key: Any | None = None) -> None:
        try:
            if partition_key is None:
                # partition_key を指定できない場合は、読み取りで取得してから削除する
                doc = await container.read_item(item=item_id, partition_key=item_id)
                await container.delete_item(item=item_id, partition_key=doc.get("conversation_id", item_id))
            else:
                await container.delete_item(item=item_id, partition_key=partition_key)
        except exceptions.CosmosHttpResponseError as ex:
            raise DbError(str(ex)) from ex
