from __future__ import annotations

import logging

from aiohttp import web
from botbuilder.integration.aiohttp import (
    CloudAdapter,
    ConfigurationBotFrameworkAuthentication,
    aiohttp_error_middleware,
)

from src.common.logging import setup_logging
from src.config.settings import Settings
from src.infra.identity import build_credential
from src.infra.cosmos_service import CosmosService
from src.infra.openai_service import AzureOpenAIService
from src.repositories.conversation_repository import ConversationRepository
from src.repositories.status_repository import StatusRepository
from src.repositories.audit_repository import AuditRepository
from src.usecases.chat_usecase import ChatUsecase
from src.bot.teams_ai_bot import TeamsAIBot

logger = logging.getLogger(__name__)

async def _on_error(context, error: Exception) -> None:
    logger.exception("Unhandled error: %s", error)
    await context.send_activity("システムで例外が発生しました。しばらくしてから再試行してください。")

def create_app(settings: Settings) -> web.Application:
    setup_logging(settings.LOG_LEVEL)

    # Bot Framework Authentication (env名は設計書通り。SDKが期待するキーへマッピングする)
    bf_config = {
        "MicrosoftAppId": settings.AZURE_APP_ID,
        "MicrosoftAppPassword": settings.AZURE_APP_PASSWORD,
        "MicrosoftAppType": settings.AZURE_APP_TYPE,
    }
    bot_framework_auth = ConfigurationBotFrameworkAuthentication(bf_config)
    adapter = CloudAdapter(bot_framework_auth)
    adapter.on_turn_error = _on_error

    # Azure credential
    credential = build_credential(settings)

    # Infra
    cosmos = CosmosService(settings, credential)
    openai_service = AzureOpenAIService(settings, credential)

    # Repo / UC / Bot
    conv_repo = ConversationRepository(cosmos)
    status_repo = StatusRepository(cosmos)
    audit_repo = AuditRepository(cosmos)

    chat_uc = ChatUsecase(
        openai_service=openai_service,
        conv_repo=conv_repo,
        status_repo=status_repo,
        audit_repo=audit_repo,
        history_limit=settings.CHAT_HISTORY_RECORD_LIMIT,
        retention_days=settings.CHAT_HISTORY_RETENTION_DAYS,
        timeout_seconds=settings.AI_PROCESSING_TIMEOUT_SECONDS,
    )
    bot = TeamsAIBot(chat_uc, max_text_length=settings.MAX_TEXT_LENGTH)

    app = web.Application(middlewares=[aiohttp_error_middleware])
    app["adapter"] = adapter
    app["bot"] = bot
    app["cosmos"] = cosmos

    async def health(_: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    async def messages(req: web.Request) -> web.StreamResponse:
        adapter: CloudAdapter = req.app["adapter"]
        bot: TeamsAIBot = req.app["bot"]
        return await adapter.process(req, bot)

    app.router.add_get("/health", health)
    app.router.add_post("/api/messages", messages)

    async def on_startup(app_: web.Application) -> None:
        await app_["cosmos"].open()

    async def on_cleanup(app_: web.Application) -> None:
        await app_["cosmos"].close()

    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    return app
