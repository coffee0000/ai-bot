from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ===== Azure OpenAI =====
    AZURE_OPENAI_ENDPOINT: str
    AZURE_OPENAI_API_VERSION: str
    AZURE_OPENAI_DEPLOYMENT: str
    AZURE_OPENAI_MAX_TOKENS: int = 1024
    AZURE_OPENAI_SYSTEM_PROMPT: str = ""

    # ===== Runtime =====
    PORT: int = 8000

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
    )

@classmethod
def load_from_env(cls) -> "Settings":
    return cls()
