from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from azure.identity import get_bearer_token_provider
from openai import AzureOpenAI

from src.config.settings import Settings

@dataclass(frozen=True)
class AiResponse:
    content: str
    response_metadata: dict[str, Any]
    id: str
    usage_metadata: dict[str, Any]

class AzureOpenAIService:
    def __init__(self, settings: Settings, credential) -> None:
        token_provider = get_bearer_token_provider(
            credential, "https://cognitiveservices.azure.com/.default"
        )
        self._client = AzureOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_ad_token_provider=token_provider,
        )
        self._deployment = settings.AZURE_OPENAI_DEPLOYMENT
        self._max_tokens = settings.AZURE_OPENAI_MAX_TOKENS
        self._system_prompt = settings.AZURE_OPENAI_SYSTEM_PROMPT

    def build_messages(self, history: list[dict[str, str]], user_text: str) -> list[dict[str, str]]:
        messages: list[dict[str, str]] = []
        if self._system_prompt:
            messages.append({"role": "system", "content": self._system_prompt})

        for h in history:
            messages.append({"role": h["role"], "content": h["content"]})

        messages.append({"role": "user", "content": user_text})
        return messages

    def chat(self, messages: list[dict[str, str]]) -> AiResponse:
        # ここは同期呼び出し（SDK内部でHTTP通信）
        resp = self._client.chat.completions.create(
            model=self._deployment,
            messages=messages,
            max_tokens=self._max_tokens,
        )

        content = ""
        if resp.choices and resp.choices[0].message and resp.choices[0].message.content:
            content = resp.choices[0].message.content

        usage = {}
        if getattr(resp, "usage", None) is not None:
            usage = {
                "prompt_tokens": getattr(resp.usage, "prompt_tokens", None),
                "completion_tokens": getattr(resp.usage, "completion_tokens", None),
                "total_tokens": getattr(resp.usage, "total_tokens", None),
            }

        meta = {
            "model": getattr(resp, "model", None),
        }

        return AiResponse(
            content=content,
            response_metadata=meta,
            id=getattr(resp, "id", ""),
            usage_metadata=usage,
        )
