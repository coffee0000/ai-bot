import time

class LockService:
    _locks = {}

    async def try_lock(self, cid: str) -> bool:
        now = time.time()
        lock = self._locks.get(cid)
        if lock and now - lock < 600:
            return False
        self._locks[cid] = now
        return True

    async def unlock(self, cid: str):
        self._locks.pop(cid, None)
