from services.lock_service import LockService

class ChatService:
    async def handle(self, turn_context):
        conversation_id = turn_context.activity.conversation.id
        lock = LockService()

        if not await lock.try_lock(conversation_id):
            return "当前会话正在处理中，请稍候。"

        try:
            text = turn_context.activity.text.strip()
            return f"AI Response: {text}"
        finally:
            await lock.unlock(conversation_id)
