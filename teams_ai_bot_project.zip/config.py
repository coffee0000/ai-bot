from pydantic import BaseSettings

class Settings(BaseSettings):
    MICROSOFT_APP_ID: str = ""
    MICROSOFT_APP_PASSWORD: str = ""
    COSMOS_ENDPOINT: str
    COSMOS_DB: str
    COSMOS_CONTAINER: str
    AI_PROCESSING_TIMEOUT_SECONDS: int = 600

settings = Settings()
