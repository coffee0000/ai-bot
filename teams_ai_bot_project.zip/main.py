from __future__ import annotations

import asyncio
import os

from aiohttp import web
from dotenv import load_dotenv

from teams_ai_bot_project.logger import setup_logging
from teams_ai_bot_project.config import load_settings
from teams_ai_bot_project.infra_credentials import create_credential
from teams_ai_bot_project.infra_cosmos import create_cosmos_client, get_container_clients
from teams_ai_bot_project.repositories import CosmosRepository
from teams_ai_bot_project.adapter import create_adapter
from teams_ai_bot_project.teams_bot import TeamsAIBot
from teams_ai_bot_project.app import create_web_app


async def main() -> None:
    load_dotenv()
    setup_logging()
    settings = load_settings()

    cred = await create_credential(settings)
    cosmos = await create_cosmos_client(settings, cred)
    business, _archive = get_container_clients(cosmos, settings)
    repo = CosmosRepository(business)

    adapter = create_adapter(settings)
    bot = TeamsAIBot(settings, repo)
    app = create_web_app(adapter, bot)

    host = "0.0.0.0"
    port = int(os.getenv("PORT", "3978"))
    web.run_app(app, host=host, port=port)


if __name__ == "__main__":
    asyncio.run(main())
