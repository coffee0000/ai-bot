from botbuilder.core import BotFrameworkAdapter, BotFrameworkAdapterSettings
from config import settings

adapter_settings = BotFrameworkAdapterSettings(
    app_id=settings.MICROSOFT_APP_ID,
    app_password=settings.MICROSOFT_APP_PASSWORD
)
adapter = BotFrameworkAdapter(adapter_settings)
