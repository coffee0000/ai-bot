from aiohttp import web
from app.common.error_handler import handle_exception

routes = web.RouteTableDef()

@routes.post("/api/messages")
async def messages(request):
    try:
        data = await request.json()
        return web.json_response({"message": "ok"})
    except Exception as e:
        return handle_exception(e)
