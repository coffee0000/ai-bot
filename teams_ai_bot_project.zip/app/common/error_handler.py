from aiohttp import web
from app.domain.exceptions import AIProcessingLockedException

def handle_exception(exc: Exception):
    if isinstance(exc, AIProcessingLockedException):
        return web.json_response({"message": "AI処理中です。"}, status=409)
    return web.json_response({"message": "内部エラーが発生しました。"}, status=500)
