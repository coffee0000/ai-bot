class AIProcessingLockedException(Exception):
    pass

class AIProcessingTimeoutException(Exception):
    pass

class DatabaseOperationException(Exception):
    pass
