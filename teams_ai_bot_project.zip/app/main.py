from aiohttp import web
from app.controller.message_controller import routes

app = web.Application()
app.add_routes(routes)

if __name__ == "__main__":
    web.run_app(app, port=8000)
