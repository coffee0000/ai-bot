"""Ensure `src/` is on sys.path for ZIP deploy (no editable install).

Python automatically imports `sitecustomize` if it is importable on startup.
Keeping this in the project root prevents `ModuleNotFoundError` when running
`python app.py` without installing the project as a package.
"""
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
src = root / "src"
if src.exists():
    sys.path.insert(0, str(src))
