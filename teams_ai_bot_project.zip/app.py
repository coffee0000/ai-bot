import asyncio
import logging
import os
import sys
from pathlib import Path

from aiohttp import web
from botbuilder.core import BotFrameworkAdapterSettings
from botbuilder.integration.aiohttp import BotFrameworkAdapter, error_middleware

# ZIP 配置：确保 src/ 可被 import
ROOT_DIR = Path(__file__).resolve().parent
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from config.settings import Settings
from infra.logging_setup import setup_logging
from bot.teams_ai_bot import TeamsAIBot
from services.chat_service import ChatService
from repositories.cosmos_repository import CosmosRepository
from services.ai_client import AzureOpenAIChatClient
from services.credentials import build_azure_credential


async def create_app() -> web.Application:
    settings = Settings.from_env()

    setup_logging(settings.log_level)

    credential = build_azure_credential(settings)
    cosmos_repo = CosmosRepository(settings=settings, credential=credential)
    ai_client = AzureOpenAIChatClient(settings=settings, credential=credential)

    chat_service = ChatService(settings=settings, repo=cosmos_repo, ai_client=ai_client)

    adapter_settings = BotFrameworkAdapterSettings(
        app_id=settings.azure_app_id,
        app_password=settings.azure_app_password,
    )
    adapter = BotFrameworkAdapter(adapter_settings)

    bot = TeamsAIBot(chat_service=chat_service)

    app = web.Application(middlewares=[error_middleware])
    app["adapter"] = adapter
    app["bot"] = bot
    app.router.add_post("/api/messages", messages)

    # 起動時に Cosmos の接続確認（軽い ping）
    async def on_startup(app: web.Application):
        await cosmos_repo.warmup()

    async def on_cleanup(app: web.Application):
        await cosmos_repo.close()

    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    return app


async def messages(req: web.Request) -> web.Response:
    adapter: BotFrameworkAdapter = req.app["adapter"]
    bot: TeamsAIBot = req.app["bot"]

    body = await req.json()
    auth_header = req.headers.get("Authorization", "")

    async def aux_func(turn_context):
        await bot.on_turn(turn_context)

    await adapter.process_activity(body, auth_header, aux_func)
    return web.Response(status=200)


def main() -> None:
    port = int(os.getenv("PORT", "8000"))
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    app = loop.run_until_complete(create_app())
    web.run_app(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
