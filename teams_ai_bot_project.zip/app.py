import os
import sys
from pathlib import Path

# Ensure 'src' is importable when running as ZIP deploy (without editable install)
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from teams_ai_bot.web.server import main  # noqa: E402


if __name__ == "__main__":
    main()
