import asyncio
import logging
from aiohttp import web

from teams_ai_bot.web.aiohttp_app import create_app

logging.basicConfig(level=logging.INFO)

def main() -> None:
    app = create_app()
    web.run_app(app, host="0.0.0.0", port=int(app["settings"].port))

if __name__ == "__main__":
    main()
