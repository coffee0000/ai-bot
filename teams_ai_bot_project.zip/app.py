import asyncio
from aiohttp import web
from adapters import adapter
from bots.ai_chat_bot import AITeamsBot

async def messages(req):
    body = await req.json()
    auth = req.headers.get("Authorization", "")
    response = await adapter.process_activity(body, auth, AITeamsBot().on_turn)
    if response:
        return web.json_response(data=response.body, status=response.status)
    return web.Response(status=201)

app = web.Application()
app.router.add_post("/api/messages", messages)

if __name__ == "__main__":
    web.run_app(app, port=3978)
