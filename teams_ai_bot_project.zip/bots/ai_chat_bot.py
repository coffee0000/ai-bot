from botbuilder.core import ActivityHandler, TurnContext
from services.chat_service import ChatService

class AITeamsBot(ActivityHandler):
    async def on_message_activity(self, turn_context: TurnContext):
        result = await ChatService().handle(turn_context)
        await turn_context.send_activity(result)
