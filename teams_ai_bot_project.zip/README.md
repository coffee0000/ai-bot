# teams_ai_bot_project

Teams Bot (Python/aiohttp + Bot Framework SDK) + Azure OpenAI (LangChain) + Azure Cosmos DB.

## 前提
- Python 3.14
- Azure App Service（公開ファイル / Zip Deploy など）
- Bot Framework の設定（Azure Bot / Teams チャネル接続）

## 起動方法（ローカル）
1) 依存関係のインストール
```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
```

2) 環境変数を設定（`.env` を使う場合は `DEV_FLG=true` にする）
```bash
cp .env.example .env
# 値を埋める
```

3) 起動
```bash
python -m teams_ai_bot_project.web.main
```

## デプロイ（Azure App Service / 公開ファイル）
- このリポジトリを ZIP 化して App Service にアップロード（Zip Deploy / 公開ファイル）
- App Service の「スタートアップ コマンド」に以下のいずれかを設定
  - `python -m teams_ai_bot_project.web.main`
  - または `bash startup.sh`

## エンドポイント
- `POST /api/messages` : Bot Framework からの受信

## 注意
- Bot Framework の JWT 検証は SDK が行います（Adapter が検証）。
- Azure OpenAI と Cosmos DB は Entra ID（DefaultAzureCredential / ClientSecretCredential）で接続します。
