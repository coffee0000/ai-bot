# teams_ai_bot_project

「前の構成（aiohttp + BotFrameworkHttpAdapter + /api/messages）」を維持したまま、
Azure OpenAI 呼び出し部分だけを **LangChain（langchain_openai + langchain_core）** に差し替えた版です。

## 起動（ローカル）
1) `.env.example` → `.env` を作成して値を設定
2) `pip install -r requirements.txt`
3) `python -m teams_ai_bot_project.app`

## デプロイ（Azure App Service: 公開ファイル/Zip）
- ZIP をアップロード
- Startup Command: `python -m teams_ai_bot_project.app`

## Endpoint
- `POST /api/messages`
