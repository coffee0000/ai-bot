# Teams AI Bot

Generated project scaffold.
