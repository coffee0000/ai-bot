# teams_ai_bot_project

Teams ボット（Bot Framework / Python）＋ Azure OpenAI ＋ Azure Cosmos DB（Entra ID 認証）構成の AI チャットアプリです。  
設計書（要件/機能/DB/API/環境変数/方式）に合わせて、以下を実装しています。

- 入力チェック（空/最大文字数）
- 排他制御（AI 生成中は待機メッセージ返却、タイムアウトでロック解除）
- 会話履歴（CosmosDB から取得→Azure OpenAI に渡す→保存）
- AI 会話状態（processing_flg / locked_at など）管理
- 過去データの削除（保持日数に基づき削除）
- Azure の認証方式
  - 本番（Azure 上）: DefaultAzureCredential（Managed Identity）
  - ローカル: DEV_FLG=true の場合 ClientSecretCredential、false の場合 DefaultAzureCredential

## 1) デプロイ（Azure App Service: ZIP 公開ファイル）

ZIP でアップロードした後、スタートアップコマンドを次のいずれかで設定してください。

- Linux App Service の場合（推奨）:
  - `bash startup.sh`

`startup.sh` は `gunicorn`（aiohttp worker）で起動します。

## 2) ローカル起動

1. Python 3.14 を用意
2. 依存をインストール
   - `pip install -r requirements.txt`
3. `.env.example` をコピーして `.env` を作成し、値を設定
4. 起動
   - `python main.py`

## 3) エンドポイント

- `POST /api/messages`

（Bot Framework Emulator / Azure Bot Service / Teams からのメッセージを受けます）

## 4) 注意

- Cosmos DB の Container 側のパーティションキー設計は環境に依存します。
  - 本実装は `conversation_id` をパーティションキーとして扱う前提で `partition_key=conversation_id` を指定します。
  - 実際の設定と異なる場合は、`infra/cosmos/repositories.py` の delete/read の partition key を合わせてください。

