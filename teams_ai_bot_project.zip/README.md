# Teams AI Bot (ZIP Deploy)

- Deploy method: Azure App Service "公開ファイル（ZIP）" upload
- Entry point: `app.py` at repository root
- Python: 3.14
- Dependencies are pinned in `requirements.lock`

## App Service Startup Command example
```
python app.py
```

## Local run
```
python -m venv .venv
.venv/bin/pip install -r requirements.lock
cp .env.sample .env
python app.py
```

※ `.env` is for local only. App Service should set environment variables in Configuration.
