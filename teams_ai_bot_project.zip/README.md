# Teams AI Bot (ZIP Deploy / Enterprise Scaffold)

- Entry point: `app.py` (project root)
- Source layout: `src/teams_ai_bot/*`
- ZIP deploy friendly: root `sitecustomize.py` ensures `src/` is importable without installing the package.

## Start (local)
```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.lock
cp .env.sample .env
# set required env values
python app.py
```
