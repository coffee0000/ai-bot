#!/usr/bin/env bash
set -euo pipefail
python -m teams_ai_bot_project.web.main
