#!/usr/bin/env bash
set -euo pipefail

# App Service on Linux usually provides PORT
: "${PORT:=8000}"

exec gunicorn "teams_ai_bot_project.wsgi:app"   --bind "0.0.0.0:${PORT}"   --worker-class aiohttp.worker.GunicornWebWorker   --workers 2   --timeout 120
