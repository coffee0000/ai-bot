from __future__ import annotations

import logging
import uuid

from botbuilder.core import ActivityHandler, TurnContext
from botbuilder.schema import ActivityTypes

from services.chat_service import ChatService

logger = logging.getLogger(__name__)

class TeamsAIBot(ActivityHandler):
    def __init__(self, chat_service: ChatService) -> None:
        self._chat_service = chat_service

    async def on_message_activity(self, turn_context: TurnContext):
        # Request-ID: generate per turn
        request_id = uuid.uuid4().hex

        # user_id / conversation_id: use Teams/Bot Framework fields
        user_id = (turn_context.activity.from_property.id if turn_context.activity.from_property else "unknown")
        conversation_id = (turn_context.activity.conversation.id if turn_context.activity.conversation else "unknown")
        text = turn_context.activity.text or ""

        answer = await self._chat_service.handle_user_message(
            user_id=user_id,
            conversation_id=conversation_id,
            text=text,
            request_id=request_id,
        )
        await turn_context.send_activity(answer)

    async def on_turn(self, turn_context: TurnContext):
        await super().on_turn(turn_context)
