from __future__ import annotations
import datetime

def utcnow_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat()
