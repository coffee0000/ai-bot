from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
import uuid


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class ConversationHistoryItem:
    id: str
    schema_name: str
    conversation_id: str
    role: str
    content: str
    create_at: str

    @staticmethod
    def new(conversation_id: str, role: str, content: str) -> "ConversationHistoryItem":
        return ConversationHistoryItem(
            id=str(uuid.uuid4()),
            schema_name="conversation_history",
            conversation_id=conversation_id,
            role=role,
            content=content,
            create_at=utc_now_iso(),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "schema_name": self.schema_name,
            "conversation_id": self.conversation_id,
            "role": self.role,
            "content": self.content,
            "create_at": self.create_at,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "ConversationHistoryItem":
        return ConversationHistoryItem(
            id=str(d.get("id")),
            schema_name=str(d.get("schema_name")),
            conversation_id=str(d.get("conversation_id")),
            role=str(d.get("role")),
            content=str(d.get("content")),
            create_at=str(d.get("create_at")),
        )


@dataclass(frozen=True)
class AIProcessingStatusItem:
    id: str
    schema_name: str
    conversation_id: str
    processing_flg: str  # "0" or "1"
    locked_at: str
    create_at: str

    @staticmethod
    def new(conversation_id: str, processing_flg: str, locked_at: str | None = None) -> "AIProcessingStatusItem":
        now = utc_now_iso()
        return AIProcessingStatusItem(
            id=str(uuid.uuid4()),
            schema_name="ai_processing_status",
            conversation_id=conversation_id,
            processing_flg=processing_flg,
            locked_at=locked_at or now,
            create_at=now,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "schema_name": self.schema_name,
            "conversation_id": self.conversation_id,
            "processing_flg": self.processing_flg,
            "locked_at": self.locked_at,
            "create_at": self.create_at,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "AIProcessingStatusItem":
        return AIProcessingStatusItem(
            id=str(d.get("id")),
            schema_name=str(d.get("schema_name")),
            conversation_id=str(d.get("conversation_id")),
            processing_flg=str(d.get("processing_flg")),
            locked_at=str(d.get("locked_at")),
            create_at=str(d.get("create_at", "")),
        )


@dataclass(frozen=True)
class AuditLogItem:
    id: str
    schema_name: str
    conversation_id: str
    user_input: str
    ai_output: str
    create_at: str
    is_filtered_flg: str  # "0" fixed
    update_flg: str       # "0" fixed

    @staticmethod
    def new(conversation_id: str, user_input: str, ai_output: str) -> "AuditLogItem":
        return AuditLogItem(
            id=str(uuid.uuid4()),
            schema_name="audit_log",
            conversation_id=conversation_id,
            user_input=user_input,
            ai_output=ai_output,
            create_at=utc_now_iso(),
            is_filtered_flg="0",
            update_flg="0",
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "schema_name": self.schema_name,
            "conversation_id": self.conversation_id,
            "user_input": self.user_input,
            "ai_output": self.ai_output,
            "create_at": self.create_at,
            "is_filtered_flg": self.is_filtered_flg,
            "update_flg": self.update_flg,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "AuditLogItem":
        return AuditLogItem(
            id=str(d.get("id")),
            schema_name=str(d.get("schema_name")),
            conversation_id=str(d.get("conversation_id")),
            user_input=str(d.get("user_input")),
            ai_output=str(d.get("ai_output")),
            create_at=str(d.get("create_at")),
            is_filtered_flg=str(d.get("is_filtered_flg")),
            update_flg=str(d.get("update_flg")),
        )
