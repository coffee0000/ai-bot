from __future__ import annotations

from typing import Dict, Any, Optional
from azure.cosmos import ContainerProxy
from teams_ai_bot.config.settings import Settings
from teams_ai_bot.repositories.cosmos.client import build_cosmos_client


SCHEMA_AI_PROCESSING_STATUS = "ai_processing_status"


class AIStatusRepository:
    def __init__(self, settings: Settings) -> None:
        client = build_cosmos_client(settings)
        db = client.get_database_client(settings.azure_cosmosdb_database_name)
        self._container: ContainerProxy = db.get_container_client(settings.azure_cosmosdb_container_business)

    async def get(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        query = (
            "SELECT * FROM c WHERE c.schema_name = @schema AND c.conversation_id = @conversation_id"
        )
        params = [
            {"name": "@schema", "value": SCHEMA_AI_PROCESSING_STATUS},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = list(self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True))
        return items[0] if items else None

    async def upsert(self, doc: Dict[str, Any]) -> None:
        self._container.upsert_item(doc)
