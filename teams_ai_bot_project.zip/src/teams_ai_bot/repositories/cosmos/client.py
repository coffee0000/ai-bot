from __future__ import annotations

from azure.cosmos import CosmosClient
from azure.identity import DefaultAzureCredential, ClientSecretCredential
from teams_ai_bot.config.settings import Settings


def build_cosmos_client(settings: Settings) -> CosmosClient:
    if settings.dev_flg:
        credential = ClientSecretCredential(
            tenant_id=settings.azure_auth_tenant_id,
            client_id=settings.azure_auth_client_id,
            client_secret=settings.azure_auth_client_secret,
        )
    else:
        credential = DefaultAzureCredential()

    return CosmosClient(url=settings.azure_cosmosdb_endpoint, credential=credential)
