from __future__ import annotations

from typing import List, Dict, Any, Optional
from azure.cosmos import ContainerProxy
from teams_ai_bot.config.settings import Settings
from teams_ai_bot.repositories.cosmos.client import build_cosmos_client


SCHEMA_CONVERSATION_HISTORY = "conversation_history"


class ChatHistoryRepository:
    def __init__(self, settings: Settings) -> None:
        client = build_cosmos_client(settings)
        db = client.get_database_client(settings.azure_cosmosdb_database_name)
        self._container: ContainerProxy = db.get_container_client(settings.azure_cosmosdb_container_business)
        self._limit = settings.ai_chat_history_limit

    async def list_recent(self, user_id: str, conversation_id: str) -> List[Dict[str, Any]]:
        # NOTE: Cosmos Python SDK is sync. Keep repository interface async for future swap.
        query = (
            "SELECT TOP @limit c.role, c.content, c.create_at "
            "FROM c WHERE c.schema_name = @schema AND c.user_id = @user_id AND c.conversation_id = @conversation_id "
            "ORDER BY c.create_at DESC"
        )
        params = [
            {"name": "@limit", "value": self._limit},
            {"name": "@schema", "value": SCHEMA_CONVERSATION_HISTORY},
            {"name": "@user_id", "value": user_id},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = list(self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True))
        # Returned DESC; caller expects oldest->newest for message building
        return list(reversed(items))

    async def upsert(self, doc: Dict[str, Any]) -> None:
        self._container.upsert_item(doc)

    async def delete_older_than_days(self, user_id: str, conversation_id: str, days: int) -> None:
        # Placeholder: depends on your partition key strategy.
        # Implement according to your DB spec / partition key setting.
        return
