from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import timedelta


def _get_env(name: str, default: str | None = None) -> str | None:
    v = os.getenv(name)
    if v is None or v == "":
        return default
    return v


def _get_int(name: str, default: int) -> int:
    v = _get_env(name)
    if v is None:
        return default
    return int(v)


def _get_bool(name: str, default: bool) -> bool:
    v = _get_env(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "y", "on"}


@dataclass(frozen=True)
class AppSettings:
    # === from 環境変数設計書 ===
    AI_CHAT_HISTORY_LIMIT: int
    BOT_USER_INPUT_MAX_LENGTH: int
    AI_PROCESSING_TIMEOUT_SECONDS: int
    CHAT_HISTORY_RETENTION_DAYS: int

    # bot framework adapter credentials
    AZURE_APP_ID: str
    AZURE_APP_PASSWORD: str

    # azure openai (Entra ID)
    AZURE_OPENAI_SYSTEM_PROMPT: str
    AZURE_OPENAI_ENDPOINT: str
    AZURE_OPENAI_API_VERSION: str
    AZURE_OPENAI_DEPLOYMENT: str
    AZURE_OPENAI_MAX_TOKEN: int

    # cosmos
    AZURE_COSMOSDB_ENDPOINT: str
    AZURE_COSMOSDB_DATABASE_NAME: str
    AZURE_COSMOSDB_CONTAINER_BUSINESS: str
    AZURE_COSMOSDB_CONTAINER_ARCHIVE: str

    # local dev auth (only when DEV_FLG=true)
    DEV_FLG: bool
    AZURE_AUTH_TENANT_ID: str | None
    AZURE_AUTH_CLIENT_ID: str | None
    AZURE_AUTH_CLIENT_SECRET: str | None

    # optional
    LOG_LEVEL: str = "INFO"

    @property
    def ai_processing_timeout(self) -> timedelta:
        return timedelta(seconds=self.AI_PROCESSING_TIMEOUT_SECONDS)

    @staticmethod
    def load() -> "AppSettings":
        # local dev convenience only (App Service usually uses Application Settings)
        try:
            from dotenv import load_dotenv  # type: ignore
            load_dotenv(override=False)
        except Exception:
            pass

        return AppSettings(
            AI_CHAT_HISTORY_LIMIT=_get_int("AI_CHAT_HISTORY_LIMIT", 10),
            BOT_USER_INPUT_MAX_LENGTH=_get_int("BOT_USER_INPUT_MAX_LENGTH", 2500),
            AI_PROCESSING_TIMEOUT_SECONDS=_get_int("AI_PROCESSING_TIMEOUT_SECONDS", 600),
            CHAT_HISTORY_RETENTION_DAYS=_get_int("CHAT_HISTORY_RETENTION_DAYS", 30),

            AZURE_APP_ID=_get_env("AZURE_APP_ID") or "",
            AZURE_APP_PASSWORD=_get_env("AZURE_APP_PASSWORD") or "",

            AZURE_OPENAI_SYSTEM_PROMPT=_get_env("AZURE_OPENAI_SYSTEM_PROMPT", "") or "",
            AZURE_OPENAI_ENDPOINT=_get_env("AZURE_OPENAI_ENDPOINT") or "",
            AZURE_OPENAI_API_VERSION=_get_env("AZURE_OPENAI_API_VERSION") or "",
            AZURE_OPENAI_DEPLOYMENT=_get_env("AZURE_OPENAI_DEPLOYMENT") or "",
            AZURE_OPENAI_MAX_TOKEN=_get_int("AZURE_OPENAI_MAX_TOKEN", 800),

            AZURE_COSMOSDB_ENDPOINT=_get_env("AZURE_COSMOSDB_ENDPOINT") or "",
            AZURE_COSMOSDB_DATABASE_NAME=_get_env("AZURE_COSMOSDB_DATABASE_NAME") or "",
            AZURE_COSMOSDB_CONTAINER_BUSINESS=_get_env("AZURE_COSMOSDB_CONTAINER_BUSINESS") or "",
            AZURE_COSMOSDB_CONTAINER_ARCHIVE=_get_env("AZURE_COSMOSDB_CONTAINER_ARCHIVE") or "",

            DEV_FLG=_get_bool("DEV_FLG", False),
            AZURE_AUTH_TENANT_ID=_get_env("AZURE_AUTH_TENANT_ID"),
            AZURE_AUTH_CLIENT_ID=_get_env("AZURE_AUTH_CLIENT_ID"),
            AZURE_AUTH_CLIENT_SECRET=_get_env("AZURE_AUTH_CLIENT_SECRET"),

            LOG_LEVEL=_get_env("LOG_LEVEL", "INFO") or "INFO",
        )

    def validate(self) -> None:
        required = {
            "AZURE_APP_ID": self.AZURE_APP_ID,
            "AZURE_APP_PASSWORD": self.AZURE_APP_PASSWORD,
            "AZURE_OPENAI_ENDPOINT": self.AZURE_OPENAI_ENDPOINT,
            "AZURE_OPENAI_API_VERSION": self.AZURE_OPENAI_API_VERSION,
            "AZURE_OPENAI_DEPLOYMENT": self.AZURE_OPENAI_DEPLOYMENT,
            "AZURE_COSMOSDB_ENDPOINT": self.AZURE_COSMOSDB_ENDPOINT,
            "AZURE_COSMOSDB_DATABASE_NAME": self.AZURE_COSMOSDB_DATABASE_NAME,
            "AZURE_COSMOSDB_CONTAINER_BUSINESS": self.AZURE_COSMOSDB_CONTAINER_BUSINESS,
            "AZURE_COSMOSDB_CONTAINER_ARCHIVE": self.AZURE_COSMOSDB_CONTAINER_ARCHIVE,
        }
        missing = [k for k, v in required.items() if not v]
        if missing:
            raise ValueError(f"Missing required env vars: {', '.join(missing)}")

        if self.DEV_FLG:
            sp_missing = [
                k
                for k, v in {
                    "AZURE_AUTH_TENANT_ID": self.AZURE_AUTH_TENANT_ID,
                    "AZURE_AUTH_CLIENT_ID": self.AZURE_AUTH_CLIENT_ID,
                    "AZURE_AUTH_CLIENT_SECRET": self.AZURE_AUTH_CLIENT_SECRET,
                }.items()
                if not v
            ]
            if sp_missing:
                raise ValueError(f"DEV_FLG=true requires: {', '.join(sp_missing)}")
