from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


def _get_env(name: str, default: Optional[str] = None) -> str:
    val = os.getenv(name)
    if val is None or val == "":
        if default is None:
            raise RuntimeError(f"Missing required environment variable: {name}")
        return default
    return val


def _get_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError as e:
        raise RuntimeError(f"Invalid int for env {name}: {raw}") from e


def _get_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


@dataclass(frozen=True, slots=True)
class Settings:
    # ---- Common ----
    port: int = 8000

    # ---- App controls ----
    ai_chat_history_limit: int = 10
    bot_user_input_max_length: int = 2500
    ai_processing_timeout_seconds: int = 600
    chat_history_retention_days: int = 30

    # ---- Bot Framework (Bot Service) ----
    azure_app_id: str = ""
    azure_app_password: str = ""

    # ---- Azure OpenAI ----
    azure_openai_system_prompt: str = ""
    azure_openai_endpoint: str = ""
    azure_openai_api_version: str = ""
    azure_openai_deployment: str = ""
    azure_openai_max_token: int = 0

    # ---- Azure Cosmos DB ----
    azure_cosmosdb_endpoint: str = ""
    azure_cosmosdb_database_name: str = ""
    azure_cosmosdb_container_business: str = ""
    azure_cosmosdb_container_archive: str = ""

    # ---- Local dev auth ----
    dev_flg: bool = False
    azure_auth_tenant_id: str = ""
    azure_auth_client_id: str = ""
    azure_auth_client_secret: str = ""

    @staticmethod
    def load() -> "Settings":
        # NOTE: Env names must match the user's environment-variable design doc exactly.
        return Settings(
            port=_get_int("PORT", 8000),
            ai_chat_history_limit=_get_int("AI_CHAT_HISTORY_LIMIT", 10),
            bot_user_input_max_length=_get_int("BOT_USER_INPUT_MAX_LENGTH", 2500),
            ai_processing_timeout_seconds=_get_int("AI_PROCESSING_TIMEOUT_SECONDS", 600),
            chat_history_retention_days=_get_int("CHAT_HISTORY_RETENTION_DAYS", 30),

            azure_app_id=_get_env("AZURE_APP_ID", "-"),
            azure_app_password=_get_env("AZURE_APP_PASSWORD", "-"),

            azure_openai_system_prompt=os.getenv("AZURE_OPENAI_SYSTEM_PROMPT", ""),
            azure_openai_endpoint=_get_env("AZURE_OPENAI_ENDPOINT", "-"),
            azure_openai_api_version=_get_env("AZURE_OPENAI_API_VERSION", "-"),
            azure_openai_deployment=_get_env("AZURE_OPENAI_DEPLOYMENT", "-"),
            azure_openai_max_token=_get_int("AZURE_OPENAI_MAX_TOKEN", 0),

            azure_cosmosdb_endpoint=_get_env("AZURE_COSMOSDB_ENDPOINT", "-"),
            azure_cosmosdb_database_name=_get_env("AZURE_COSMOSDB_DATABASE_NAME", "-"),
            azure_cosmosdb_container_business=_get_env("AZURE_COSMOSDB_CONTAINER_BUSINESS", "-"),
            azure_cosmosdb_container_archive=_get_env("AZURE_COSMOSDB_CONTAINER_ARCHIVE", "-"),

            dev_flg=_get_bool("DEV_FLG", False),
            azure_auth_tenant_id=os.getenv("AZURE_AUTH_TENANT_ID", ""),
            azure_auth_client_id=os.getenv("AZURE_AUTH_CLIENT_ID", ""),
            azure_auth_client_secret=os.getenv("AZURE_AUTH_CLIENT_SECRET", ""),
        )
