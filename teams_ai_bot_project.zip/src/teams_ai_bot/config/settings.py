from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import timedelta


def _get_env(name: str, default: str | None = None) -> str | None:
    v = os.getenv(name)
    if v is None or v == "":
        return default
    return v


def _get_int(name: str, default: int) -> int:
    v = _get_env(name)
    if v is None:
        return default
    return int(v)


def _get_bool(name: str, default: bool) -> bool:
    v = _get_env(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "y", "on"}


@dataclass(frozen=True)
class AppSettings:
    # app
    DEV_FLG: bool
    LOG_LEVEL: str

    # bot
    BOT_USER_INPUT_MAX_LENGTH: int
    AI_CHAT_HISTORY_LIMIT: int
    AI_PROCESSING_TIMEOUT_SECONDS: int

    # azure openai (Entra ID auth)
    AOAI_ENDPOINT: str
    AOAI_API_VERSION: str
    AOAI_CHAT_MODEL_DEPLOYMENT: str
    AOAI_TEMPERATURE: float
    AOAI_MAX_TOKENS: int
    AOAI_SYSTEM_PROMPT: str

    # cosmos
    AZURE_COSMOSDB_ENDPOINT: str
    AZURE_COSMOSDB_DATABASE: str
    AZURE_COSMOSDB_CONTAINER_BUSINESS: str
    AZURE_COSMOSDB_CONTAINER_ARCHIVE: str

    # service principal (local only when DEV_FLG=true)
    AZURE_TENANT_ID: str | None
    AZURE_CLIENT_ID: str | None
    AZURE_CLIENT_SECRET: str | None

    @property
    def ai_processing_timeout(self) -> timedelta:
        return timedelta(seconds=self.AI_PROCESSING_TIMEOUT_SECONDS)

    @staticmethod
    def load() -> "AppSettings":
        # NOTE: .env loading is intentionally optional, for local dev convenience.
        try:
            from dotenv import load_dotenv  # type: ignore
            load_dotenv(override=False)
        except Exception:
            pass

        return AppSettings(
            DEV_FLG=_get_bool("DEV_FLG", False),
            LOG_LEVEL=_get_env("LOG_LEVEL", "INFO") or "INFO",

            BOT_USER_INPUT_MAX_LENGTH=_get_int("BOT_USER_INPUT_MAX_LENGTH", 2500),
            AI_CHAT_HISTORY_LIMIT=_get_int("AI_CHAT_HISTORY_LIMIT", 10),
            AI_PROCESSING_TIMEOUT_SECONDS=_get_int("AI_PROCESSING_TIMEOUT_SECONDS", 600),

            AOAI_ENDPOINT=_get_env("AOAI_ENDPOINT") or "",
            AOAI_API_VERSION=_get_env("AOAI_API_VERSION", "2024-10-21") or "2024-10-21",
            AOAI_CHAT_MODEL_DEPLOYMENT=_get_env("AOAI_CHAT_MODEL_DEPLOYMENT") or "",
            AOAI_TEMPERATURE=float(_get_env("AOAI_TEMPERATURE", "0.2") or "0.2"),
            AOAI_MAX_TOKENS=_get_int("AOAI_MAX_TOKENS", 800),
            AOAI_SYSTEM_PROMPT=_get_env("AOAI_SYSTEM_PROMPT", "") or "",

            AZURE_COSMOSDB_ENDPOINT=_get_env("AZURE_COSMOSDB_ENDPOINT") or "",
            AZURE_COSMOSDB_DATABASE=_get_env("AZURE_COSMOSDB_DATABASE") or "",
            AZURE_COSMOSDB_CONTAINER_BUSINESS=_get_env("AZURE_COSMOSDB_CONTAINER_BUSINESS") or "",
            AZURE_COSMOSDB_CONTAINER_ARCHIVE=_get_env("AZURE_COSMOSDB_CONTAINER_ARCHIVE") or "",

            AZURE_TENANT_ID=_get_env("AZURE_TENANT_ID"),
            AZURE_CLIENT_ID=_get_env("AZURE_CLIENT_ID"),
            AZURE_CLIENT_SECRET=_get_env("AZURE_CLIENT_SECRET"),
        )

    def validate(self) -> None:
        required = {
            "AOAI_ENDPOINT": self.AOAI_ENDPOINT,
            "AOAI_CHAT_MODEL_DEPLOYMENT": self.AOAI_CHAT_MODEL_DEPLOYMENT,
            "AZURE_COSMOSDB_ENDPOINT": self.AZURE_COSMOSDB_ENDPOINT,
            "AZURE_COSMOSDB_DATABASE": self.AZURE_COSMOSDB_DATABASE,
            "AZURE_COSMOSDB_CONTAINER_BUSINESS": self.AZURE_COSMOSDB_CONTAINER_BUSINESS,
        }
        missing = [k for k, v in required.items() if not v]
        if missing:
            raise ValueError(f"Missing required env vars: {', '.join(missing)}")

        if self.DEV_FLG:
            # local dev expects a service principal (ClientSecretCredential)
            sp_missing = [k for k, v in {
                "AZURE_TENANT_ID": self.AZURE_TENANT_ID,
                "AZURE_CLIENT_ID": self.AZURE_CLIENT_ID,
                "AZURE_CLIENT_SECRET": self.AZURE_CLIENT_SECRET,
            }.items() if not v]
            if sp_missing:
                raise ValueError(f"DEV_FLG=true requires: {', '.join(sp_missing)}")
