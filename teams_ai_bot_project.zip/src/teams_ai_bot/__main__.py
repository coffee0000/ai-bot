from teams_ai_bot.web.server import main

if __name__ == '__main__':
    main()
