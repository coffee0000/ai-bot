from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from azure.identity.aio import get_bearer_token_provider
from openai import AsyncAzureOpenAI

from teams_ai_bot.config.settings import AppSettings


Role = Literal["system", "user", "assistant"]


@dataclass
class AzureOpenAIChatClient:
    settings: AppSettings
    credential: Any

    def __post_init__(self) -> None:
        # Token provider for Entra ID auth to Azure OpenAI
        self._token_provider = get_bearer_token_provider(
            self.credential, "https://cognitiveservices.azure.com/.default"
        )

        self._client = AsyncAzureOpenAI(
            azure_endpoint=self.settings.AOAI_ENDPOINT,
            api_version=self.settings.AOAI_API_VERSION,
            azure_ad_token_provider=self._token_provider,
        )

    async def close(self) -> None:
        # close underlying http client
        await self._client.close()

    async def chat(self, messages: list[dict[str, str]]) -> str:
        # messages: [{"role": "...", "content": "..."}]
        resp = await self._client.chat.completions.create(
            model=self.settings.AOAI_CHAT_MODEL_DEPLOYMENT,
            messages=messages,
            temperature=self.settings.AOAI_TEMPERATURE,
            max_tokens=self.settings.AOAI_MAX_TOKENS,
        )
        # Choose first choice safely
        if not resp.choices or not resp.choices[0].message or resp.choices[0].message.content is None:
            return ""
        return resp.choices[0].message.content
