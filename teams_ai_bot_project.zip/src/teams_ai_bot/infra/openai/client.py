from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from azure.identity.aio import get_bearer_token_provider
from openai import AsyncAzureOpenAI

from teams_ai_bot.config.settings import AppSettings


Role = Literal["system", "user", "assistant"]


@dataclass
class AzureOpenAIChatClient:
    settings: AppSettings
    credential: Any

    def __post_init__(self) -> None:
        self._token_provider = get_bearer_token_provider(
            self.credential, "https://cognitiveservices.azure.com/.default"
        )

        self._client = AsyncAzureOpenAI(
            azure_endpoint=self.settings.AZURE_OPENAI_ENDPOINT,
            api_version=self.settings.AZURE_OPENAI_API_VERSION,
            azure_ad_token_provider=self._token_provider,
        )

    async def close(self) -> None:
        await self._client.close()

    async def chat(self, messages: list[dict[str, str]]) -> str:
        resp = await self._client.chat.completions.create(
            model=self.settings.AZURE_OPENAI_DEPLOYMENT,
            messages=messages,
            # temperature は環境変数設計書にないため固定（必要なら将来拡張で追加）
            temperature=0.2,
            max_tokens=self.settings.AZURE_OPENAI_MAX_TOKEN,
        )
        if not resp.choices or not resp.choices[0].message or resp.choices[0].message.content is None:
            return ""
        return resp.choices[0].message.content
