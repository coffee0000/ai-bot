from __future__ import annotations

from dataclasses import dataclass

from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure.core.credentials import TokenCredential

from teams_ai_bot.config.settings import AppSettings


@dataclass(frozen=True)
class AzureCredentialFactory:
    settings: AppSettings

    def create(self) -> TokenCredential:
        # Per your design:
        # - local dev (DEV_FLG=true): service principal (ClientSecretCredential)
        # - Azure (DEV_FLG=false): DefaultAzureCredential (Managed Identity etc.)
        if self.settings.DEV_FLG:
            assert self.settings.AZURE_TENANT_ID and self.settings.AZURE_CLIENT_ID and self.settings.AZURE_CLIENT_SECRET
            return ClientSecretCredential(
                tenant_id=self.settings.AZURE_TENANT_ID,
                client_id=self.settings.AZURE_CLIENT_ID,
                client_secret=self.settings.AZURE_CLIENT_SECRET,
            )

        # DefaultAzureCredential includes Managed Identity when running on Azure.
        return DefaultAzureCredential()
