from __future__ import annotations

from dataclasses import dataclass

from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure.core.credentials import TokenCredential

from teams_ai_bot.config.settings import AppSettings


@dataclass(frozen=True)
class AzureCredentialFactory:
    settings: AppSettings

    def create(self) -> TokenCredential:
        # 設計通り：
        # - ローカル開発（DEV_FLG=true）: ClientSecretCredential
        # - Azure 本番（DEV_FLG=false）: DefaultAzureCredential（Managed Identity 等）
        if self.settings.DEV_FLG:
            assert (
                self.settings.AZURE_AUTH_TENANT_ID
                and self.settings.AZURE_AUTH_CLIENT_ID
                and self.settings.AZURE_AUTH_CLIENT_SECRET
            )
            return ClientSecretCredential(
                tenant_id=self.settings.AZURE_AUTH_TENANT_ID,
                client_id=self.settings.AZURE_AUTH_CLIENT_ID,
                client_secret=self.settings.AZURE_AUTH_CLIENT_SECRET,
            )

        return DefaultAzureCredential()
