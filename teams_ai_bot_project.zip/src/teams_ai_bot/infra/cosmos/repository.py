from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

from azure.cosmos.aio import CosmosClient
from azure.cosmos import PartitionKey

from teams_ai_bot.config.settings import AppSettings
from teams_ai_bot.domain.models import (
    ConversationHistoryItem,
    AIProcessingStatusItem,
    AuditLogItem,
)

logger = logging.getLogger(__name__)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class CosmosRepository:
    settings: AppSettings
    client: CosmosClient

    @classmethod
    async def create(cls, settings: AppSettings, credential) -> "CosmosRepository":
        # CosmosClient supports Entra ID credential authentication. (DefaultAzureCredential etc.)
        # See Microsoft docs: CosmosClient(url, credential=DefaultAzureCredential()).
        client = CosmosClient(url=settings.AZURE_COSMOSDB_ENDPOINT, credential=credential)
        repo = cls(settings=settings, client=client)
        await repo._ensure_clients()
        return repo

    async def close(self) -> None:
        await self.client.close()

    async def _ensure_clients(self) -> None:
        self._db = self.client.get_database_client(self.settings.AZURE_COSMOSDB_DATABASE_NAME)

        self._business = self._db.get_container_client(self.settings.AZURE_COSMOSDB_CONTAINER_BUSINESS)
        # archive container is optional
        self._archive = None
        if self.settings.AZURE_COSMOSDB_CONTAINER_ARCHIVE:
            self._archive = self._db.get_container_client(self.settings.AZURE_COSMOSDB_CONTAINER_ARCHIVE)

    # ----- AI processing status -----

    async def get_ai_processing_status(self, conversation_id: str) -> AIProcessingStatusItem | None:
        query = "SELECT * FROM c WHERE c.schema_name = @schema AND c.conversation_id = @cid"
        params = [
            {"name": "@schema", "value": "ai_processing_status"},
            {"name": "@cid", "value": conversation_id},
        ]
        items = []
        async for item in self._business.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            items.append(item)
        if not items:
            return None
        return AIProcessingStatusItem.from_dict(items[0])

    async def upsert_ai_processing_status(self, item: AIProcessingStatusItem) -> None:
        await self._business.upsert_item(item.to_dict())

    # ----- conversation history -----

    async def insert_conversation_history(self, items: Iterable[ConversationHistoryItem]) -> None:
        for it in items:
            await self._business.create_item(it.to_dict())

    async def delete_conversation_history(self, conversation_id: str) -> None:
        # delete all conversation_history records for this conversation_id
        query = "SELECT c.id, c.conversation_id FROM c WHERE c.schema_name = @schema AND c.conversation_id = @cid"
        params = [
            {"name": "@schema", "value": "conversation_history"},
            {"name": "@cid", "value": conversation_id},
        ]
        async for item in self._business.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            try:
                await self._business.delete_item(item=item["id"], partition_key=item["conversation_id"])
            except Exception as e:
                logger.exception("delete_item_failed", extra={"extra": {"conversation_id": conversation_id, "id": item.get("id")}})
                raise

    async def fetch_recent_history(self, conversation_id: str, limit: int) -> list[ConversationHistoryItem]:
        # Order by create_at desc then take limit; Cosmos requires indexed property.
        query = (
            "SELECT TOP @limit * FROM c "
            "WHERE c.schema_name = @schema AND c.conversation_id = @cid "
            "ORDER BY c.create_at DESC"
        )
        params = [
            {"name": "@limit", "value": limit},
            {"name": "@schema", "value": "conversation_history"},
            {"name": "@cid", "value": conversation_id},
        ]
        items: list[dict[str, Any]] = []
        async for item in self._business.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            items.append(item)
        # reverse to chronological
        items.reverse()
        return [ConversationHistoryItem.from_dict(x) for x in items]

    # ----- audit log -----

    async def insert_audit_log(self, item: AuditLogItem) -> None:
        # Audit log container is fixed by DB design doc; if you want it configurable, add env var later.
        # Here we store it in the same 'business' container with schema_name=audit_log.
        await self._business.create_item(item.to_dict())
