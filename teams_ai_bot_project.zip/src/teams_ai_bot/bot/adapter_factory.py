from __future__ import annotations

from botbuilder.integration.aiohttp import BotFrameworkAdapter, BotFrameworkAdapterSettings
from teams_ai_bot.config.settings import Settings


def build_adapter(settings: Settings) -> BotFrameworkAdapter:
    # Env names must match the user's design doc (AZURE_APP_ID / AZURE_APP_PASSWORD).
    adapter_settings = BotFrameworkAdapterSettings(settings.azure_app_id, settings.azure_app_password)
    adapter = BotFrameworkAdapter(adapter_settings)

    return adapter
