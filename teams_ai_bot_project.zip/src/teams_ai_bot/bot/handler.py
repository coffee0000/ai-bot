from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from botbuilder.core import ActivityHandler, TurnContext

from teams_ai_bot.config.settings import AppSettings
from teams_ai_bot.domain.models import ConversationHistoryItem, AIProcessingStatusItem, AuditLogItem
from teams_ai_bot.infra.cosmos.repository import CosmosRepository
from teams_ai_bot.infra.openai.client import AzureOpenAIChatClient

logger = logging.getLogger(__name__)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# From your 機能仕様書 (排他制御チェック)
WAIT_MESSAGE = "AI回答生成中です。しばらくしてから再試行してください。"
AI_ABNORMAL_CLOSE_MESSAGE = "現在の会話のAIに異常が発生しました。この会話を閉じてから、もう一度チャットを開始してください。"

# From your 機能仕様書 (入力項目チェック)
EMPTY_INPUT_MESSAGE = "入力内容が空です。正しい内容を入力してください。"
TOO_LONG_MESSAGE_TEMPLATE = "入力内容が長すぎます。最大文字数：{max_len}"


class TeamsAIBot(ActivityHandler):
    def __init__(
        self,
        settings: AppSettings,
        cosmos: CosmosRepository,
        aoai: AzureOpenAIChatClient,
    ) -> None:
        super().__init__()
        self._settings = settings
        self._cosmos = cosmos
        self._aoai = aoai

    async def on_message_activity(self, turn_context: TurnContext):
        request_id = str(uuid.uuid4())
        conversation_id = (turn_context.activity.conversation.id or "").strip()

        raw_text = (turn_context.activity.text or "")
        user_text = raw_text.strip()

        if not user_text:
            await turn_context.send_activity(EMPTY_INPUT_MESSAGE)
            return

        if len(user_text) > self._settings.BOT_USER_INPUT_MAX_LENGTH:
            await turn_context.send_activity(
                TOO_LONG_MESSAGE_TEMPLATE.format(max_len=self._settings.BOT_USER_INPUT_MAX_LENGTH)
            )
            return

        # ----- 排他制御チェック -----
        try:
            status = await self._cosmos.get_ai_processing_status(conversation_id)
        except Exception:
            logger.exception("db_get_status_failed", extra={"extra": {"request_id": request_id, "conversation_id": conversation_id}})
            await turn_context.send_activity(
                "データベース処理中に例外が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード："
                + request_id
            )
            return

        now = datetime.now(timezone.utc)

        if status is not None and status.processing_flg == "1":
            # compare now - locked_at
            try:
                locked_at = datetime.fromisoformat(status.locked_at.replace("Z", "+00:00"))
            except Exception:
                locked_at = now

            diff_seconds = int((now - locked_at).total_seconds())
            if diff_seconds <= self._settings.AI_PROCESSING_TIMEOUT_SECONDS:
                await turn_context.send_activity(WAIT_MESSAGE)
                return

            # timeout → unlock and continue
            status = AIProcessingStatusItem(
                id=status.id,
                schema_name=status.schema_name,
                conversation_id=status.conversation_id,
                processing_flg="0",
                locked_at=utc_now_iso(),
                create_at=status.create_at or utc_now_iso(),
            )
            try:
                await self._cosmos.upsert_ai_processing_status(status)
            except Exception:
                logger.exception("db_unlock_timeout_failed", extra={"extra": {"request_id": request_id, "conversation_id": conversation_id}})
                await turn_context.send_activity(
                    "データベース処理中に例外が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード："
                    + request_id
                )
                return

        # lock
        if status is None:
            status = AIProcessingStatusItem.new(conversation_id=conversation_id, processing_flg="1", locked_at=utc_now_iso())
        else:
            status = AIProcessingStatusItem(
                id=status.id,
                schema_name=status.schema_name,
                conversation_id=status.conversation_id,
                processing_flg="1",
                locked_at=utc_now_iso(),
                create_at=status.create_at or utc_now_iso(),
            )

        try:
            await self._cosmos.upsert_ai_processing_status(status)
        except Exception:
            logger.exception("db_lock_failed", extra={"extra": {"request_id": request_id, "conversation_id": conversation_id}})
            await turn_context.send_activity(
                "データベース処理中に例外が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード："
                + request_id
            )
            return

        # ----- AIチャット処理 -----
        try:
            history_items = await self._cosmos.fetch_recent_history(
                conversation_id=conversation_id,
                limit=self._settings.AI_CHAT_HISTORY_LIMIT,
            )

            messages: list[dict[str, str]] = []
            if self._settings.AZURE_OPENAI_SYSTEM_PROMPT:
                messages.append({"role": "system", "content": self._settings.AZURE_OPENAI_SYSTEM_PROMPT})

            for h in history_items:
                # role is stored as 'user' or 'assistant'
                messages.append({"role": h.role, "content": h.content})

            # current user input
            messages.append({"role": "user", "content": user_text})

            ai_text = await self._aoai.chat(messages)

            # store history (user + assistant)
            await self._cosmos.insert_conversation_history([
                ConversationHistoryItem.new(conversation_id=conversation_id, role="user", content=user_text),
                ConversationHistoryItem.new(conversation_id=conversation_id, role="assistant", content=ai_text),
            ])

            # store audit log (schema_name=audit_log)
            await self._cosmos.insert_audit_log(
                AuditLogItem.new(conversation_id=conversation_id, user_input=user_text, ai_output=ai_text)
            )

            # unlock
            unlock = AIProcessingStatusItem(
                id=status.id,
                schema_name=status.schema_name,
                conversation_id=status.conversation_id,
                processing_flg="0",
                locked_at=utc_now_iso(),
                create_at=status.create_at,
            )
            await self._cosmos.upsert_ai_processing_status(unlock)

            await turn_context.send_activity(ai_text)

        except Exception:
            logger.exception("ai_chat_flow_failed", extra={"extra": {"request_id": request_id, "conversation_id": conversation_id}})
            # best-effort unlock
            try:
                if status is not None:
                    unlock = AIProcessingStatusItem(
                        id=status.id,
                        schema_name=status.schema_name,
                        conversation_id=status.conversation_id,
                        processing_flg="0",
                        locked_at=utc_now_iso(),
                        create_at=status.create_at,
                    )
                    await self._cosmos.upsert_ai_processing_status(unlock)
            except Exception:
                logger.exception("unlock_after_error_failed", extra={"extra": {"request_id": request_id, "conversation_id": conversation_id}})

            await turn_context.send_activity(
                "AIの処理中に問題が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード："
                + request_id
            )
