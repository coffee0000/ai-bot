from __future__ import annotations

from botbuilder.core import ActivityHandler, TurnContext, MessageFactory
from teams_ai_bot.config.settings import Settings
from teams_ai_bot.services.orchestration.chat_flow import ChatFlow


class TeamsAIBot(ActivityHandler):
    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self._flow = ChatFlow(settings)

    async def on_message_activity(self, turn_context: TurnContext):
        reply_text = await self._flow.handle_user_message(turn_context)
        await turn_context.send_activity(MessageFactory.text(reply_text))
