from __future__ import annotations

import logging
from aiohttp import web

from botbuilder.schema import Activity

from teams_ai_bot.config.settings import Settings
from teams_ai_bot.bot.adapter_factory import build_adapter
from teams_ai_bot.bot.teams_ai_bot import TeamsAIBot

logger = logging.getLogger(__name__)


def create_app() -> web.Application:
    settings = Settings.load()

    app = web.Application()
    app["settings"] = settings

    adapter = build_adapter(settings)
    bot = TeamsAIBot(settings)

    async def messages(req: web.Request) -> web.StreamResponse:
        body = await req.json()
        activity = Activity().deserialize(body)
        auth_header = req.headers.get("Authorization", "")

        invoke_response = await adapter.process_activity(activity, auth_header, bot.on_turn)
        if invoke_response:
            return web.json_response(data=invoke_response.body, status=invoke_response.status)
        # Bot Framework expects 201 on success for non-invoke activities.
        return web.Response(status=201)

    app.router.add_post("/api/messages", messages)
    return app
