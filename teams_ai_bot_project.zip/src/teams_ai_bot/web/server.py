from __future__ import annotations

import asyncio
import logging
import os
from aiohttp import web

from botbuilder.core import BotFrameworkAdapterSettings, BotFrameworkAdapter, TurnContext
from botbuilder.schema import Activity

from teams_ai_bot.config.settings import AppSettings
from teams_ai_bot.config.logging import configure_logging
from teams_ai_bot.infra.credential import AzureCredentialFactory
from teams_ai_bot.infra.cosmos.repository import CosmosRepository
from teams_ai_bot.infra.openai.client import AzureOpenAIChatClient
from teams_ai_bot.bot.handler import TeamsAIBot

logger = logging.getLogger(__name__)


async def on_error(context: TurnContext, error: Exception) -> None:
    logger.exception("bot_unhandled_error", extra={"extra": {"error": str(error)}})
    await context.send_activity("エラーが発生しました。しばらくしてから再試行してください。")


async def init_app() -> web.Application:
    settings = AppSettings.load()
    settings.validate()
    configure_logging(settings.LOG_LEVEL)

    # Bot Framework credentials (from environment variables)
    # These are standard for botbuilder-python.
    app_id = os.getenv("MICROSOFT_APP_ID", "")
    app_password = os.getenv("MICROSOFT_APP_PASSWORD", "")

    adapter_settings = BotFrameworkAdapterSettings(app_id, app_password)
    adapter = BotFrameworkAdapter(adapter_settings)
    adapter.on_turn_error = on_error

    # Azure credential (Cosmos + Azure OpenAI) per your design.
    azure_credential = AzureCredentialFactory(settings).create()

    cosmos = await CosmosRepository.create(settings=settings, credential=azure_credential)
    aoai = AzureOpenAIChatClient(settings=settings, credential=azure_credential)
    bot = TeamsAIBot(settings=settings, cosmos=cosmos, aoai=aoai)

    app = web.Application()

    async def messages(req: web.Request) -> web.Response:
        # /api/messages endpoint (Bot Framework)
        body = await req.json()
        activity = Activity().deserialize(body)
        auth_header = req.headers.get("Authorization", "")

        async def aux_func(turn_context: TurnContext):
            await bot.on_turn(turn_context)

        await adapter.process_activity(activity, auth_header, aux_func)
        return web.Response(status=201)

    app.router.add_post("/api/messages", messages)

    async def on_shutdown(app: web.Application):
        await cosmos.close()
        await aoai.close()
        # credential close (if async) is not required for sync TokenCredential.

    app.on_shutdown.append(on_shutdown)
    return app


def main() -> None:
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    app = loop.run_until_complete(init_app())
    web.run_app(app, host="0.0.0.0", port=int(os.getenv("PORT", "3978")))


if __name__ == "__main__":
    main()
