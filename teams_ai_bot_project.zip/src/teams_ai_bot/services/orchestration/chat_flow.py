from __future__ import annotations

import asyncio
import datetime
import uuid
from typing import Any, Dict

from botbuilder.core import TurnContext

from teams_ai_bot.config.settings import Settings
from teams_ai_bot.common.time import utcnow_iso
from teams_ai_bot.repositories.cosmos.chat_history_repo import ChatHistoryRepository, SCHEMA_CONVERSATION_HISTORY
from teams_ai_bot.repositories.cosmos.ai_status_repo import AIStatusRepository, SCHEMA_AI_PROCESSING_STATUS
from teams_ai_bot.services.ai.azure_openai_client import AzureOpenAIChatClient
from teams_ai_bot.services.ai.prompt_builder import build_messages


WAIT_MESSAGE = "AIの回答を生成中です。しばらくお待ちください。"
INPUT_EMPTY_MESSAGE = "入力内容が空です。正しい内容を入力してください。"
INPUT_TOO_LONG_MESSAGE = "入力文字数が上限を超えています。内容を短くして再送してください。"
AI_ERROR_MESSAGE = "現在会話のAIで異常が発生しました。会話を閉じて、再度お試しください。"
DB_ERROR_MESSAGE = "データベース処理中に例外が発生しました。しばらくしてから再試行するか、管理者に連絡してください。"


class ChatFlow:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._history_repo = ChatHistoryRepository(settings)
        self._status_repo = AIStatusRepository(settings)
        self._ai = AzureOpenAIChatClient(settings)

    async def handle_user_message(self, turn_context: TurnContext) -> str:
        text = (turn_context.activity.text or "").strip()
        if not text:
            return INPUT_EMPTY_MESSAGE
        if len(text) > self._settings.bot_user_input_max_length:
            return INPUT_TOO_LONG_MESSAGE

        user_id = (turn_context.activity.from_property.id if turn_context.activity.from_property else "") or "unknown"
        conversation_id = (turn_context.activity.conversation.id if turn_context.activity.conversation else "") or "unknown"

        # 1) AI processing status (排他)
        status = await self._status_repo.get(conversation_id)
        now = datetime.datetime.now(datetime.timezone.utc)

        if status and status.get("processing_flg") == "1":
            locked_at_raw = status.get("locked_at")
            if locked_at_raw:
                try:
                    locked_at = datetime.datetime.fromisoformat(locked_at_raw.replace("Z", "+00:00"))
                except Exception:
                    locked_at = None
            else:
                locked_at = None

            if locked_at:
                diff = (now - locked_at).total_seconds()
                if diff <= self._settings.ai_processing_timeout_seconds:
                    return WAIT_MESSAGE

            # timeout -> unlock
            status["processing_flg"] = "0"
            status["locked_at"] = utcnow_iso()
            await self._status_repo.upsert(status)

        # 2) lock
        status_doc = status or {
            "id": str(uuid.uuid4()),
            "schema_name": SCHEMA_AI_PROCESSING_STATUS,
            "conversation_id": conversation_id,
            "processing_flg": "1",
            "locked_at": utcnow_iso(),
            "create_at": utcnow_iso(),
        }
        status_doc["processing_flg"] = "1"
        status_doc["locked_at"] = utcnow_iso()
        if "create_at" not in status_doc:
            status_doc["create_at"] = utcnow_iso()
        await self._status_repo.upsert(status_doc)

        try:
            # 3) load history
            history_items = await self._history_repo.list_recent(user_id, conversation_id)
            messages = build_messages(self._settings, history_items, text)

            # 4) call AI (SDK is sync -> run in thread)
            ai_text = await asyncio.to_thread(self._ai.chat, messages)

            # 5) persist: user message + ai response
            now_iso = utcnow_iso()
            await self._history_repo.upsert({
                "id": str(uuid.uuid4()),
                "schema_name": SCHEMA_CONVERSATION_HISTORY,
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": str(uuid.uuid4()),
                "role": "user",
                "content": text,
                "create_at": now_iso,
            })
            await self._history_repo.upsert({
                "id": str(uuid.uuid4()),
                "schema_name": SCHEMA_CONVERSATION_HISTORY,
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": str(uuid.uuid4()),
                "role": "assistant",
                "content": ai_text,
                "create_at": now_iso,
            })

            # 6) unlock
            status_doc["processing_flg"] = "0"
            status_doc["locked_at"] = utcnow_iso()
            await self._status_repo.upsert(status_doc)

            return ai_text

        except Exception:
            # fail -> set -1 and unlock-ish
            try:
                status_doc["processing_flg"] = "-1"
                status_doc["locked_at"] = utcnow_iso()
                await self._status_repo.upsert(status_doc)
            except Exception:
                return DB_ERROR_MESSAGE
            return AI_ERROR_MESSAGE
