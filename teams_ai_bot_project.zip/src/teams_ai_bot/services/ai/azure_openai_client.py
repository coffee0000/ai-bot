from __future__ import annotations

from typing import List, Dict, Any

from azure.identity import DefaultAzureCredential, ClientSecretCredential, get_bearer_token_provider
from openai import AzureOpenAI

from teams_ai_bot.config.settings import Settings


class AzureOpenAIChatClient:
    def __init__(self, settings: Settings) -> None:
        if settings.dev_flg:
            credential = ClientSecretCredential(
                tenant_id=settings.azure_auth_tenant_id,
                client_id=settings.azure_auth_client_id,
                client_secret=settings.azure_auth_client_secret,
            )
        else:
            credential = DefaultAzureCredential()

        token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")

        self._client = AzureOpenAI(
            azure_endpoint=settings.azure_openai_endpoint,
            api_version=settings.azure_openai_api_version,
            azure_ad_token_provider=token_provider,
        )
        self._deployment = settings.azure_openai_deployment
        self._max_tokens = settings.azure_openai_max_token

    def chat(self, messages: List[Dict[str, str]]) -> str:
        resp = self._client.chat.completions.create(
            model=self._deployment,
            messages=messages,
            max_tokens=self._max_tokens if self._max_tokens > 0 else None,
        )
        return resp.choices[0].message.content or ""
