from __future__ import annotations

from typing import List, Dict, Any, Optional

from teams_ai_bot.config.settings import Settings


def build_messages(
    settings: Settings,
    history_items: List[Dict[str, Any]],
    latest_user_text: str,
) -> List[Dict[str, str]]:
    messages: List[Dict[str, str]] = []

    if settings.azure_openai_system_prompt:
        messages.append({"role": "system", "content": settings.azure_openai_system_prompt})

    # DB schema: role/content per your DB spec.
    for item in history_items:
        role = item.get("role")
        content = item.get("content")
        if not role or content is None:
            continue
        messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": latest_user_text})
    return messages
