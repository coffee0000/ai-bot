from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from azure.cosmos.aio import CosmosClient
from azure.cosmos import PartitionKey

from config.settings import Settings

logger = logging.getLogger(__name__)

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

class CosmosRepository:
    def __init__(self, settings: Settings, credential) -> None:
        self._settings = settings
        self._client = CosmosClient(settings.azure_cosmosdb_endpoint, credential=credential)
        self._db = self._client.get_database_client(settings.azure_cosmosdb_database_name)
        self._c_business = self._db.get_container_client(settings.azure_cosmosdb_container_business)
        self._c_archive = self._db.get_container_client(settings.azure_cosmosdb_container_archive)

    async def warmup(self) -> None:
        # read account properties or a tiny query to ensure credentials/endpoint are OK
        try:
            await self._db.read()
        except Exception:
            logger.exception("Cosmos warmup failed")
            raise

    async def close(self) -> None:
        await self._client.close()

    # ---- conversation_history ----
    async def insert_conversation_history(self, item: dict[str, Any]) -> None:
        await self._c_business.create_item(body=item)

    async def get_conversation_history(self, conversation_id: str, limit: int) -> list[dict[str, Any]]:
        query = (
            "SELECT TOP @limit * FROM c "
            "WHERE c.schema_name = 'conversation_history' AND c.conversation_id = @conversation_id "
            "ORDER BY c.create_at DESC"
        )
        params = [
            {"name": "@limit", "value": int(limit)},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = []
        async for it in self._c_business.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            items.append(it)
        # DB からは新しい順なので、messages 構成のために古い→新しいへ戻す
        return list(reversed(items))

    async def purge_old_conversation_history(self, retention_days: int) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        cutoff_iso = cutoff.isoformat().replace("+00:00", "Z")
        query = (
            "SELECT c.id, c.conversation_id FROM c "
            "WHERE c.schema_name = 'conversation_history' AND c.create_at < @cutoff"
        )
        params = [{"name": "@cutoff", "value": cutoff_iso}]
        deleted = 0
        async for it in self._c_business.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            try:
                await self._c_business.delete_item(item=it["id"], partition_key=it.get("conversation_id"))
                deleted += 1
            except Exception:
                logger.exception("Failed to delete old history id=%s", it.get("id"))
        return deleted

    # ---- ai_processing_status ----
    async def get_ai_processing_status(self, conversation_id: str) -> dict[str, Any] | None:
        query = (
            "SELECT TOP 1 * FROM c "
            "WHERE c.schema_name = 'ai_processing_status' AND c.conversation_id = @conversation_id"
        )
        params = [{"name": "@conversation_id", "value": conversation_id}]
        async for it in self._c_business.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            return it
        return None

    async def create_ai_processing_status_if_absent(self, conversation_id: str) -> None:
        # 新規（存在しない場合のみ）
        existing = await self.get_ai_processing_status(conversation_id)
        if existing is not None:
            return
        item = {
            "id": __import__("uuid").uuid4().hex,
            "schema_name": "ai_processing_status",
            "conversation_id": conversation_id,
            "processing_flg": "0",
            "locked_at": _now_iso(),
            "create_at": _now_iso(),
        }
        await self._c_business.create_item(body=item)

    async def update_ai_processing_status(self, conversation_id: str, processing_flg: str | None = None, locked_at: str | None = None) -> None:
        item = await self.get_ai_processing_status(conversation_id)
        if item is None:
            # 仕様上は先に新規作成が走る前提だが、保険で作成
            await self.create_ai_processing_status_if_absent(conversation_id)
            item = await self.get_ai_processing_status(conversation_id)
            if item is None:
                raise RuntimeError("ai_processing_status create failed")

        if processing_flg is not None:
            item["processing_flg"] = processing_flg
        if locked_at is not None:
            item["locked_at"] = locked_at

        await self._c_business.upsert_item(body=item)

    async def delete_ai_processing_status(self, conversation_id: str) -> None:
        item = await self.get_ai_processing_status(conversation_id)
        if item is None:
            return
        await self._c_business.delete_item(item=item["id"], partition_key=item.get("conversation_id"))

    # ---- archive ----
    async def archive_conversation_history(self, items: list[dict[str, Any]]) -> None:
        # Cold Data は原則 INSERT のみ
        for it in items:
            await self._c_archive.create_item(body=it)
