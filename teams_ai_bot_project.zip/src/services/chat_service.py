from __future__ import annotations

import logging
from datetime import datetime, timezone
import uuid

from config.settings import Settings
from domain import messages as user_messages
from repositories.cosmos_repository import CosmosRepository
from services.ai_client import AzureOpenAIChatClient

logger = logging.getLogger(__name__)

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

class ChatService:
    def __init__(self, settings: Settings, repo: CosmosRepository, ai_client: AzureOpenAIChatClient) -> None:
        self._settings = settings
        self._repo = repo
        self._ai = ai_client

    async def handle_user_message(self, *, user_id: str, conversation_id: str, text: str, request_id: str) -> str:
        # ① 入力チェック
        trimmed = (text or "").strip()
        if trimmed == "":
            return user_messages.INPUT_EMPTY
        if len(trimmed) > self._settings.bot_user_input_max_length:
            return user_messages.INPUT_TOO_LONG.format(BOT_USER_INPUT_MAX_LENGTH=self._settings.bot_user_input_max_length)

        # ② 排他制御チェック
        try:
            await self._repo.create_ai_processing_status_if_absent(conversation_id)
            status = await self._repo.get_ai_processing_status(conversation_id)
        except Exception:
            logger.exception("DB error in status init")
            return user_messages.DB_ERROR.format(request_id=request_id)

        if status is not None and status.get("processing_flg") == "1":
            # timeout 判定
            locked_at = status.get("locked_at")
            try:
                locked_dt = datetime.fromisoformat(str(locked_at).replace("Z", "+00:00"))
                diff = (datetime.now(timezone.utc) - locked_dt).total_seconds()
            except Exception:
                diff = 0

            if diff <= self._settings.ai_processing_timeout_seconds:
                return user_messages.PLEASE_WAIT

            # timeout 超過 -> ロック解除して続行
            try:
                await self._repo.update_ai_processing_status(conversation_id, processing_flg="0")
            except Exception:
                logger.exception("DB error unlocking after timeout")
                return user_messages.DB_ERROR.format(request_id=request_id)

        # ③ ロック
        try:
            await self._repo.update_ai_processing_status(conversation_id, processing_flg="1", locked_at=_utc_now_iso())
        except Exception:
            logger.exception("DB error locking")
            return user_messages.DB_ERROR.format(request_id=request_id)

        try:
            # ④ 会話履歴取得（最大件数）
            history = await self._repo.get_conversation_history(conversation_id, self._settings.ai_chat_history_limit)

            # ⑤ messages 構成
            messages = []
            if self._settings.azure_openai_system_prompt.strip() != "":
                messages.append({"role": "system", "content": self._settings.azure_openai_system_prompt})

            for h in history:
                messages.append({"role": h["role"], "content": h["content"]})

            # 最新ユーザー入力
            messages.append({"role": "user", "content": trimmed})

            # ⑥ AI 呼び出し
            answer = await self._ai.chat(messages)

            # ⑦ DB 保存（user / assistant）
            now_iso = _utc_now_iso()

            user_item = {
                "id": uuid.uuid4().hex,
                "schema_name": "conversation_history",
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": uuid.uuid4().hex,
                "role": "user",
                "content": trimmed,
                "create_at": now_iso,
            }
            ai_item = {
                "id": uuid.uuid4().hex,
                "schema_name": "conversation_history",
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": uuid.uuid4().hex,
                "role": "assistant",
                "content": answer,
                "create_at": _utc_now_iso(),
            }

            await self._repo.insert_conversation_history(user_item)
            await self._repo.insert_conversation_history(ai_item)

            # ⑧ 古い履歴削除（Hot Data）
            try:
                await self._repo.purge_old_conversation_history(self._settings.chat_history_retention_days)
            except Exception:
                logger.exception("purge old history failed (non-fatal)")

            return answer

        except Exception:
            logger.exception("AI processing failed")
            return user_messages.AI_ERROR.format(request_id=request_id)

        finally:
            # ⑨ ロック解除（失敗してもユーザー応答は返す）
            try:
                await self._repo.update_ai_processing_status(conversation_id, processing_flg="0")
            except Exception:
                logger.exception("DB error unlock in finally")
