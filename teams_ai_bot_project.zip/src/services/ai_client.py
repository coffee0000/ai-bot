from __future__ import annotations

import logging
from typing import Any

from azure.identity import get_bearer_token_provider
from openai import AzureOpenAI

from config.settings import Settings

logger = logging.getLogger(__name__)

class AzureOpenAIChatClient:
    def __init__(self, settings: Settings, credential) -> None:
        self._settings = settings
        token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")
        self._client = AzureOpenAI(
            azure_endpoint=settings.azure_openai_endpoint,
            api_version=settings.azure_openai_api_version,
            azure_ad_token_provider=token_provider,
        )

    async def chat(self, messages: list[dict[str, Any]]) -> str:
        # openai sdk is sync; run in thread to keep aiohttp loop responsive
        import asyncio
        return await asyncio.to_thread(self._chat_sync, messages)

    def _chat_sync(self, messages: list[dict[str, Any]]) -> str:
        resp = self._client.chat.completions.create(
            model=self._settings.azure_openai_deployment,
            messages=messages,
            max_tokens=int(self._settings.azure_openai_max_token),
        )
        return (resp.choices[0].message.content or "").strip()
