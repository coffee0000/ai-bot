from __future__ import annotations

from azure.identity import DefaultAzureCredential, ClientSecretCredential
from config.settings import Settings

def build_azure_credential(settings: Settings):
    # 本番：Managed Identity 等を含む DefaultAzureCredential
    if not settings.dev_flg:
        return DefaultAzureCredential(exclude_interactive_browser_credential=True)

    # ローカル：ClientSecretCredential（設計書の AZURE_AUTH_* を使用）
    if not (settings.azure_auth_tenant_id and settings.azure_auth_client_id and settings.azure_auth_client_secret):
        raise ValueError("DEV_FLG=TRUE requires AZURE_AUTH_TENANT_ID / AZURE_AUTH_CLIENT_ID / AZURE_AUTH_CLIENT_SECRET")
    return ClientSecretCredential(
        tenant_id=settings.azure_auth_tenant_id,
        client_id=settings.azure_auth_client_id,
        client_secret=settings.azure_auth_client_secret,
    )
