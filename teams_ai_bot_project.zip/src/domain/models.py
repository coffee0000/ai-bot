from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime

@dataclass(frozen=True, slots=True)
class ChatMessage:
    id: str
    schema_name: str
    user_id: str
    conversation_id: str
    message_id: str
    role: str
    content: str
    create_at: str  # ISO 8601

@dataclass(frozen=True, slots=True)
class AIProcessingStatus:
    id: str
    schema_name: str
    conversation_id: str
    processing_flg: str  # "0" or "1"
    locked_at: str       # ISO 8601
    create_at: str       # ISO 8601

    def locked_since(self) -> datetime:
        return datetime.fromisoformat(self.locked_at.replace("Z", "+00:00"))
