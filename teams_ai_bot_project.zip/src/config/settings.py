from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

def _get_env(name: str, default: str | None = None) -> str:
    v = os.getenv(name)
    if v is None:
        if default is None:
            raise ValueError(f"Missing required env var: {name}")
        return str(default)
    return v

def _get_int(name: str, default: int | None = None) -> int:
    v = os.getenv(name)
    if v is None:
        if default is None:
            raise ValueError(f"Missing required env var: {name}")
        return int(default)
    return int(v)

def _get_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "t", "yes", "y")

@dataclass(frozen=True, slots=True)
class Settings:
    # --- From 環境変数設計書 ---
    ai_chat_history_limit: int
    bot_user_input_max_length: int
    ai_processing_timeout_seconds: int
    chat_history_retention_days: int

    azure_app_id: str
    azure_app_password: str

    azure_openai_system_prompt: str
    azure_openai_endpoint: str
    azure_openai_api_version: str
    azure_openai_deployment: str
    azure_openai_max_token: int

    azure_cosmosdb_endpoint: str
    azure_cosmosdb_database_name: str
    azure_cosmosdb_container_business: str
    azure_cosmosdb_container_archive: str

    dev_flg: bool
    azure_auth_tenant_id: str
    azure_auth_client_id: str
    azure_auth_client_secret: str

    # runtime
    log_level: str = "INFO"

    @staticmethod
    def from_env() -> "Settings":
        # local: allow .env (but production on App Service should not rely on it)
        load_dotenv(override=False)

        return Settings(
            ai_chat_history_limit=_get_int("AI_CHAT_HISTORY_LIMIT", 10),
            bot_user_input_max_length=_get_int("BOT_USER_INPUT_MAX_LENGTH", 2500),
            ai_processing_timeout_seconds=_get_int("AI_PROCESSING_TIMEOUT_SECONDS", 600),
            chat_history_retention_days=_get_int("CHAT_HISTORY_RETENTION_DAYS", 30),

            azure_app_id=_get_env("AZURE_APP_ID"),
            azure_app_password=_get_env("AZURE_APP_PASSWORD"),

            azure_openai_system_prompt=os.getenv("AZURE_OPENAI_SYSTEM_PROMPT", ""),
            azure_openai_endpoint=_get_env("AZURE_OPENAI_ENDPOINT"),
            azure_openai_api_version=_get_env("AZURE_OPENAI_API_VERSION"),
            azure_openai_deployment=_get_env("AZURE_OPENAI_DEPLOYMENT"),
            azure_openai_max_token=_get_int("AZURE_OPENAI_MAX_TOKEN"),

            azure_cosmosdb_endpoint=_get_env("AZURE_COSMOSDB_ENDPOINT"),
            azure_cosmosdb_database_name=_get_env("AZURE_COSMOSDB_DATABASE_NAME"),
            azure_cosmosdb_container_business=_get_env("AZURE_COSMOSDB_CONTAINER_BUSINESS"),
            azure_cosmosdb_container_archive=_get_env("AZURE_COSMOSDB_CONTAINER_ARCHIVE"),

            dev_flg=_get_bool("DEV_FLG", False),
            azure_auth_tenant_id=os.getenv("AZURE_AUTH_TENANT_ID", ""),
            azure_auth_client_id=os.getenv("AZURE_AUTH_CLIENT_ID", ""),
            azure_auth_client_secret=os.getenv("AZURE_AUTH_CLIENT_SECRET", ""),

            log_level=os.getenv("LOG_LEVEL", "INFO"),
        )
