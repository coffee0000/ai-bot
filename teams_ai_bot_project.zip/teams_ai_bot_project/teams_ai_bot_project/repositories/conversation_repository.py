\
from __future__ import annotations

from typing import Any

from teams_ai_bot_project.common.utils import new_uuid, now_utc_iso
from teams_ai_bot_project.infra.cosmos_service import CosmosService

SCHEMA_NAME_CONVERSATION_HISTORY = "conversation_history"

class ConversationRepository:
    def __init__(self, cosmos: CosmosService) -> None:
        self._cosmos = cosmos

    async def list_recent_history(self, user_id: str, conversation_id: str, limit: int) -> list[dict[str, str]]:
        # create_at desc で取得し、最終的に時系列順に並べ直す
        q = """
        SELECT TOP @limit c.role, c.content, c.create_at
        FROM c
        WHERE c.schema_name = @schema_name AND c.user_id = @user_id AND c.conversation_id = @conversation_id
        ORDER BY c.create_at DESC
        """
        params = [
            {"name": "@limit", "value": limit},
            {"name": "@schema_name", "value": SCHEMA_NAME_CONVERSATION_HISTORY},
            {"name": "@user_id", "value": user_id},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = await self._cosmos.query_items(self._cosmos.business, q, params)
        items_sorted = sorted(items, key=lambda x: x.get("create_at", ""))
        return [{"role": i["role"], "content": i["content"]} for i in items_sorted]

    async def insert_message(self, user_id: str, conversation_id: str, message_id: str, role: str, content: str) -> None:
        doc: dict[str, Any] = {
            "id": new_uuid(),
            "schema_name": SCHEMA_NAME_CONVERSATION_HISTORY,
            "user_id": user_id,
            "conversation_id": conversation_id,
            "message_id": message_id,
            "role": role,
            "content": content,
            "create_at": now_utc_iso(),
        }
        await self._cosmos.create_item(self._cosmos.business, doc)

    async def delete_old_history(self, user_id: str, retention_days: int) -> None:
        # ユーザー単位で古い履歴を削除
        q = """
        SELECT c.id, c.create_at, c.conversation_id, c.schema_name
        FROM c
        WHERE c.schema_name = @schema_name AND c.user_id = @user_id AND c.create_at <= @cutoff
        """
        import datetime
        cutoff_dt = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=retention_days)
        cutoff = cutoff_dt.isoformat()

        params = [
            {"name": "@schema_name", "value": SCHEMA_NAME_CONVERSATION_HISTORY},
            {"name": "@user_id", "value": user_id},
            {"name": "@cutoff", "value": cutoff},
        ]
        items = await self._cosmos.query_items(self._cosmos.business, q, params)
        for it in items:
            # partition key が不明なため、deleteは upsert設計時のPKに依存する。ここは best-effort.
            # 既知のパス（conversation_id / schema_name / id）で試行する。
            await _best_effort_delete(self._cosmos.business, it)

async def _best_effort_delete(container, item: dict) -> None:
    from azure.cosmos import exceptions
    item_id = item["id"]
    # よくあるパーティションキー候補で順番に試す
    candidates = [
        item.get("conversation_id"),
        item.get("schema_name"),
        item_id,
    ]
    for pk in candidates:
        if pk is None:
            continue
        try:
            await container.delete_item(item=item_id, partition_key=pk)
            return
        except exceptions.CosmosHttpResponseError:
            continue
    # 最後は例外を投げる
    await container.delete_item(item=item_id, partition_key=item_id)
