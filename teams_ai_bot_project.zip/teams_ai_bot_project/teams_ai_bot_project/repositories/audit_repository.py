\
from __future__ import annotations

from typing import Any

from teams_ai_bot_project.common.utils import new_uuid, now_utc_iso
from teams_ai_bot_project.infra.cosmos_service import CosmosService

SCHEMA_NAME_AUDIT_LOG = "audit_log"

class AuditRepository:
    def __init__(self, cosmos: CosmosService) -> None:
        self._cosmos = cosmos

    async def insert_audit(self, conversation_id: str, tokens: int | None, user_input: str, response: str) -> None:
        doc: dict[str, Any] = {
            "id": new_uuid(),
            "schema_name": SCHEMA_NAME_AUDIT_LOG,
            "conversation_id": conversation_id,
            "tokens": tokens,
            "input": user_input,
            "response": response,
            "create_at": now_utc_iso(),
        }
        await self._cosmos.create_item(self._cosmos.archive, doc)
