\
from __future__ import annotations

import uuid
from datetime import datetime, timezone

def new_uuid() -> str:
    return str(uuid.uuid4())

def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def now_utc_ts() -> float:
    return datetime.now(timezone.utc).timestamp()
