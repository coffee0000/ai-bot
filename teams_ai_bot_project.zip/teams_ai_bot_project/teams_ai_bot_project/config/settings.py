\
from __future__ import annotations

import os
from dataclasses import dataclass

def _get_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "y", "on")

def _get_int(name: str, default: int) -> int:
    v = os.getenv(name)
    if v is None or str(v).strip() == "":
        return default
    return int(v)

@dataclass(frozen=True)
class Settings:
    # Bot Framework
    AZURE_APP_ID: str
    AZURE_APP_PASSWORD: str
    AZURE_APP_TYPE: str

    # App
    DEV_FLG: bool

    # Azure Auth (local)
    AZURE_AUTH_TENANT_ID: str
    AZURE_AUTH_CLIENT_ID: str
    AZURE_AUTH_CLIENT_SECRET: str

    # Azure OpenAI
    AZURE_OPENAI_ENDPOINT: str
    AZURE_OPENAI_DEPLOYMENT: str
    AZURE_OPENAI_API_VERSION: str
    AZURE_OPENAI_SYSTEM_PROMPT: str
    AZURE_OPENAI_MAX_TOKENS: int

    # Cosmos DB
    AZURE_COSMOSDB_ENDPOINT: str
    AZURE_COSMOSDB_DATABASE_NAME: str
    AZURE_COSMOSDB_CONTAINER_BUSINESS: str
    AZURE_COSMOSDB_CONTAINER_ARCHIVE: str

    # Chat
    CHAT_HISTORY_RECORD_LIMIT: int
    CHAT_HISTORY_RETENTION_DAYS: int
    AI_PROCESSING_TIMEOUT_SECONDS: int
    MAX_TEXT_LENGTH: int

    # Logging
    LOG_LEVEL: str

    @staticmethod
    def load_from_env() -> "Settings":
        return Settings(
            AZURE_APP_ID=os.getenv("AZURE_APP_ID", ""),
            AZURE_APP_PASSWORD=os.getenv("AZURE_APP_PASSWORD", ""),
            AZURE_APP_TYPE=os.getenv("AZURE_APP_TYPE", "MultiTenant"),

            DEV_FLG=_get_bool("DEV_FLG", False),

            AZURE_AUTH_TENANT_ID=os.getenv("AZURE_AUTH_TENANT_ID", ""),
            AZURE_AUTH_CLIENT_ID=os.getenv("AZURE_AUTH_CLIENT_ID", ""),
            AZURE_AUTH_CLIENT_SECRET=os.getenv("AZURE_AUTH_CLIENT_SECRET", ""),

            AZURE_OPENAI_ENDPOINT=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            AZURE_OPENAI_DEPLOYMENT=os.getenv("AZURE_OPENAI_DEPLOYMENT", ""),
            AZURE_OPENAI_API_VERSION=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
            AZURE_OPENAI_SYSTEM_PROMPT=os.getenv("AZURE_OPENAI_SYSTEM_PROMPT", ""),
            AZURE_OPENAI_MAX_TOKENS=_get_int("AZURE_OPENAI_MAX_TOKENS", 1024),

            AZURE_COSMOSDB_ENDPOINT=os.getenv("AZURE_COSMOSDB_ENDPOINT", ""),
            AZURE_COSMOSDB_DATABASE_NAME=os.getenv("AZURE_COSMOSDB_DATABASE_NAME", ""),
            AZURE_COSMOSDB_CONTAINER_BUSINESS=os.getenv("AZURE_COSMOSDB_CONTAINER_BUSINESS", ""),
            AZURE_COSMOSDB_CONTAINER_ARCHIVE=os.getenv("AZURE_COSMOSDB_CONTAINER_ARCHIVE", ""),

            CHAT_HISTORY_RECORD_LIMIT=_get_int("CHAT_HISTORY_RECORD_LIMIT", 10),
            CHAT_HISTORY_RETENTION_DAYS=_get_int("CHAT_HISTORY_RETENTION_DAYS", 30),
            AI_PROCESSING_TIMEOUT_SECONDS=_get_int("AI_PROCESSING_TIMEOUT_SECONDS", 600),
            MAX_TEXT_LENGTH=_get_int("MAX_TEXT_LENGTH", 2000),

            LOG_LEVEL=os.getenv("LOG_LEVEL", "INFO"),
        )
