from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    HOST: str = Field(default="0.0.0.0")
    PORT: int = Field(default=8000)
    DEV_FLG: bool = Field(default=False)

    AZURE_APP_ID: str = Field(default="")
    AZURE_APP_PASSWORD: str = Field(default="")

    AZURE_AUTH_TENANT_ID: str = Field(default="")
    AZURE_AUTH_CLIENT_ID: str = Field(default="")
    AZURE_AUTH_CLIENT_SECRET: str = Field(default="")

    AZURE_OPENAI_SYSTEM_PROMPT: str = Field(default="")
    AZURE_OPENAI_ENDPOINT: str = Field(default="")
    AZURE_OPENAI_API_VERSION: str = Field(default="2024-10-21")
    AZURE_OPENAI_DEPLOYMENT: str = Field(default="")
    AZURE_OPENAI_MAX_TOKEN: int = Field(default=1024)

    AZURE_COSMOSDB_ENDPOINT: str = Field(default="")
    AZURE_COSMOSDB_DATABASE_NAME: str = Field(default="")
    AZURE_COSMOSDB_CONTAINER_BUSINESS: str = Field(default="")
    AZURE_COSMOSDB_CONTAINER_ARCHIVE: str = Field(default="")

    AI_CHAT_HISTORY_LIMIT: int = Field(default=10)
    BOT_USER_INPUT_MAX_LENGTH: int = Field(default=2500)
    AI_PROCESSING_TIMEOUT_SECONDS: int = Field(default=600)
    CHAT_HISTORY_RETENTION_DAYS: int = Field(default=30)


def get_settings() -> Settings:
    return Settings()
