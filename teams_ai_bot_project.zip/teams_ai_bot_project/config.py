from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Bot Framework
    MICROSOFT_APP_ID: str = Field(default="")
    MICROSOFT_APP_PASSWORD: str = Field(default="")
    MICROSOFT_APP_TENANT_ID: str = Field(default="")

    # Runtime
    DEV_FLG: bool = Field(default=False)

    # Azure OpenAI
    AZURE_OPENAI_ENDPOINT: str
    AZURE_OPENAI_API_VERSION: str
    AZURE_OPENAI_GPT_MODEL: str
    SYSTEM_PROMPT: str = Field(default="")

    AI_CHAT_MAX_TOKENS: int = Field(default=1024)
    AI_CHAT_TEMPERATURE: float = Field(default=0.7)
    AI_CHAT_TOP_P: float = Field(default=0.95)
    AI_CHAT_HISTORY_LIMIT: int = Field(default=10)

    # Cosmos DB
    AZURE_COSMOSDB_ENDPOINT: str
    AZURE_COSMOSDB_DB_NAME: str
    AZURE_COSMOSDB_CONTAINER_BUSINESS: str
    AZURE_COSMOSDB_CONTAINER_ARCHIVE: str

    # App logic
    BOT_USER_INPUT_MAX_LENGTH: int = Field(default=2000)
    AI_PROCESSING_TIMEOUT_SECONDS: int = Field(default=600)
    DATA_RETENTION_DAYS: int = Field(default=30)

    # Local dev (service principal) - used only if DEV_FLG=true
    AZURE_TENANT_ID: str = Field(default="")
    AZURE_CLIENT_ID: str = Field(default="")
    AZURE_CLIENT_SECRET: str = Field(default="")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


def load_settings() -> Settings:
    return Settings()  # type: ignore
