from __future__ import annotations

import uuid
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional


SCHEMA_CONVERSATION_HISTORY = "conversation_history"
SCHEMA_AI_PROCESSING_STATUS = "ai_processing_status"


def utc_iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_iso(s: str) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


class ConversationRepo:
    def __init__(self, container: object):
        self._c = container

    async def get_status(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        query = "SELECT TOP 1 * FROM c WHERE c.schema_name=@schema AND c.conversation_id=@cid"
        params = [{"name": "@schema", "value": SCHEMA_AI_PROCESSING_STATUS}, {"name": "@cid", "value": conversation_id}]
        async for item in self._c.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            return item
        return None

    async def upsert_status(self, conversation_id: str, processing_flg: str, locked_at: str) -> None:
        now = utc_iso_now()
        existing = await self.get_status(conversation_id)
        doc = existing or {
            "id": str(uuid.uuid4()),
            "schema_name": SCHEMA_AI_PROCESSING_STATUS,
            "conversation_id": conversation_id,
            "create_at": now,
        }
        doc["processing_flg"] = processing_flg
        doc["locked_at"] = locked_at
        doc["update_at"] = now
        await self._c.upsert_item(doc)

    async def list_history_desc(self, conversation_id: str, user_id: str, limit: int) -> List[Dict[str, Any]]:
        query = (
            "SELECT TOP @limit c.role, c.content, c.create_at FROM c "
            "WHERE c.schema_name=@schema AND c.conversation_id=@cid AND c.user_id=@uid "
            "ORDER BY c.create_at DESC"
        )
        params = [
            {"name": "@limit", "value": limit},
            {"name": "@schema", "value": SCHEMA_CONVERSATION_HISTORY},
            {"name": "@cid", "value": conversation_id},
            {"name": "@uid", "value": user_id},
        ]
        out: List[Dict[str, Any]] = []
        async for item in self._c.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            out.append(item)
        return out

    async def append_history(self, conversation_id: str, user_id: str, role: str, content: str) -> None:
        doc = {
            "id": str(uuid.uuid4()),
            "schema_name": SCHEMA_CONVERSATION_HISTORY,
            "user_id": user_id,
            "conversation_id": conversation_id,
            "message_id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "create_at": utc_iso_now(),
        }
        await self._c.upsert_item(doc)

    async def cleanup_old(self, conversation_id: str, user_id: str, retention_days: int) -> None:
        if retention_days <= 0:
            return
        threshold = (datetime.now(timezone.utc) - timedelta(days=retention_days)).isoformat()
        query = (
            "SELECT c.id, c.conversation_id FROM c "
            "WHERE c.schema_name=@schema AND c.conversation_id=@cid AND c.user_id=@uid AND c.create_at < @th"
        )
        params = [
            {"name": "@schema", "value": SCHEMA_CONVERSATION_HISTORY},
            {"name": "@cid", "value": conversation_id},
            {"name": "@uid", "value": user_id},
            {"name": "@th", "value": threshold},
        ]
        async for item in self._c.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            item_id = item.get("id")
            if not item_id:
                continue
            try:
                await self._c.delete_item(item=item_id, partition_key=item.get("conversation_id"))
            except Exception:
                pass


class AuditRepo:
    def __init__(self, container: object):
        self._c = container

    async def upsert_audit(self, doc: Dict[str, Any]) -> None:
        await self._c.upsert_item(doc)
