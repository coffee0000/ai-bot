from __future__ import annotations

# 画面側の固定文言は仕様に合わせて調整してください
MSG_INPUT_EMPTY = "入力内容为空，请输入正确内容。"
MSG_INPUT_TOO_LONG = "入力が長すぎます。文字数をご確認ください。"
MSG_AI_WAIT = "AI の回答を生成中です。しばらく待ってから再度お試しください。"
MSG_AI_ERROR = "当前会话的AI发生异常，请关闭当前会话重新进行聊天。"
MSG_DB_ERROR = "数据库处理过程中发生异常，请稍后再试或联系管理员。"
