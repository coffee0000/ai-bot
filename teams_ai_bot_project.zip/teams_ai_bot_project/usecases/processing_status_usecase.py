from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional, Tuple

from teams_ai_bot_project.repositories.conversation_repository import ConversationRepository
from teams_ai_bot_project.usecases.time_utils import utc_iso_now


def _parse_iso(dt_str: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
    except Exception:
        return None


class ProcessingStatusUseCase:
    def __init__(self, repo: ConversationRepository, timeout_seconds: int):
        self._repo = repo
        self._timeout_seconds = timeout_seconds

    async def can_process(self, conversation_id: str) -> Tuple[bool, bool]:
        # return: (can_process, did_timeout_unlock)
        status = await self._repo.get_ai_processing_status(conversation_id)
        if not status:
            return True, False

        flg = str(status.get("processing_flg", "0"))
        if flg != "1":
            return True, False

        locked_at = status.get("locked_at") or ""
        locked_dt = _parse_iso(locked_at)
        if not locked_dt:
            return False, False

        now = datetime.now(timezone.utc)
        diff = (now - locked_dt).total_seconds()
        if diff > self._timeout_seconds:
            # timeout -> unlock
            status["processing_flg"] = "0"
            status["locked_at"] = ""
            await self._repo.upsert_ai_processing_status(status)
            return True, True

        return False, False

    async def lock(self, conversation_id: str) -> None:
        status = await self._repo.get_ai_processing_status(conversation_id)
        if not status:
            status = {
                "id": str(uuid.uuid4()),
                "schema_name": "ai_processing_status",
                "conversation_id": conversation_id,
                "processing_flg": "1",
                "locked_at": utc_iso_now(),
                "create_at": utc_iso_now(),
            }
        else:
            status["processing_flg"] = "1"
            status["locked_at"] = utc_iso_now()
        await self._repo.upsert_ai_processing_status(status)

    async def unlock_ok(self, conversation_id: str) -> None:
        status = await self._repo.get_ai_processing_status(conversation_id)
        if not status:
            return
        status["processing_flg"] = "0"
        status["locked_at"] = ""
        await self._repo.upsert_ai_processing_status(status)

    async def unlock_error(self, conversation_id: str) -> None:
        status = await self._repo.get_ai_processing_status(conversation_id)
        if not status:
            return
        status["processing_flg"] = "-1"
        status["locked_at"] = ""
        await self._repo.upsert_ai_processing_status(status)
