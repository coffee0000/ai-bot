from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from teams_ai_bot_project.config.settings import AppSettings
from teams_ai_bot_project.repositories.auditlog_repository import AuditLogRepository
from teams_ai_bot_project.repositories.conversation_repository import ConversationRepository
from teams_ai_bot_project.usecases.time_utils import utc_iso_now

logger = logging.getLogger(__name__)


def _safe_str(v: Any) -> str:
    return "" if v is None else str(v)


def _extract_token_usage(result: Any) -> Tuple[str, str, str]:
    # langchain の戻り値構造はモデル・バージョンで変わることがあるため、取れた範囲で入れる
    prompt_tokens = ""
    completion_tokens = ""
    total_tokens = ""
    try:
        meta = getattr(result, "response_metadata", None) or {}
        usage = meta.get("token_usage") or meta.get("usage") or {}
        prompt_tokens = _safe_str(usage.get("prompt_tokens") or usage.get("input_tokens"))
        completion_tokens = _safe_str(usage.get("completion_tokens") or usage.get("output_tokens"))
        total_tokens = _safe_str(usage.get("total_tokens"))
    except Exception:
        pass
    return prompt_tokens, completion_tokens, total_tokens


class AIChatUseCase:
    def __init__(
        self,
        settings: AppSettings,
        conversation_repo: ConversationRepository,
        auditlog_repo: AuditLogRepository,
        llm: Any,
    ):
        self._settings = settings
        self._conversation_repo = conversation_repo
        self._auditlog_repo = auditlog_repo
        self._llm = llm

        # 1回の呼び出しで system + 履歴 + 入力 を組み立てる
        self._prompt = ChatPromptTemplate.from_messages(
            [
                ("system", "{system_prompt}"),
                MessagesPlaceholder("history"),
                ("human", "{user_input}"),
            ]
        )

    async def run(
        self,
        conversation_id: str,
        user_id: str,
        user_input: str,
        history_items_desc: List[Dict[str, Any]],
    ) -> str:
        # 履歴（DB は DESC で取るので、送信は ASC に戻す）
        history_items = list(reversed(history_items_desc))

        history_msgs: List[Any] = []
        for it in history_items:
            role = (it.get("role") or "").lower()
            content = it.get("content") or ""
            if role == "assistant":
                history_msgs.append(AIMessage(content=content))
            else:
                history_msgs.append(HumanMessage(content=content))

        chain_input = {
            "system_prompt": self._settings.AZURE_OPENAI_SYSTEM_PROMPT or "",
            "history": history_msgs,
            "user_input": user_input,
        }

        # LangChain で prompt -> model
        chain = self._prompt | self._llm

        # invoke（非同期）
        result = await chain.ainvoke(chain_input)
        ai_text = getattr(result, "content", None) or str(result)

        # 履歴保存（user, assistant）
        now = utc_iso_now()
        user_message_id = str(uuid.uuid4())
        ai_message_id = str(uuid.uuid4())

        await self._conversation_repo.upsert_conversation_item(
            {
                "id": str(uuid.uuid4()),
                "schema_name": "conversation_history",
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": user_message_id,
                "role": "user",
                "content": user_input,
                "create_at": now,
            }
        )
        await self._conversation_repo.upsert_conversation_item(
            {
                "id": str(uuid.uuid4()),
                "schema_name": "conversation_history",
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": ai_message_id,
                "role": "assistant",
                "content": ai_text,
                "create_at": now,
            }
        )

        # 審査ログ保存
        prompt_tokens, completion_tokens, total_tokens = _extract_token_usage(result)
        await self._auditlog_repo.upsert_auditlog_item(
            {
                "id": str(uuid.uuid4()),
                "schema_name": "conversation_auditlog",
                "create_at": now,
                "user_id": user_id,
                "conversation_id": conversation_id,
                "message_id": user_message_id,
                "question": user_input,
                "answer": ai_text,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens,
            }
        )

        return ai_text
