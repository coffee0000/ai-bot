from __future__ import annotations

import asyncio

from aiohttp import web

from .logger import setup_logging
from .config import load_settings
from .infra_credentials import create_credential
from .infra_cosmos import create_cosmos_client, get_container_clients
from .repositories import CosmosRepository
from .adapter import create_adapter
from .teams_bot import TeamsAIBot
from .app import create_web_app


setup_logging()
settings = load_settings()

# gunicorn は同期で app を要求するため、初期化を event loop で実行
async def _build() -> web.Application:
    cred = await create_credential(settings)
    cosmos = await create_cosmos_client(settings, cred)
    business, _archive = get_container_clients(cosmos, settings)
    repo = CosmosRepository(business)
    adapter = create_adapter(settings)
    bot = TeamsAIBot(settings, repo)
    return create_web_app(adapter, bot)

# aiohttp.worker.GunicornWebWorker が参照する app
app: web.Application = asyncio.get_event_loop().run_until_complete(_build())
