from __future__ import annotations

from typing import Any

from azure.identity import get_bearer_token_provider  # sync helper (token callback)
from openai import AsyncAzureOpenAI

from .config import Settings
from .infra_credentials import create_credential


AZURE_OPENAI_SCOPE = "https://cognitiveservices.azure.com/.default"


async def create_openai_client(settings: Settings) -> AsyncAzureOpenAI:
    # openai-python の Azure AD 連携（token provider）を使用
    cred = await create_credential(settings)
    token_provider = get_bearer_token_provider(cred, AZURE_OPENAI_SCOPE)  # type: ignore[arg-type]
    return AsyncAzureOpenAI(
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
        api_version=settings.AZURE_OPENAI_API_VERSION,
        azure_ad_token_provider=token_provider,
    )


async def chat_completion(settings: Settings, messages: list[dict[str, Any]]) -> str:
    client = await create_openai_client(settings)
    resp = await client.chat.completions.create(
        model=settings.AZURE_OPENAI_GPT_MODEL,  # Azure の deployment 名
        messages=messages,
        temperature=settings.AI_CHAT_TEMPERATURE,
        top_p=settings.AI_CHAT_TOP_P,
        max_tokens=settings.AI_CHAT_MAX_TOKENS,
    )
    # choices[0].message.content を返す
    try:
        return (resp.choices[0].message.content or "").strip()
    finally:
        await client.close()
