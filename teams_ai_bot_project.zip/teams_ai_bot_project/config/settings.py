from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # ローカルで .env を使うか（true のとき python-dotenv を読み込み）
    DEV_FLG: bool = Field(default=False)

    # Bot Framework（設計書の環境変数名に合わせる）
    AZURE_APP_ID: str = Field(default="")
    AZURE_APP_PASSWORD: str = Field(default="")
    AZURE_APP_TENANT_ID: str = Field(default="")

    # Azure OpenAI
    AZURE_OPENAI_ENDPOINT: str = Field(default="")
    AZURE_OPENAI_DEPLOYMENT: str = Field(default="")
    AZURE_OPENAI_API_VERSION: str = Field(default="2024-10-21")
    AZURE_OPENAI_SYSTEM_PROMPT: str = Field(default="")

    # Cosmos DB (NoSQL)
    AZURE_COSMOSDB_ENDPOINT: str = Field(default="")
    AZURE_COSMOSDB_NOSQL_DATABASE: str = Field(default="")
    AZURE_COSMOSDB_NOSQL_CONTAINER_CONVERSATION: str = Field(default="")
    AZURE_COSMOSDB_NOSQL_CONTAINER_AUDITLOG: str = Field(default="")

    # 制御
    AI_PROCESSING_TIMEOUT_SECONDS: int = Field(default=600)
    BOT_USER_INPUT_MAX_LENGTH: int = Field(default=2000)
    AI_CHAT_HISTORY_LIMIT: int = Field(default=10)
    HISTORY_RETENTION_DAYS: int = Field(default=90)
