from __future__ import annotations

import logging
import os
import sys
from datetime import datetime


def setup_logging(level: str) -> None:

    # ログディレクトリとファイル名を設定
    log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_filename = f"teams_ai_bot_project_{datetime.now().strftime('%Y%m%d')}.log"
    log_path = os.path.join(log_dir, log_filename)

    # ログをファイルに追記しつつ、コンソールにも出力
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=[logging.FileHandler(log_path, mode="a", encoding="utf-8"), logging.StreamHandler(sys.stdout)],
    )

    # Azure SDKなどの冗長なログを抑制
    noisy_loggers = [
        "azure.core.pipeline.policies.http_logging_policy",
        "azure.cosmos",
        "azure",
        "requests.packages.urllib3.connectionpool",
    ]
    for logger_name in noisy_loggers:
        logging.getLogger(logger_name).setLevel(logging.WARNING)
