from __future__ import annotations


class AppError(Exception):
    pass


class DbError(AppError):
    pass


class AiError(AppError):
    pass
