from __future__ import annotations

import logging
import re
from pathlib import Path
from types import SimpleNamespace

from aiohttp import web
from botbuilder.core import TurnContext
from botbuilder.integration.aiohttp import (
    CloudAdapter,
    ConfigurationBotFrameworkAuthentication,
    aiohttp_error_middleware,
)

from src.bot.teams_ai_bot import TeamsAIBot
from src.common.logging import setup_logging
from src.common.utils import new_uuid
from src.config.settings import Settings
from src.infra.azure_openai_service import AzureOpenAIService
from src.infra.cosmos_db_service import CosmosDBService
from src.infra.identity import build_credential
from src.repositories.audit_repository import AuditRepository
from src.repositories.conversation_repository import ConversationRepository
from src.repositories.status_repository import StatusRepository
from src.usecases.chat_usecase import ChatUsecase

logger = logging.getLogger(__name__)

SYSTEM_ERROR_MESSAGE = "システムで例外が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード：{request_id}"


RELEASE_NOTES_PATH = Path(__file__).resolve().parents[2] / "release-note.md"


def _parse_latest_release_note() -> dict | None:
    """release-note.md から最新バージョン情報を取得する。

    形式想定:

    ## vX.Y.Z - 2026-02-16
    以降、次の "## " 見出しまでが該当バージョンの説明。
    """

    try:
        text = RELEASE_NOTES_PATH.read_text(encoding="utf-8")
    except FileNotFoundError:
        logger.warning("release-note.md not found at %s", RELEASE_NOTES_PATH)
        return None
    except OSError:
        logger.exception("failed to read release-note.md at %s", RELEASE_NOTES_PATH)
        return None

    lines = text.splitlines()

    header_re = re.compile(r"^##\s+(v[0-9]+\.[0-9]+\.[0-9]+)(?:\s*-\s*(.+))?\s*$")

    version: str | None = None
    released_at: str | None = None
    body_lines: list[str] = []
    in_section = False

    for line in lines:
        m = header_re.match(line)
        if m:
            # 2 つ目以降のバージョン見出しが出てきたらループ終了
            if in_section:
                break
            version = m.group(1)
            released_at = m.group(2) if m.group(2) else None
            in_section = True
            continue

        if in_section:
            body_lines.append(line)

    if not in_section or not version:
        logger.warning("no valid version section found in release-note.md")
        return None

    # 末尾の空行をトリム
    while body_lines and body_lines[-1].strip() == "":
        body_lines.pop()

    notes = "\n".join(body_lines).strip()

    return {
        "version": version,
        "released_at": released_at,
        "notes": notes,
    }


async def _on_error(turn_context: TurnContext, error: Exception) -> None:
    """CloudAdapter 配下で補足される未処理例外の共通ハンドラー"""

    request_id = new_uuid()
    # サーバー側ログには request_id・エラー内容・コンテキスト情報を出力（スタックトレース付き）
    # CloudAdapterBase.run_pipeline 内の try/except から呼ばれるため、この時点では例外コンテキストが生きている。
    logger.exception(
        "System error request_id=%s error=%r",
        request_id,
        error,
    )

    # ユーザーには共通のシステムエラーメッセージ（request_id 付き）を返す
    await turn_context.send_activity(SYSTEM_ERROR_MESSAGE.format(request_id=request_id))


def create_app(settings: Settings) -> web.Application:
    setup_logging(settings.LOG_LEVEL)

    # Bot Framework認証の設定
    # Azure AD認証情報をセットアップ
    bf_config = SimpleNamespace(
        APP_ID=settings.AZURE_APP_ID,
        APP_PASSWORD=settings.AZURE_APP_PASSWORD,
        APP_TYPE=settings.AZURE_APP_TYPE,
        APP_TENANTID=settings.AZURE_AUTH_TENANT_ID,
    )

    # ボットアダプターの作成とエラーハンドラーの設定
    bot_framework_auth = ConfigurationBotFrameworkAuthentication(bf_config)
    adapter = CloudAdapter(bot_framework_auth)
    adapter.on_turn_error = _on_error

    # Azure認証情報の取得
    credential = build_credential(settings)

    # インフラストラクチャサービスの初期化
    # Cosmos DBとAzure OpenAIサービスのセットアップ
    cosmos_db_service = CosmosDBService(settings, credential)
    azure_openai_service = AzureOpenAIService(settings, credential)

    # リポジトリ、ユースケース、ボットの初期化
    # データベースアクセス層の設定
    conv_repo = ConversationRepository(cosmos_db_service)
    status_repo = StatusRepository(cosmos_db_service)
    audit_repo = AuditRepository(cosmos_db_service)

    # チャットユースケースの初期化
    # AIによるメッセージ処理ロジックの設定
    chat_uc = ChatUsecase(
        openai_service=azure_openai_service,
        conv_repo=conv_repo,
        status_repo=status_repo,
        audit_repo=audit_repo,
        history_limit=settings.AI_CHAT_HISTORY_LIMIT,
        retention_days=settings.CHAT_HISTORY_RETENTION_DAYS,
        timeout_seconds=settings.AI_PROCESSING_TIMEOUT_SECONDS,
    )
    # Teams AIボットの初期化
    bot = TeamsAIBot(chat_uc, settings)

    # aiohttp Webアプリケーションの作成
    # エラーミドルウェアを設定
    app = web.Application(middlewares=[aiohttp_error_middleware])
    # アプリケーションコンテキストにコンポーネントを登録
    app["adapter"] = adapter
    app["bot"] = bot
    app["cosmos"] = cosmos_db_service

    # ヘルスチェックエンドポイント
    async def health(_: web.Request) -> web.Response:
        """アプリケーションの健全性を確認するエンドポイント"""
        return web.json_response({"status": "ok"})

    # バージョン確認エンドポイント
    async def version(_: web.Request) -> web.Response:
        """現在デプロイされているアプリケーションのバージョン情報を返すエンドポイント。

        release-note.md の先頭に記載されたバージョン情報を返却する。
        """

        info = _parse_latest_release_note()
        if not info:
            return web.json_response(
                {
                    "version": None,
                    "released_at": None,
                    "notes": None,
                    "error": "release-note.md not found or invalid format",
                },
                status=500,
            )

        return web.json_response(
            {
                "version": info.get("version"),
                "released_at": info.get("released_at"),
                "notes": info.get("notes"),
                "source": "release-note.md",
            }
        )

    # メッセージ受信エンドポイント
    async def messages(req: web.Request) -> web.StreamResponse:
        """Bot Frameworkからのメッセージを処理するエンドポイント"""
        try:
            # クライアントIPアドレスとユーザーエージェント情報を取得
            xff = req.headers.get("X-Forwarded-For") or ""
            ip = xff.split(",", 1)[0].strip() or req.remote or "unknown"
            ua = req.headers.get("User-Agent") or "-"
            logger.info("INBOUND ip=%s %s %s ua=%s", ip, req.method, req.path, ua)

            # リクエスト内容（ヘッダー／ボディ）を INFO で出力する
            # LOG_LEVEL を ERROR に設定すれば、このログは出力されない
            if logger.isEnabledFor(logging.INFO):
                # センシティブなヘッダーはマスクする
                sensitive_headers = {"authorization", "cookie", "set-cookie"}
                safe_headers: dict[str, str] = {}
                for k, v in req.headers.items():
                    if k.lower() in sensitive_headers:
                        safe_headers[k] = "*****masked*****"
                    else:
                        safe_headers[k] = v

                body_text = await req.text()
                # 見やすさのため、ヘッダーとボディを別行・インデント付きで出力
                logger.info("INBOUND raw headers=\n%s", safe_headers)
                logger.info("INBOUND raw body=\n%s", body_text)

            # ボットアダプターはコンテキストから読み込む
            adapter: CloudAdapter = req.app["adapter"]
            bot: TeamsAIBot = req.app["bot"]

            # adapter.process 内部（authenticate_request や connector 作成など）で発生した例外は
            # on_turn_error では拾えないため、ここで一括ログ出力し、HTTP レスポンスとしても
            # システムエラーを返してチャネル側に即座に通知する
            logger.info("******* Teams AI Bot 非同期処理 started *******")
            resp = await adapter.process(req, bot)
            logger.info("******* Teams AI Bot 非同期処理 finished *******")
            return resp

        except Exception:
            request_id = new_uuid()
            logger.exception(
                "adapter.process failed request_id=%s method=%s path=%s",
                request_id,
                req.method,
                req.path,
            )
            # TurnContext がまだ生成されていないため、ここからユーザーに
            # 通常のメッセージ（Activity）を送ることはできない。
            # 代わりに、Bot Framework Service に対して 500 とエラーメッセージを返すことで、
            # チャネル側には「ボットがエラーになった」という扱いで伝わる。
            return web.json_response(
                {"error": SYSTEM_ERROR_MESSAGE.format(request_id=request_id)},
                status=500,
            )

    app.router.add_get("/health", health)
    app.router.add_get("/version", version)
    app.router.add_post("/api/messages", messages)

    # アプリケーション起動時の処理
    async def on_startup(app_: web.Application) -> None:
        # Cosmos DBへの接続を開く
        await app_["cosmos"].open()

    # アプリケーション終了時の処理
    async def on_cleanup(app_: web.Application) -> None:
        # Cosmos DBへの接続を閉じる
        await app_["cosmos"].close()

    # 起動イベントハンドラーを登録
    app.on_startup.append(on_startup)
    # クリーンアップイベントハンドラーを登録
    app.on_cleanup.append(on_cleanup)
    return app
