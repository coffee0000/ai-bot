from __future__ import annotations

import logging

from botbuilder.core import ActivityHandler, TurnContext
from botbuilder.schema import Activity, ActivityTypes, ChannelAccount

from src.config.settings import Settings
from src.usecases.chat_usecase import ChatUsecase

logger = logging.getLogger(__name__)

EMPTY_INPUT_MESSAGE = "入力内容が空です。正しい内容を入力してください。"
MAX_INPUT_MESSAGE = "最大文字数：{max_len} 以内で入力してください。"
GENERATING_MESSAGE = "AIの回答を生成しています。しばらくお待ちください。"


class TeamsAIBot(ActivityHandler):
    def __init__(self, chat_usecase: ChatUsecase, settings: Settings) -> None:
        self._chat = chat_usecase
        self._max_len = settings.BOT_USER_INPUT_MAX_LENGTH
        self._welcome_message = settings.TEAMS_AI_BOT_WELCOME_MESSAGE

    async def on_members_added_activity(self, members_added: list[ChannelAccount], turn_context: TurnContext):
        for member in members_added:
            if member.id != turn_context.activity.recipient.id:
                logger.info("******* Teams AI Bot 案内メッセージ返却 started *******")
                await turn_context.send_activity(self._welcome_message)
                logger.info("******* Teams AI Bot 案内メッセージ返却 finished *******")

    async def on_message_activity(self, turn_context: TurnContext) -> None:
        user: ChannelAccount | None = turn_context.activity.from_property
        conversation = turn_context.activity.conversation

        user_id = user.id if user else ""
        conversation_id = conversation.id if conversation else ""

        text = (turn_context.activity.text or "").strip()

        if text == "":
            await turn_context.send_activity(EMPTY_INPUT_MESSAGE)
            return

        if len(text) > self._max_len:
            await turn_context.send_activity(MAX_INPUT_MESSAGE.format(max_len=self._max_len))
            return

        # 先にユーザーへ「AI 正在生成回答」メッセージを返し、その同じ Activity を後で更新する
        placeholder_response = await turn_context.send_activity(GENERATING_MESSAGE)

        # AI からの実際の回答を取得
        result = await self._chat.handle(user_id=user_id, conversation_id=conversation_id, user_text=text)

        # 取得した回答で、先ほど送信したメッセージを更新
        try:
            updated_activity = Activity(
                id=getattr(placeholder_response, "id", None),
                type=ActivityTypes.message,
                text=result.message,
                channel_id=turn_context.activity.channel_id,
                conversation=turn_context.activity.conversation,
                # from_property: Bot を送信者として設定（元の recipient）
                from_property=turn_context.activity.recipient,
                # recipient: ユーザーを受信者として設定（元の from_property）
                recipient=turn_context.activity.from_property,
                service_url=turn_context.activity.service_url,
            )
            logger.info("******* Teams AI Bot メッセージ更新: AI回答内容返却 started *******")
            await turn_context.update_activity(updated_activity)
            logger.info("******* Teams AI Bot メッセージ更新: AI回答内容返却 finished *******")
        except Exception:
            # もし更新に失敗した場合は、フォールバックとして通常のメッセージ送信を行う
            logger.exception("メッセージ更新に失敗しました。代わりに新しいメッセージを送信します。")
            await turn_context.send_activity(result.message)
