from __future__ import annotations

from typing import Any

from src.common.utils import new_uuid, now_utc_iso
from src.infra.cosmos_db_service import CosmosDBService

SCHEMA_NAME_CONVERSATION_HISTORY = "conversation_history"


class ConversationRepository:
    def __init__(self, cosmos: CosmosDBService) -> None:
        self._cosmos = cosmos

    async def list_recent_history(self, user_id: str, conversation_id: str, limit: int) -> list[dict[str, str]]:
        # create_at desc で取得し、最終的に時系列順に並べ直す
        q = """
        SELECT TOP @limit c.role, c.content, c.create_at
        FROM c
        WHERE c.schema_name = @schema_name AND c.user_id = @user_id AND c.conversation_id = @conversation_id
        ORDER BY c.create_at DESC
        """
        params = [
            {"name": "@limit", "value": limit},
            {"name": "@schema_name", "value": SCHEMA_NAME_CONVERSATION_HISTORY},
            {"name": "@user_id", "value": user_id},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = await self._cosmos.query_items(self._cosmos.business, q, params)
        items_sorted = sorted(items, key=lambda x: x.get("create_at", ""))
        return [{"role": i["role"], "content": i["content"]} for i in items_sorted]

    async def insert_message(
        self, user_id: str, conversation_id: str, message_id: str, role: str, content: str
    ) -> None:
        doc: dict[str, Any] = {
            "id": new_uuid(),
            "schema_name": SCHEMA_NAME_CONVERSATION_HISTORY,
            "user_id": user_id,
            "conversation_id": conversation_id,
            "message_id": message_id,
            "role": role,
            "content": content,
            "create_at": now_utc_iso(),
        }
        await self._cosmos.create_item(self._cosmos.business, doc)

    async def delete_old_history(self, user_id: str, retention_days: int) -> None:
        """
        指定したユーザーの古い会話履歴を削除します。
        `retention_days` 日より前の `conversation_history` レコードが対象です。

        Args:
            user_id: ユーザーID
            retention_days: 保持日数
        """
        import datetime

        # カットオフ日時を計算
        cutoff_dt = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=retention_days)
        cutoff = cutoff_dt.isoformat()

        # 期限切れの会話履歴を検索
        sql = """
        SELECT c.id, c.create_at, c.user_id, c.conversation_id, c.schema_name
        FROM c
        WHERE c.schema_name = @schema_name AND c.user_id = @user_id AND c.create_at <= @cutoff
        """
        params = [
            {"name": "@schema_name", "value": SCHEMA_NAME_CONVERSATION_HISTORY},
            {"name": "@user_id", "value": user_id},
            {"name": "@cutoff", "value": cutoff},
        ]
        items = await self._cosmos.query_items(self._cosmos.business, sql, params)

        # コンテナのパーティションキーを取得（環境変数で設定）
        partition_key = self._cosmos.business_partition_key

        # 並行削除（複数アイテムを同時削除して効率向上）
        delete_list = [(item["id"], item.get(partition_key)) for item in items]
        await self._cosmos.delete_items_batch(self._cosmos.business, delete_list)
