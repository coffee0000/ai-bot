from __future__ import annotations

from typing import Any

from src.common.utils import new_uuid, now_utc_iso
from src.infra.cosmos_db_service import CosmosDBService


class AuditRepository:
    def __init__(self, cosmos: CosmosDBService) -> None:
        self._cosmos = cosmos

    async def insert_audit(self, user: str, tokens: int | None, user_input: str, response: str) -> None:
        doc: dict[str, Any] = {
            "id": new_uuid(),
            "approach": "chat",
            "user": user,
            "tokens": tokens,
            "input": user_input,
            "response": response,
        }
        await self._cosmos.create_item(self._cosmos.archive, doc)
