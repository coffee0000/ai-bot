from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from azure.identity import get_bearer_token_provider
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import Runnable
from langchain_openai import AzureChatOpenAI

from src.config.settings import Settings


@dataclass(frozen=True)
class AiResponse:
    content: str
    response_metadata: dict[str, Any]
    id: str
    usage_metadata: dict[str, Any]


class AzureOpenAIService:
    """Azure OpenAI 呼び出し（LangChain 経由）

    - 認証: azure.identity の credential から token provider を作って AzureChatOpenAI に渡す
    - Prompt: system + history + user input を ChatPromptTemplate で構成
    - 実行: chain.invoke(...) を呼び出す（呼び出し側は to_thread で非同期化）
    """

    def __init__(self, settings: Settings, credential) -> None:
        token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")

        self._deployment = settings.AZURE_OPENAI_DEPLOYMENT
        self._max_tokens = settings.AZURE_OPENAI_MAX_TOKENS
        self._system_prompt = settings.AZURE_OPENAI_SYSTEM_PROMPT

        # HTTP リクエスト超時（DB の処理超時より 10 秒短く設定）
        ai_request_timeout = max(settings.AI_PROCESSING_TIMEOUT_SECONDS - 10, 10)

        # LLM (LangChain)
        self._llm = AzureChatOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_deployment=self._deployment,
            azure_ad_token_provider=token_provider,
            max_tokens=self._max_tokens,
            timeout=ai_request_timeout,
        )

        # Prompt: system + history + input
        self._prompt = ChatPromptTemplate.from_messages(
            [
                ("system", self._system_prompt),
                MessagesPlaceholder("history"),
                ("human", "{input}"),
            ]
        )

        # Chain: prompt | llm
        self._chain: Runnable = self._prompt | self._llm

    def _to_history_messages(self, history: list[dict[str, str]]) -> list[BaseMessage]:
        """DB の履歴（role/content）を LangChain の messages に変換する。
        想定 role: user / assistant（それ以外は user 扱い）
        """
        lc: list[BaseMessage] = []
        for h in history:
            role = (h.get("role") or "").strip().lower()
            content = h.get("content") or ""
            if role == "assistant":
                lc.append(AIMessage(content=content))
            else:
                lc.append(HumanMessage(content=content))
        return lc

    def build_messages(self, history: list[dict[str, str]], user_text: str) -> list[dict[str, str]]:
        """既存ロジック互換のために残す：system + history + user を dict で返す。
        ※呼び出し側のロジックを変えないための互換 API。
        """
        messages: list[dict[str, str]] = []
        if self._system_prompt:
            messages.append({"role": "system", "content": self._system_prompt})
        for h in history:
            messages.append({"role": h["role"], "content": h["content"]})
        messages.append({"role": "user", "content": user_text})
        return messages

    def chat(self, messages: list[dict[str, str]]) -> AiResponse:
        """LangChain chain.invoke で実行し、AiResponse に整形して返す（同期）。"""
        # messages から system / history / input を復元
        history_dicts: list[dict[str, str]] = []
        user_text = ""
        for m in messages:
            role = (m.get("role") or "").strip().lower()
            if role == "system":
                # system は初期化時に固定（settings）で入れているので、ここでは無視
                continue
            if role == "user":
                user_text = m.get("content") or ""
            else:
                history_dicts.append({"role": role, "content": m.get("content") or ""})

        lc_history = self._to_history_messages(history_dicts)

        # invoke
        result: AIMessage = self._chain.invoke({"history": lc_history, "input": user_text})

        # content
        content = getattr(result, "content", "") or ""

        # metadata / usage
        response_meta = {}
        usage_meta = {}
        run_id = ""

        # LangChain message has response_metadata in .response_metadata (dict) on many integrations
        rm = getattr(result, "response_metadata", None)
        if isinstance(rm, dict):
            response_meta = rm

            # try extract usage
            usage = rm.get("token_usage") or rm.get("usage") or rm.get("usage_metadata")
            if isinstance(usage, dict):
                usage_meta = {
                    "prompt_tokens": usage.get("prompt_tokens"),
                    "completion_tokens": usage.get("completion_tokens"),
                    "total_tokens": usage.get("total_tokens"),
                }

            # sometimes id / model are in response_metadata
            run_id = str(rm.get("id") or rm.get("request_id") or "")

        return AiResponse(
            content=content,
            response_metadata=response_meta,
            id=run_id,
            usage_metadata=usage_meta,
        )
