from __future__ import annotations

from azure.identity.aio import DefaultAzureCredential, ClientSecretCredential
from azure.core.credentials_async import AsyncTokenCredential

from .config import Settings


async def create_credential(settings: Settings) -> AsyncTokenCredential:
    # ローカル開発（Service Principal）
    if settings.DEV_FLG:
        return ClientSecretCredential(
            tenant_id=settings.AZURE_TENANT_ID,
            client_id=settings.AZURE_CLIENT_ID,
            client_secret=settings.AZURE_CLIENT_SECRET,
        )
    # 本番（App Service 等）: Managed Identity を含む
    return DefaultAzureCredential()
