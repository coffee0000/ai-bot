#!/usr/bin/env bash
# Azure App Service (Linux) startup.sh
# export NO_PROXY=.documents.azure.com,.openai.azure.com
# export SSL_CERT_FILE=/home/site/wwwroot/cert/ca-bundle.crt
# export REQUESTS_CA_BUNDLE=/home/site/wwwroot/cert/ca-bundle.crt

cat /etc/ssl/certs/ca-certificates.crt /home/site/wwwroot/cert/yw1385757.crt > /home/site/wwwroot/cert/ca-bundle.crt

APP_DIR="/home/site/wwwroot"
VENV_DIR="${APP_DIR}/.venv"

echo "[START] PWD=$(pwd)"
echo "[START] System Python=$(python --version 2>&1 || true)"
echo "[START] PORT=${PORT:-not set}"

cd "$APP_DIR" || exit 1

# 1) venv が存在しない場合のみ作成する（再起動時は再作成しない）
if [ -d "$VENV_DIR" ] && [ -x "$VENV_DIR/bin/python" ]; then
    echo "[INFO] venv already exists and is valid. Skipping venv creation."
else
    echo "[WARN] venv is missing or broken. Recreating venv..."
    rm -rf "$VENV_DIR"
    python -m venv "$VENV_DIR" || exit 1
fi

# 2) 依存関係をインストール
"$VENV_DIR/bin/python" -m pip install --upgrade pip
"$VENV_DIR/bin/pip" install -r requirements.txt || exit 1

# 3) アプリケーション起動（app.py に app オブジェクトが存在する前提）
exec "$VENV_DIR/bin/gunicorn" app:app --worker-class aiohttp.GunicornWebWorker --workers 2 --timeout 300 --graceful-timeout 30 --bind "0.0.0.0:${PORT}"