from __future__ import annotations

from typing import Any, Dict

class AuditLogRepository:
    def __init__(self, container: object):
        self._container = container

    async def upsert_auditlog_item(self, item: Dict[str, Any]) -> None:
        await self._container.upsert_item(item)
