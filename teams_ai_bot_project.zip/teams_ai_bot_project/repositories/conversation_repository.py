from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _utc_iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ConversationRepository:
    def __init__(self, container: object):
        self._container = container

    async def upsert_conversation_item(self, item: Dict[str, Any]) -> None:
        await self._container.upsert_item(item)

    async def query_conversation_history(
        self,
        conversation_id: str,
        user_id: str,
        limit: int,
    ) -> List[Dict[str, Any]]:
        # create_at は ISO 8601 文字列（昇順・降順の比較が可能）
        query = (
            "SELECT TOP @limit * FROM c "
            "WHERE c.schema_name = 'conversation_history' "
            "AND c.conversation_id = @conversation_id "
            "AND c.user_id = @user_id "
            "ORDER BY c.create_at DESC"
        )
        params = [
            {"name": "@limit", "value": limit},
            {"name": "@conversation_id", "value": conversation_id},
            {"name": "@user_id", "value": user_id},
        ]
        items = []
        async for i in self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            items.append(i)
        return items

    async def get_ai_processing_status(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        query = (
            "SELECT TOP 1 * FROM c "
            "WHERE c.schema_name = 'ai_processing_status' "
            "AND c.conversation_id = @conversation_id"
        )
        params = [{"name": "@conversation_id", "value": conversation_id}]
        async for i in self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            return i
        return None

    async def upsert_ai_processing_status(self, status_item: Dict[str, Any]) -> None:
        await self._container.upsert_item(status_item)

    async def cleanup_old_history(self, conversation_id: str, user_id: str, retention_days: int) -> None:
        if retention_days <= 0:
            return
        threshold = datetime.now(timezone.utc) - timedelta(days=retention_days)
        threshold_iso = threshold.isoformat()

        # 古い履歴を取得（必要最低限の項目）
        query = (
            "SELECT c.id, c.conversation_id, c.user_id, c.schema_name, c.create_at "
            "FROM c WHERE c.schema_name = 'conversation_history' "
            "AND c.conversation_id = @conversation_id "
            "AND c.user_id = @user_id "
            "AND c.create_at < @threshold"
        )
        params = [
            {"name": "@conversation_id", "value": conversation_id},
            {"name": "@user_id", "value": user_id},
            {"name": "@threshold", "value": threshold_iso},
        ]

        old_items = []
        async for i in self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            old_items.append(i)

        # partition key が設計書で明示されていないため、消せる範囲で削除を試行
        for it in old_items:
            item_id = it.get("id")
            if not item_id:
                continue
            for pk in (conversation_id, user_id, item_id):
                try:
                    await self._container.delete_item(item=item_id, partition_key=pk)
                    break
                except Exception:
                    continue
