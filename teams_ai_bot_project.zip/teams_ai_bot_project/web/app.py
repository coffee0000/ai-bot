from __future__ import annotations

import logging
import os
from aiohttp import web
from botbuilder.core import BotFrameworkAdapterSettings, TurnContext
from botbuilder.integration.aiohttp import BotFrameworkHttpAdapter, aiohttp_error_middleware

from teams_ai_bot_project.config.settings import AppSettings
from teams_ai_bot_project.infra.azure_openai import build_llm
from teams_ai_bot_project.infra.cosmos import build_cosmos_resources
from teams_ai_bot_project.repositories.conversation_repository import ConversationRepository
from teams_ai_bot_project.repositories.auditlog_repository import AuditLogRepository
from teams_ai_bot_project.bot.ai_chat_bot import AIChatBot

logger = logging.getLogger(__name__)


async def create_app(settings: AppSettings) -> web.Application:
    # Adapter（Bot Framework SDK が JWT 検証を実施）
    adapter_settings = BotFrameworkAdapterSettings(
        app_id=settings.AZURE_APP_ID,
        app_password=settings.AZURE_APP_PASSWORD,
    )
    adapter = BotFrameworkHttpAdapter(adapter_settings)

    async def on_error(context: TurnContext, error: Exception):
        logger.exception("Bot error: %s", error)
        await context.send_activity("システムエラーが発生しました。")

    adapter.on_turn_error = on_error

    # Azure resources
    cosmos = await build_cosmos_resources(settings)
    llm = build_llm(settings)

    conv_repo = ConversationRepository(cosmos.conversation_container)
    audit_repo = AuditLogRepository(cosmos.auditlog_container)

    bot = AIChatBot(settings=settings, conversation_repo=conv_repo, auditlog_repo=audit_repo, llm=llm)

    app = web.Application(middlewares=[aiohttp_error_middleware])

    async def messages(req: web.Request) -> web.Response:
        return await adapter.process(req, bot)

    app.router.add_post("/api/messages", messages)

    # graceful shutdown
    async def on_cleanup(app_: web.Application):
        try:
            await cosmos.client.close()
        except Exception:
            pass

    app.on_cleanup.append(on_cleanup)
    return app
