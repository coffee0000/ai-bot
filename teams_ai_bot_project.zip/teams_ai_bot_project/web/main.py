from __future__ import annotations

import asyncio
import logging
import os
from aiohttp import web
from dotenv import load_dotenv

from teams_ai_bot_project.config.settings import AppSettings
from teams_ai_bot_project.infra.logging import setup_logging
from teams_ai_bot_project.web.app import create_app


def _load_env_if_needed(settings: AppSettings) -> None:
    if settings.DEV_FLG:
        load_dotenv(override=False)


def main() -> None:
    setup_logging()
    settings = AppSettings()
    _load_env_if_needed(settings)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    app = loop.run_until_complete(create_app(settings))

    port = int(os.getenv("PORT", "8000"))
    web.run_app(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
