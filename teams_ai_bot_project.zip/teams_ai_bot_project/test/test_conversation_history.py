from __future__ import annotations

import asyncio

from src.config.settings import Settings
from src.infra.cosmos_db_service import CosmosDBService
from src.infra.identity import build_credential
from src.repositories.conversation_repository import SCHEMA_NAME_CONVERSATION_HISTORY


async def fetch_conversation_history(cosmos: CosmosDBService) -> None:
    """conversation_history の全データを取得し、コンソールに出力する。"""
    query = """
    SELECT c.id, c.user_id, c.conversation_id, c.message_id, c.role, c.content, c.create_at
    FROM c
    WHERE c.schema_name = @schema_name
    ORDER BY c.create_at DESC
    """
    params = [{"name": "@schema_name", "value": SCHEMA_NAME_CONVERSATION_HISTORY}]

    items = await cosmos.query_items(cosmos.business, query, params)

    print(f"[conversation_history] count={len(items)}")
    for item in items:
        print(item)


async def clear_conversation_history(cosmos: CosmosDBService) -> None:
    """すべての conversation_history データを削除する。"""
    query = """
    SELECT c.id, c.user_id, c.conversation_id, c.schema_name
    FROM c
    WHERE c.schema_name = @schema_name
    """
    params = [{"name": "@schema_name", "value": SCHEMA_NAME_CONVERSATION_HISTORY}]

    items = await cosmos.query_items(cosmos.business, query, params)

    if not items:
        print("[conversation_history] no items to delete")
        return

    partition_key_name = cosmos.business_partition_key
    delete_list = [(item["id"], item.get(partition_key_name)) for item in items]

    await cosmos.delete_items_batch(cosmos.business, delete_list)
    print(f"[conversation_history] deleted {len(delete_list)} items")


async def main() -> None:
    # 環境変数から設定を読み込む（ローカル開発では .env / 環境変数を事前に設定しておく）
    settings = Settings.load_from_env()
    credential = build_credential(settings)

    cosmos = CosmosDBService(settings, credential)
    await cosmos.open()
    try:
        # デフォルトでは取得して出力するだけ
        await fetch_conversation_history(cosmos)

        # データを全削除したい場合は、内容を確認のうえ次の行のコメントアウトを外す
        # await clear_conversation_history(cosmos)
    finally:
        await cosmos.close()


if __name__ == "__main__":
    asyncio.run(main())
