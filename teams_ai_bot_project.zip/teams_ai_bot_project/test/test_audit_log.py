from __future__ import annotations

import asyncio

from src.config.settings import Settings
from src.infra.cosmos_db_service import CosmosDBService
from src.infra.identity import build_credential


async def fetch_audit_log(cosmos: CosmosDBService) -> None:
    """audit_log の全データを取得し、コンソールに出力する。"""
    query = """
    SELECT c.id, c.user, c.tokens, c.input, c.response, c.approach
    FROM c
    WHERE c.approach = @approach
    ORDER BY c.id DESC
    """
    params: list[dict[str, str]] = [{"name": "@approach", "value": "chat"}]

    items = await cosmos.query_items(cosmos.archive, query, params)

    print(f"[audit_log] count={len(items)}")
    for item in items:
        print(item)


async def clear_audit_log(cosmos: CosmosDBService) -> None:
    """すべての audit_log データを削除する。"""
    query = """
    SELECT c.id, c.user, c.approach
    FROM c
    WHERE c.approach = @approach
    """
    params: list[dict[str, str]] = [{"name": "@approach", "value": "chat"}]

    items = await cosmos.query_items(cosmos.archive, query, params)

    if not items:
        print("[audit_log] no items to delete")
        return

    partition_key_name = cosmos.archive_partition_key
    delete_list = [(item["id"], item.get(partition_key_name)) for item in items]

    await cosmos.delete_items_batch(cosmos.archive, delete_list)
    print(f"[audit_log] deleted {len(delete_list)} items")


async def main() -> None:
    # 環境変数から設定を読み込む（ローカル開発では .env / 環境変数を事前に設定しておく）
    settings = Settings.load_from_env()
    credential = build_credential(settings)

    cosmos = CosmosDBService(settings, credential)
    await cosmos.open()
    try:
        # デフォルトでは取得して出力するだけ
        await fetch_audit_log(cosmos)

        # データを全削除したい場合は、内容を確認のうえ次の行のコメントアウトを外す
        # await clear_audit_log(cosmos)
    finally:
        await cosmos.close()


if __name__ == "__main__":
    asyncio.run(main())
