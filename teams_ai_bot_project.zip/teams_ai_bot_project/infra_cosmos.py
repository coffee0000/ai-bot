from __future__ import annotations

from azure.cosmos.aio import CosmosClient
from azure.cosmos import PartitionKey
from azure.core.credentials_async import AsyncTokenCredential

from .config import Settings


async def create_cosmos_client(settings: Settings, credential: AsyncTokenCredential) -> CosmosClient:
    return CosmosClient(url=settings.AZURE_COSMOSDB_ENDPOINT, credential=credential)


def get_container_clients(client: CosmosClient, settings: Settings):
    db = client.get_database_client(settings.AZURE_COSMOSDB_DB_NAME)
    business = db.get_container_client(settings.AZURE_COSMOSDB_CONTAINER_BUSINESS)
    archive = db.get_container_client(settings.AZURE_COSMOSDB_CONTAINER_ARCHIVE)
    return business, archive
