## Teams AI Bot Project

Microsoft Teams 向けのチャットボットを、Azure OpenAI / Azure Cosmos DB 上で動作させるための Python プロジェクトです。
aiohttp と Bot Framework SDK for Python を利用し、シンプルな構成で安全にデプロイできることを目的としています。

---

### 主な機能

- Teams チャット経由で Azure OpenAI を利用した対話型応答
- 会話履歴・処理ステータス・監査ログを Azure Cosmos DB に永続化
- Pydantic v2 による型安全な設定管理
- LangChain 経由の Azure OpenAI 呼び出し（タイムアウト・トークン使用量取得対応）
- 日次ローテーションによるアプリケーションログ出力（logs ディレクトリ）

---

### アーキテクチャ概要

- エントリポイント: `app.py`
  - 環境変数から Settings を構築し、`create_app` で aiohttp アプリを生成
- Web / Bot 統合: `src/web/app_factory.py`
  - Bot Framework `CloudAdapter` + `ConfigurationBotFrameworkAuthentication`
  - エンドポイント: `/health`, `/version`, `/api/messages`
- Bot 実装: `src/bot/teams_ai_bot.py`
  - `ActivityHandler` 継承の Teams ボット本体
  - 入力バリデーション（空文字・最大長など）
- ユースケース層: `src/usecases/chat_usecase.py`
  - 会話履歴・AI 処理ステータスの管理と排他制御
  - Azure OpenAI 呼び出しと結果保存・監査ログの記録
- インフラ層: `src/infra`
  - Azure OpenAI / Cosmos DB / 認証関連のクライアント実装
- リポジトリ層: `src/repositories`
  - 会話履歴・ステータス・監査ログの CRUD をカプセル化

---

### ローカル開発手順

#### 前提条件

- Python 3.x
- Azure Bot 登録済み（Teams チャネル有効）
- Azure OpenAI リソース（チャットモデルをデプロイ済み）
- Azure Cosmos DB（Database / Containers 作成済み）

#### セットアップ

1. 仮想環境を作成し、有効化する
2. `pip install -r requirements.txt` を実行し依存関係をインストール
3. `.env.sample` をコピーして `.env` を作成し、環境変数を設定する
4. アプリケーションを起動: `python app.py`

デフォルトでは `http://localhost:3978` で起動し、Bot Framework からのメッセージは
`POST /api/messages` に送信されます。

---

### 環境変数 (.env) 概要

詳細は `.env.sample` を参照してください。主な項目は以下です。

- Bot 設定
  - `AZURE_APP_ID`, `AZURE_APP_PASSWORD`, `AZURE_APP_TYPE`
- アプリ共通
  - `DEV_FLG`（ローカル開発フラグ）
- チャット設定
  - `TEAMS_AI_BOT_WELCOME_MESSAGE`, `CHAT_HISTORY_RECORD_LIMIT`, `MAX_TEXT_LENGTH` など
- Azure OpenAI
  - `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DEPLOYMENT`, `AZURE_OPENAI_API_VERSION` など
- Cosmos DB
  - `AZURE_COSMOSDB_ENDPOINT`, `AZURE_COSMOSDB_DATABASE_NAME`, コンテナ名・パーティションキー
- Azure 認証（ローカル開発用）
  - `AZURE_AUTH_TENANT_ID`, `AZURE_AUTH_CLIENT_ID`, `AZURE_AUTH_CLIENT_SECRET`
- ログ
  - `LOG_LEVEL`

---

### ロギング

- 出力先: プロジェクトルート配下の `logs` ディレクトリ
- ログローテーション: 日次ローテーション
- ログレベル: 環境変数 `LOG_LEVEL`（デフォルト: `INFO` を想定）

---

### デプロイ (Azure App Service / Zip Deploy 想定)

- 依存関係は `requirements.txt` にピン留め（Zip Deploy 前提）
- スタートアップコマンド例: `python app.py`
- App Service のアプリ設定に `.env` と同等の環境変数を登録
- Bot の Messaging endpoint 例: `https://<app-name>.azurewebsites.net/api/messages`

---

### プロジェクト構成 (概要)

- `app.py` — エントリポイント / aiohttp アプリ起動
- `src/web/app_factory.py` — Web アプリ・Bot アダプター・DI 構成
- `src/bot/teams_ai_bot.py` — Teams ボット実装
- `src/usecases/chat_usecase.py` — 会話ロジック & AI 呼び出し
- `src/infra` — Azure OpenAI / Cosmos DB / 認証
- `src/repositories` — DB アクセス層
- `src/common` — ログ・共通エラー・ユーティリティ
