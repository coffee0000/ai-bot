# teams_ai_bot_project

Python 3.14 / aiohttp / Bot Framework SDK (Python)

## Entry
- `app.py`

## Azure App Service (Zip Deploy)
- `requirements.txt` is pinned (no dynamic install).
- Start command example:
  - `python app.py`
