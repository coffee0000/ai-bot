from __future__ import annotations

import logging
from botbuilder.core import TurnContext
from botbuilder.integration.aiohttp import BotFrameworkHttpAdapter, BotFrameworkAdapterSettings

logger = logging.getLogger(__name__)


def create_adapter(app_id: str, app_password: str) -> BotFrameworkHttpAdapter:
    settings = BotFrameworkAdapterSettings(app_id, app_password)
    adapter = BotFrameworkHttpAdapter(settings)

    async def on_error(context: TurnContext, error: Exception) -> None:
        logger.exception("Bot error: %s", error)
        await context.send_activity("系统错误，请稍后再试或联系管理员。")

    adapter.on_turn_error = on_error
    return adapter
