from __future__ import annotations

import datetime
import uuid
from typing import Any, Iterable

from azure.cosmos.aio import ContainerProxy
from azure.cosmos import exceptions as cosmos_exceptions


SCHEMA_CONVERSATION_HISTORY = "conversation_history"
SCHEMA_AI_PROCESSING_STATUS = "ai_processing_status"


def _utc_now() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


def _utc_iso(dt: datetime.datetime) -> str:
    return dt.astimezone(datetime.timezone.utc).isoformat()


def _parse_dt(value: str | None) -> datetime.datetime | None:
    if not value:
        return None
    try:
        return datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


class CosmosRepository:
    def __init__(self, business_container: ContainerProxy):
        self._c = business_container

    async def get_processing_status(self, user_id: str, conversation_id: str) -> dict[str, Any] | None:
        query = (
            "SELECT TOP 1 * FROM c "
            "WHERE c.schema_name=@schema_name AND c.user_id=@user_id AND c.conversation_id=@conversation_id "
            "ORDER BY c.update_at DESC"
        )
        params = [
            {"name": "@schema_name", "value": SCHEMA_AI_PROCESSING_STATUS},
            {"name": "@user_id", "value": user_id},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = self._c.query_items(query=query, parameters=params, enable_cross_partition_query=True)
        async for item in items:
            return item
        return None

    async def upsert_processing_status(
        self,
        user_id: str,
        conversation_id: str,
        processing_flg: str,
        locked_at: str | None,
    ) -> dict[str, Any]:
        now = _utc_now()
        existing = await self.get_processing_status(user_id, conversation_id)
        doc = existing or {
            "id": str(uuid.uuid4()),
            "schema_name": SCHEMA_AI_PROCESSING_STATUS,
            "user_id": user_id,
            "conversation_id": conversation_id,
            "create_at": _utc_iso(now),
        }
        doc["processing_flg"] = processing_flg
        doc["locked_at"] = locked_at or ""
        doc["update_at"] = _utc_iso(now)
        return await self._c.upsert_item(doc)

    async def insert_history(
        self,
        user_id: str,
        conversation_id: str,
        role: str,
        content: str,
    ) -> dict[str, Any]:
        now = _utc_now()
        doc = {
            "id": str(uuid.uuid4()),
            "schema_name": SCHEMA_CONVERSATION_HISTORY,
            "user_id": user_id,
            "conversation_id": conversation_id,
            "role": role,
            "content": content,
            "create_at": _utc_iso(now),
        }
        return await self._c.create_item(doc)

    async def list_recent_history(
        self,
        user_id: str,
        conversation_id: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        query = (
            "SELECT TOP @limit * FROM c "
            "WHERE c.schema_name=@schema_name AND c.user_id=@user_id AND c.conversation_id=@conversation_id "
            "ORDER BY c.create_at DESC"
        )
        params = [
            {"name": "@limit", "value": limit},
            {"name": "@schema_name", "value": SCHEMA_CONVERSATION_HISTORY},
            {"name": "@user_id", "value": user_id},
            {"name": "@conversation_id", "value": conversation_id},
        ]
        items = self._c.query_items(query=query, parameters=params, enable_cross_partition_query=True)
        out: list[dict[str, Any]] = []
        async for item in items:
            out.append(item)
        # DESC → chronological
        out.reverse()
        return out

    async def delete_old_data(self, user_id: str, retention_days: int) -> None:
        # conversation_history
        threshold = _utc_now() - datetime.timedelta(days=retention_days)
        threshold_iso = _utc_iso(threshold)

        # 取得→削除（CosmosDB はサーバー側一括削除がないため）
        for schema in (SCHEMA_CONVERSATION_HISTORY, SCHEMA_AI_PROCESSING_STATUS):
            query = (
                "SELECT c.id, c.conversation_id FROM c "
                "WHERE c.schema_name=@schema_name AND c.user_id=@user_id AND c.create_at <= @threshold "
            )
            params = [
                {"name": "@schema_name", "value": schema},
                {"name": "@user_id", "value": user_id},
                {"name": "@threshold", "value": threshold_iso},
            ]
            items = self._c.query_items(query=query, parameters=params, enable_cross_partition_query=True)
            async for item in items:
                # ここは container の partition key 設計に依存します。
                # 本実装では conversation_id を partition key として削除します。
                pk = item.get("conversation_id")
                if not pk:
                    continue
                try:
                    await self._c.delete_item(item=item["id"], partition_key=pk)
                except cosmos_exceptions.CosmosResourceNotFoundError:
                    pass

    @staticmethod
    def is_processing(status: dict[str, Any] | None) -> bool:
        if not status:
            return False
        return str(status.get("processing_flg", "")) == "1"

    @staticmethod
    def is_timeout(status: dict[str, Any] | None, timeout_seconds: int) -> bool:
        if not status:
            return False
        locked_at = _parse_dt(str(status.get("locked_at", "")))
        if not locked_at:
            return False
        delta = _utc_now() - locked_at
        return delta.total_seconds() > timeout_seconds
