from __future__ import annotations

import uuid


class AppError(Exception):
    def __init__(self, code: str, message: str, request_id: str | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.request_id = request_id or str(uuid.uuid4())


# 画面に返す文言は設計書の message に合わせる
INPUT_EMPTY_MESSAGE = "入力内容が空です。正しい内容を入力してください。"
INPUT_TOO_LONG_MESSAGE_TEMPLATE = "入力内容が長すぎます。最大文字数：{max_len}"

WAITING_MESSAGE = "回答が返ってくるまで、少々お待ちください。"

DB_ERROR_MESSAGE_TEMPLATE = (
    "データベース処理中に例外が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。"
    "エラーコード：{request_id}"
)
AI_ERROR_MESSAGE_TEMPLATE = (
    "AIの処理中に問題が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。"
    "エラーコード：{request_id}"
)
