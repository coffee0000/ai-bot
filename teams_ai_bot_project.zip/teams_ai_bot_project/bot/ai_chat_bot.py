from __future__ import annotations

import logging

from botbuilder.core import ActivityHandler, TurnContext

from teams_ai_bot_project.config.settings import AppSettings
from teams_ai_bot_project.repositories.conversation_repository import ConversationRepository
from teams_ai_bot_project.usecases.ai_chat_usecase import AIChatUseCase
from teams_ai_bot_project.usecases.processing_status_usecase import ProcessingStatusUseCase
from teams_ai_bot_project.usecases import messages as msg

logger = logging.getLogger(__name__)


class AIChatBot(ActivityHandler):
    def __init__(
        self,
        settings: AppSettings,
        conversation_repo: ConversationRepository,
        auditlog_repo,
        llm,
    ):
        self._settings = settings
        self._conversation_repo = conversation_repo
        self._processing_uc = ProcessingStatusUseCase(
            repo=conversation_repo,
            timeout_seconds=settings.AI_PROCESSING_TIMEOUT_SECONDS,
        )
        self._ai_uc = AIChatUseCase(
            settings=settings,
            conversation_repo=conversation_repo,
            auditlog_repo=auditlog_repo,
            llm=llm,
        )

    async def on_message_activity(self, turn_context: TurnContext):
        text = (turn_context.activity.text or "").strip()
        if not text:
            await turn_context.send_activity(msg.MSG_INPUT_EMPTY)
            return
        if len(text) > self._settings.BOT_USER_INPUT_MAX_LENGTH:
            await turn_context.send_activity(msg.MSG_INPUT_TOO_LONG)
            return

        conversation_id = (turn_context.activity.conversation.id or "").strip()
        user_id = (turn_context.activity.from_property.id or "").strip()

        # 期限超え履歴を削除（ベストエフォート）
        try:
            await self._conversation_repo.cleanup_old_history(
                conversation_id=conversation_id,
                user_id=user_id,
                retention_days=self._settings.HISTORY_RETENTION_DAYS,
            )
        except Exception as e:
            logger.warning("cleanup_old_history failed: %s", e)

        can_process, did_timeout_unlock = await self._processing_uc.can_process(conversation_id)
        if not can_process:
            await turn_context.send_activity(msg.MSG_AI_WAIT)
            return

        await self._processing_uc.lock(conversation_id)

        try:
            history = await self._conversation_repo.query_conversation_history(
                conversation_id=conversation_id,
                user_id=user_id,
                limit=self._settings.AI_CHAT_HISTORY_LIMIT,
            )
            ai_text = await self._ai_uc.run(
                conversation_id=conversation_id,
                user_id=user_id,
                user_input=text,
                history_items_desc=history,
            )
            await self._processing_uc.unlock_ok(conversation_id)
            await turn_context.send_activity(ai_text)
        except Exception as e:
            logger.exception("AI chat failed: %s", e)
            await self._processing_uc.unlock_error(conversation_id)
            await turn_context.send_activity(msg.MSG_AI_ERROR)
