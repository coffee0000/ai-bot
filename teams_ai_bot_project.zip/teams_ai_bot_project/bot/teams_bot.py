from __future__ import annotations

from botbuilder.core import ActivityHandler, TurnContext

from teams_ai_bot_project.config import Settings
from teams_ai_bot_project.messages import INPUT_EMPTY_MESSAGE, INPUT_TOO_LONG_TEMPLATE
from teams_ai_bot_project.repository import ConversationRepo, AuditRepo
from teams_ai_bot_project.usecase import handle_message


class TeamsAIBot(ActivityHandler):
    def __init__(self, settings: Settings, conv_repo: ConversationRepo, audit_repo: AuditRepo):
        self._settings = settings
        self._conv_repo = conv_repo
        self._audit_repo = audit_repo

    async def on_message_activity(self, turn_context: TurnContext) -> None:
        text = (turn_context.activity.text or "").strip()
        if not text:
            await turn_context.send_activity(INPUT_EMPTY_MESSAGE)
            return
        if len(text) > self._settings.BOT_USER_INPUT_MAX_LENGTH:
            await turn_context.send_activity(
                INPUT_TOO_LONG_TEMPLATE.format(max_len=self._settings.BOT_USER_INPUT_MAX_LENGTH)
            )
            return

        conversation_id = (turn_context.activity.conversation.id if turn_context.activity.conversation else "") or "unknown"
        user_id = (turn_context.activity.from_property.id if turn_context.activity.from_property else "") or "unknown"

        reply = await handle_message(
            settings=self._settings,
            conv_repo=self._conv_repo,
            audit_repo=self._audit_repo,
            conversation_id=conversation_id,
            user_id=user_id,
            user_text=text,
        )
        await turn_context.send_activity(reply)
