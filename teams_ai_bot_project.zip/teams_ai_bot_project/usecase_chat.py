from __future__ import annotations

import uuid
import logging

from .config import Settings
from .repositories import CosmosRepository
from .common import (
    INPUT_EMPTY_MESSAGE,
    INPUT_TOO_LONG_MESSAGE_TEMPLATE,
    WAITING_MESSAGE,
    DB_ERROR_MESSAGE_TEMPLATE,
    AI_ERROR_MESSAGE_TEMPLATE,
)
from .infra_openai import chat_completion


log = logging.getLogger("teams_ai_bot_project.chat")


def _trim(text: str) -> str:
    return (text or "").strip()


async def handle_user_message(
    settings: Settings,
    repo: CosmosRepository,
    user_id: str,
    conversation_id: str,
    user_text: str,
) -> str:
    request_id = str(uuid.uuid4())
    text = _trim(user_text)

    # ① 入力チェック
    if not text:
        return INPUT_EMPTY_MESSAGE
    if len(text) > settings.BOT_USER_INPUT_MAX_LENGTH:
        return INPUT_TOO_LONG_MESSAGE_TEMPLATE.format(max_len=settings.BOT_USER_INPUT_MAX_LENGTH)

    # ② 排他制御チェック
    try:
        status = await repo.get_processing_status(user_id, conversation_id)
    except Exception:
        log.exception("db_read_failed request_id=%s", request_id)
        return DB_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    if repo.is_processing(status) and not repo.is_timeout(status, settings.AI_PROCESSING_TIMEOUT_SECONDS):
        return WAITING_MESSAGE

    # タイムアウトならロック解除して継続
    if repo.is_processing(status) and repo.is_timeout(status, settings.AI_PROCESSING_TIMEOUT_SECONDS):
        try:
            await repo.upsert_processing_status(
                user_id=user_id,
                conversation_id=conversation_id,
                processing_flg="0",
                locked_at="",
            )
        except Exception:
            log.exception("db_unlock_failed request_id=%s", request_id)
            return DB_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    # ③ 過去データ削除（保持日数）
    try:
        await repo.delete_old_data(user_id=user_id, retention_days=settings.DATA_RETENTION_DAYS)
    except Exception:
        log.exception("db_cleanup_failed request_id=%s", request_id)
        # ここは致命にしない（会話自体は継続）

    # ④ AI 生成開始（ロック）
    try:
        await repo.upsert_processing_status(
            user_id=user_id,
            conversation_id=conversation_id,
            processing_flg="1",
            locked_at=None,  # locked_at は upsert 側で空→更新
        )
    except Exception:
        log.exception("db_lock_failed request_id=%s", request_id)
        return DB_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    # locked_at を明確に set（設計書の locked_at 更新に合わせる）
    try:
        from datetime import datetime, timezone
        await repo.upsert_processing_status(
            user_id=user_id,
            conversation_id=conversation_id,
            processing_flg="1",
            locked_at=datetime.now(timezone.utc).isoformat(),
        )
    except Exception:
        log.exception("db_locktime_failed request_id=%s", request_id)
        return DB_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    # ⑤ 履歴取得
    try:
        history = await repo.list_recent_history(
            user_id=user_id,
            conversation_id=conversation_id,
            limit=settings.AI_CHAT_HISTORY_LIMIT,
        )
    except Exception:
        log.exception("db_history_failed request_id=%s", request_id)
        # ロック解除
        try:
            await repo.upsert_processing_status(user_id, conversation_id, "0", "")
        except Exception:
            pass
        return DB_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    # ⑥ Azure OpenAI 呼び出し
    messages = []
    if settings.SYSTEM_PROMPT:
        messages.append({"role": "system", "content": settings.SYSTEM_PROMPT})
    for h in history:
        role = str(h.get("role", "")).strip()
        content = str(h.get("content", "")).strip()
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": text})

    try:
        ai_text = await chat_completion(settings, messages)
    except Exception:
        log.exception("ai_failed request_id=%s", request_id)
        # ステータス更新（異常）
        try:
            await repo.upsert_processing_status(user_id, conversation_id, "-1", "")
        except Exception:
            pass
        return AI_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    # ⑦ 履歴保存（user → assistant）
    try:
        await repo.insert_history(user_id, conversation_id, "user", text)
        await repo.insert_history(user_id, conversation_id, "assistant", ai_text)
    except Exception:
        log.exception("db_save_failed request_id=%s", request_id)
        # ステータス解放は行う
        try:
            await repo.upsert_processing_status(user_id, conversation_id, "0", "")
        except Exception:
            pass
        return DB_ERROR_MESSAGE_TEMPLATE.format(request_id=request_id)

    # ⑧ ステータス更新（正常）
    try:
        await repo.upsert_processing_status(user_id, conversation_id, "0", "")
    except Exception:
        log.exception("db_status_update_failed request_id=%s", request_id)

    return ai_text
