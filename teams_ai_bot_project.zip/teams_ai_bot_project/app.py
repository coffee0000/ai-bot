from __future__ import annotations

import logging
from aiohttp import web
from botbuilder.integration.aiohttp import BotFrameworkHttpAdapter
from botbuilder.core import TurnContext

from .teams_bot import TeamsAIBot


log = logging.getLogger("teams_ai_bot_project.http")


def create_web_app(adapter: BotFrameworkHttpAdapter, bot: TeamsAIBot) -> web.Application:
    app = web.Application()

    async def messages(req: web.Request) -> web.Response:
        # Bot Framework: /api/messages
        if "application/json" not in (req.headers.get("Content-Type") or ""):
            return web.Response(status=415)

        body = await req.json()
        auth_header = req.headers.get("Authorization", "")

        await adapter.process_activity(body, auth_header, bot.on_turn)
        return web.Response(status=200)

    app.router.add_post("/api/messages", messages)
    app.router.add_get("/healthz", lambda _: web.Response(text="ok"))
    return app
