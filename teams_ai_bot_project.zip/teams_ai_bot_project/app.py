\
import os
from aiohttp import web

from teams_ai_bot_project.config.settings import Settings
from teams_ai_bot_project.web.app_factory import create_app

def main() -> None:
    settings = Settings.load_from_env()
    app = create_app(settings)
    web.run_app(app, host="0.0.0.0", port=int(os.getenv("PORT", "8000")))

if __name__ == "__main__":
    main()
