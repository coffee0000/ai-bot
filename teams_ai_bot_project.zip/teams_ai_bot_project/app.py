from __future__ import annotations

import asyncio
import logging
import os

from aiohttp import web
from botbuilder.schema import Activity
from dotenv import load_dotenv

from teams_ai_bot_project.config import get_settings
from teams_ai_bot_project.logging_config import configure_logging
from teams_ai_bot_project.adapters.bot_adapter import create_adapter
from teams_ai_bot_project.bot.teams_bot import TeamsAIBot
from teams_ai_bot_project.infra.cosmos_client import create_cosmos_resources
from teams_ai_bot_project.repository import ConversationRepo, AuditRepo

logger = logging.getLogger(__name__)


async def create_app() -> web.Application:
    settings = get_settings()

    cosmos = await create_cosmos_resources(settings)
    conv_repo = ConversationRepo(cosmos.business_container)
    audit_repo = AuditRepo(cosmos.archive_container)

    adapter = create_adapter(settings.AZURE_APP_ID, settings.AZURE_APP_PASSWORD)
    bot = TeamsAIBot(settings=settings, conv_repo=conv_repo, audit_repo=audit_repo)

    app = web.Application()

    async def health(_: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    async def messages(req: web.Request) -> web.StreamResponse:
        if "application/json" not in req.headers.get("Content-Type", ""):
            return web.Response(status=415, text="Unsupported Media Type")

        body = await req.json()
        activity = Activity().deserialize(body)
        auth_header = req.headers.get("Authorization", "")

        await adapter.process_activity(activity, auth_header, bot.on_turn)
        return web.Response(status=200)

    async def on_cleanup(_: web.Application) -> None:
        try:
            await cosmos.client.close()
        except Exception:
            pass

    app.router.add_get("/health", health)
    app.router.add_get("/", health)
    app.router.add_post("/api/messages", messages)
    app.on_cleanup.append(on_cleanup)
    return app


def main() -> None:
    load_dotenv()
    configure_logging()
    settings = get_settings()

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    app = loop.run_until_complete(create_app())
    web.run_app(app, host=settings.HOST, port=int(os.getenv("PORT", settings.PORT)))


if __name__ == "__main__":
    main()
