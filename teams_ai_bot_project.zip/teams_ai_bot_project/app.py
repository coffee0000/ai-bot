import os
from pathlib import Path

from aiohttp import web
from dotenv import load_dotenv

from src.config.settings import Settings
from src.web.app_factory import create_app

# ローカル開発時は .env を読み込んで環境変数化する
# （App Service など本番環境では、既に設定されている環境変数を優先し、.env は通常存在しない）
project_root = Path(__file__).resolve().parent
env_path = project_root / ".env"
load_dotenv(dotenv_path=env_path, override=False)

settings = Settings.load_from_env()
app = create_app(settings)


def main() -> None:
    web.run_app(app, host="0.0.0.0", port=int(os.getenv("PORT", "3978")))


if __name__ == "__main__":
    main()
