from __future__ import annotations

import logging
from botbuilder.core import ActivityHandler, TurnContext, MessageFactory

from .config import Settings
from .repositories import CosmosRepository
from .usecase_chat import handle_user_message


log = logging.getLogger("teams_ai_bot_project.bot")


class TeamsAIBot(ActivityHandler):
    def __init__(self, settings: Settings, repo: CosmosRepository):
        self._settings = settings
        self._repo = repo
        super().__init__()

    async def on_message_activity(self, turn_context: TurnContext):
        # Teams/Emulator の user id と conversation id を設計書の user_id / conversation_id として扱う
        user_id = (turn_context.activity.from_property.id or "").strip()
        conversation_id = (turn_context.activity.conversation.id or "").strip()
        text = turn_context.activity.text or ""

        if not user_id or not conversation_id:
            await turn_context.send_activity(MessageFactory.text("リクエスト情報が不正です。"))
            return

        reply = await handle_user_message(
            settings=self._settings,
            repo=self._repo,
            user_id=user_id,
            conversation_id=conversation_id,
            user_text=text,
        )
        await turn_context.send_activity(MessageFactory.text(reply))
