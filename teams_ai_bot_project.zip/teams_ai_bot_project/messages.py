from __future__ import annotations

INPUT_EMPTY_MESSAGE = "入力内容为空，请输入正确内容。"
INPUT_TOO_LONG_TEMPLATE = "入力内容过长，最大文字数：{max_len}"
WAITING_MESSAGE = "回答が返ってくるまで、少々お待ちください。"
DB_ERROR_MESSAGE = "数据库处理过程中发生异常，请稍后再试或联系管理员。"
AI_ERROR_MESSAGE = "当前会话的AI发生异常，请关闭当前会话重新进行聊天。"
