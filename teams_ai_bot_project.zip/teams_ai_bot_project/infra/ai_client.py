from __future__ import annotations

from typing import List, Dict, Any

from azure.identity import get_bearer_token_provider
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from teams_ai_bot_project.config import Settings
from teams_ai_bot_project.infra.credentials import build_sync_credential


AZURE_OPENAI_SCOPE = "https://cognitiveservices.azure.com/.default"


def build_llm(settings: Settings) -> AzureChatOpenAI:
    credential = build_sync_credential(settings)
    token_provider = get_bearer_token_provider(credential, AZURE_OPENAI_SCOPE)

    return AzureChatOpenAI(
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
        azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
        api_version=settings.AZURE_OPENAI_API_VERSION,
        azure_ad_token_provider=token_provider,
        max_tokens=settings.AZURE_OPENAI_MAX_TOKEN,
    )


def build_chain(settings: Settings):
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "{system_prompt}"),
            MessagesPlaceholder("history"),
            ("human", "{user_input}"),
        ]
    )
    llm = build_llm(settings)
    return prompt | llm


def history_to_messages(history_items_asc: List[Dict[str, Any]]):
    msgs: List[Any] = []
    for it in history_items_asc:
        role = (it.get("role") or "").lower()
        content = it.get("content") or ""
        if not content:
            continue
        if role == "assistant":
            msgs.append(AIMessage(content=content))
        else:
            msgs.append(HumanMessage(content=content))
    return msgs
