from __future__ import annotations

import logging


def setup_logging() -> None:
    # 必要最低限（密なログを避ける）
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s - %(message)s",
    )
