from __future__ import annotations

from dataclasses import dataclass

from azure.cosmos.aio import CosmosClient
from teams_ai_bot_project.config.settings import AppSettings
from teams_ai_bot_project.infra.credentials import AzureClientSecret, build_async_credential


@dataclass(frozen=True)
class CosmosResources:
    client: CosmosClient
    conversation_container: object
    auditlog_container: object


async def build_cosmos_resources(settings: AppSettings) -> CosmosResources:
    secret = AzureClientSecret(
        tenant_id=settings.AZURE_APP_TENANT_ID,
        client_id=settings.AZURE_APP_ID,
        client_secret=settings.AZURE_APP_PASSWORD,
    )
    credential = build_async_credential(settings.DEV_FLG, secret)

    client = CosmosClient(
        url=settings.AZURE_COSMOSDB_ENDPOINT,
        credential=credential,
    )

    db = client.get_database_client(settings.AZURE_COSMOSDB_NOSQL_DATABASE)
    conv = db.get_container_client(settings.AZURE_COSMOSDB_NOSQL_CONTAINER_CONVERSATION)
    audit = db.get_container_client(settings.AZURE_COSMOSDB_NOSQL_CONTAINER_AUDITLOG)

    return CosmosResources(client=client, conversation_container=conv, auditlog_container=audit)
