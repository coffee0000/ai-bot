from __future__ import annotations

from dataclasses import dataclass

from azure.cosmos.aio import CosmosClient

from teams_ai_bot_project.config import Settings
from teams_ai_bot_project.infra.credentials import build_async_credential


@dataclass(frozen=True)
class CosmosResources:
    client: CosmosClient
    business_container: object
    archive_container: object


async def create_cosmos_resources(settings: Settings) -> CosmosResources:
    credential = build_async_credential(settings)
    client = CosmosClient(url=settings.AZURE_COSMOSDB_ENDPOINT, credential=credential)

    db = client.get_database_client(settings.AZURE_COSMOSDB_DATABASE_NAME)
    business = db.get_container_client(settings.AZURE_COSMOSDB_CONTAINER_BUSINESS)
    archive = db.get_container_client(settings.AZURE_COSMOSDB_CONTAINER_ARCHIVE)

    return CosmosResources(client=client, business_container=business, archive_container=archive)
