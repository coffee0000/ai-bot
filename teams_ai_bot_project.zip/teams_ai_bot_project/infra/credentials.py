from __future__ import annotations

from dataclasses import dataclass

from azure.identity import ClientSecretCredential, DefaultAzureCredential
from azure.identity.aio import ClientSecretCredential as AsyncClientSecretCredential
from azure.identity.aio import DefaultAzureCredential as AsyncDefaultAzureCredential


@dataclass(frozen=True)
class AzureClientSecret:
    tenant_id: str
    client_id: str
    client_secret: str


def build_sync_credential(dev_flg: bool, secret: AzureClientSecret) -> object:
    # Azure OpenAI (langchain-openai) の token_provider 用（同期）
    if dev_flg:
        return ClientSecretCredential(
            tenant_id=secret.tenant_id,
            client_id=secret.client_id,
            client_secret=secret.client_secret,
        )
    return DefaultAzureCredential(exclude_interactive_browser_credential=True)


def build_async_credential(dev_flg: bool, secret: AzureClientSecret):
    # Cosmos DB 用（非同期）
    if dev_flg:
        return AsyncClientSecretCredential(
            tenant_id=secret.tenant_id,
            client_id=secret.client_id,
            client_secret=secret.client_secret,
        )
    return AsyncDefaultAzureCredential(exclude_interactive_browser_credential=True)
