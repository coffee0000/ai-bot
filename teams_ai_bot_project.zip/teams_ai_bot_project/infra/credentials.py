from __future__ import annotations

from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure.identity.aio import DefaultAzureCredential as AsyncDefaultAzureCredential
from azure.identity.aio import ClientSecretCredential as AsyncClientSecretCredential

from teams_ai_bot_project.config import Settings


def build_sync_credential(settings: Settings):
    if settings.DEV_FLG:
        return ClientSecretCredential(
            tenant_id=settings.AZURE_AUTH_TENANT_ID,
            client_id=settings.AZURE_AUTH_CLIENT_ID,
            client_secret=settings.AZURE_AUTH_CLIENT_SECRET,
        )
    return DefaultAzureCredential(exclude_interactive_browser_credential=True)


def build_async_credential(settings: Settings):
    if settings.DEV_FLG:
        return AsyncClientSecretCredential(
            tenant_id=settings.AZURE_AUTH_TENANT_ID,
            client_id=settings.AZURE_AUTH_CLIENT_ID,
            client_secret=settings.AZURE_AUTH_CLIENT_SECRET,
        )
    return AsyncDefaultAzureCredential(exclude_interactive_browser_credential=True)
