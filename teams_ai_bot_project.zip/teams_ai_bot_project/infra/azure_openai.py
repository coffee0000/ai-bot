from __future__ import annotations

from typing import Optional

from langchain_openai import AzureChatOpenAI
from azure.identity import get_bearer_token_provider

from teams_ai_bot_project.config.settings import AppSettings
from teams_ai_bot_project.infra.credentials import AzureClientSecret, build_sync_credential


def build_llm(settings: AppSettings) -> AzureChatOpenAI:
    # Entra ID (token) で Azure OpenAI に接続
    # NOTE: 公式の token provider を利用
    secret = AzureClientSecret(
        tenant_id=settings.AZURE_APP_TENANT_ID,
        client_id=settings.AZURE_APP_ID,
        client_secret=settings.AZURE_APP_PASSWORD,
    )
    credential = build_sync_credential(settings.DEV_FLG, secret)

    token_provider = get_bearer_token_provider(
        credential,
        "https://cognitiveservices.azure.com/.default",
    )

    return AzureChatOpenAI(
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
        azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
        api_version=settings.AZURE_OPENAI_API_VERSION,
        azure_ad_token_provider=token_provider,
    )
