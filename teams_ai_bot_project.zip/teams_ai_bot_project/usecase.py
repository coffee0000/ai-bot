from __future__ import annotations

import uuid
import logging
from teams_ai_bot_project.config import Settings
from teams_ai_bot_project.messages import WAITING_MESSAGE, DB_ERROR_MESSAGE, AI_ERROR_MESSAGE
from teams_ai_bot_project.infra.ai_client import build_chain, history_to_messages
from teams_ai_bot_project.repository import ConversationRepo, AuditRepo, utc_iso_now, parse_iso

logger = logging.getLogger(__name__)


async def handle_message(
    settings: Settings,
    conv_repo: ConversationRepo,
    audit_repo: AuditRepo,
    conversation_id: str,
    user_id: str,
    user_text: str,
) -> str:
    # 排他チェック
    try:
        status = await conv_repo.get_status(conversation_id)
    except Exception:
        logger.exception("db_get_status_failed")
        return DB_ERROR_MESSAGE

    if status and str(status.get("processing_flg", "0")) == "1":
        locked_at = parse_iso(str(status.get("locked_at", "")))
        if locked_at:
            import datetime
            now = datetime.datetime.now(datetime.timezone.utc)
            if (now - locked_at).total_seconds() <= settings.AI_PROCESSING_TIMEOUT_SECONDS:
                return WAITING_MESSAGE

    # cleanup（best effort）
    try:
        await conv_repo.cleanup_old(conversation_id, user_id, settings.CHAT_HISTORY_RETENTION_DAYS)
    except Exception:
        logger.warning("cleanup_old_failed", exc_info=True)

    # lock
    try:
        await conv_repo.upsert_status(conversation_id, "1", utc_iso_now())
    except Exception:
        logger.exception("db_lock_failed")
        return DB_ERROR_MESSAGE

    request_id = str(uuid.uuid4())

    try:
        history_desc = await conv_repo.list_history_desc(conversation_id, user_id, settings.AI_CHAT_HISTORY_LIMIT)
        history_asc = list(reversed(history_desc))

        chain = build_chain(settings)
        lc_history = history_to_messages(history_asc)

        result = await chain.ainvoke(
            {
                "system_prompt": settings.AZURE_OPENAI_SYSTEM_PROMPT or "",
                "history": lc_history,
                "user_input": user_text,
            }
        )
        ai_text = getattr(result, "content", None) or str(result)

        await conv_repo.append_history(conversation_id, user_id, "user", user_text)
        await conv_repo.append_history(conversation_id, user_id, "assistant", ai_text)

        # audit（最小）
        try:
            await audit_repo.upsert_audit(
                {
                    "id": str(uuid.uuid4()),
                    "approach": "chat",
                    "user": user_id,
                    "tokens": "",
                    "input": user_text,
                    "response": ai_text,
                    "create_at": utc_iso_now(),
                }
            )
        except Exception:
            logger.warning("audit_write_failed", exc_info=True)

        return ai_text

    except Exception:
        logger.exception("ai_or_db_failed request_id=%s", request_id)
        try:
            await conv_repo.upsert_status(conversation_id, "-1", "")
        except Exception:
            pass
        return AI_ERROR_MESSAGE
    finally:
        try:
            st = await conv_repo.get_status(conversation_id)
            if st and str(st.get("processing_flg")) == "1":
                await conv_repo.upsert_status(conversation_id, "0", "")
        except Exception:
            pass
