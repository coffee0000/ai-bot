from __future__ import annotations

import logging
from botbuilder.core import BotFrameworkAdapterSettings, TurnContext
from botbuilder.integration.aiohttp import BotFrameworkHttpAdapter

from .config import Settings


log = logging.getLogger("teams_ai_bot_project.adapter")


def create_adapter(settings: Settings) -> BotFrameworkHttpAdapter:
    # channel_auth_tenant に tenant id を設定（単一テナント運用を想定）
    adapter_settings = BotFrameworkAdapterSettings(
        app_id=settings.MICROSOFT_APP_ID,
        app_password=settings.MICROSOFT_APP_PASSWORD,
        channel_auth_tenant=settings.MICROSOFT_APP_TENANT_ID or None,
    )
    adapter = BotFrameworkHttpAdapter(adapter_settings)

    async def on_error(turn_context: TurnContext, error: Exception):
        log.exception("on_turn_error: %s", error)
        # ユーザー向けに一般的メッセージ
        try:
            await turn_context.send_activity("内部エラーが発生しました。")
        except Exception:
            pass

    adapter.on_turn_error = on_error
    return adapter
