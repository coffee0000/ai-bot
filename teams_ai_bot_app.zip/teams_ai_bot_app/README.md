# Teams AI Bot App (aiohttp + Bot Framework SDK + LangChain + Cosmos DB)

このリポジトリは「方式設計」に沿った **実装用ひな型** です。

- 入口層（aiohttp）：`/api/messages`
- 共通前処理：入力チェック・相関ID（trace）・例外処理
- Adapter：Bot Framework SDK に委譲（検証/TurnContext/実行）
- Bot 編排：権限→ロック→履歴→LLM→保存→返信→監査
- services：権限/ロック/監査/チャット
- repositories：Cosmos DB
- llm：LangChain（Azure OpenAI）

## 起動（ローカル）
1. `.env.example` → `.env`
2. `pip install -e .`
3. `python -m teams_ai_bot_app.app`  
   Endpoint: `http://localhost:3978/api/messages`

## テスト
`pytest -q`
