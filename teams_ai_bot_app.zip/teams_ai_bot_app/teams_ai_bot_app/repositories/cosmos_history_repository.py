from typing import List
from datetime import datetime
from azure.identity import DefaultAzureCredential
from azure.cosmos.aio import CosmosClient

from ..config import settings
from ..models.chat import ChatMessage, ChatTurn
from .history_repository import HistoryRepository

class CosmosHistoryRepository(HistoryRepository):
    def __init__(self) -> None:
        self._client = None
        self._container = None

    async def _ensure(self):
        if self._container is not None:
            return
        if not (settings.cosmos_endpoint and settings.cosmos_database and settings.cosmos_container):
            raise RuntimeError("Cosmos settings are not configured.")
        cred = DefaultAzureCredential(exclude_interactive_browser_credential=False)
        self._client = CosmosClient(settings.cosmos_endpoint, credential=cred)
        db = self._client.get_database_client(settings.cosmos_database)
        self._container = db.get_container_client(settings.cosmos_container)

    async def load_messages(self, conversation_id: str, limit: int) -> List[ChatMessage]:
        await self._ensure()
        query = "SELECT TOP @limit c.role, c.content, c.created_at FROM c WHERE c.conversation_id = @cid ORDER BY c.created_at DESC"
        params = [{"name":"@cid","value":conversation_id},{"name":"@limit","value":limit}]
        items = []
        async for it in self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True):
            items.append(it)
        items = list(reversed(items))
        return [ChatMessage(role=i["role"], content=i["content"], created_at=datetime.fromisoformat(i["created_at"])) for i in items]

    async def save_turn(self, turn: ChatTurn) -> None:
        await self._ensure()
        doc_user = {
            "id": f"{turn.conversation_id}:{turn.created_at.isoformat()}",
            "conversation_id": turn.conversation_id,
            "user_id": turn.user_id,
            "trace_id": turn.trace_id,
            "role": "user",
            "content": turn.user_text,
            "created_at": turn.created_at.isoformat(),
        }
        doc_ai = {
            "id": f"{turn.conversation_id}:{turn.created_at.isoformat()}:assistant",
            "conversation_id": turn.conversation_id,
            "user_id": turn.user_id,
            "trace_id": turn.trace_id,
            "role": "assistant",
            "content": turn.assistant_text,
            "created_at": turn.created_at.isoformat(),
        }
        await self._container.upsert_item(doc_user)
        await self._container.upsert_item(doc_ai)
