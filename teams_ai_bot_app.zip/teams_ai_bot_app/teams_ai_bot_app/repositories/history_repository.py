from abc import ABC, abstractmethod
from typing import List
from ..models.chat import ChatMessage, ChatTurn

class HistoryRepository(ABC):
    @abstractmethod
    async def load_messages(self, conversation_id: str, limit: int) -> List[ChatMessage]:
        raise NotImplementedError

    @abstractmethod
    async def save_turn(self, turn: ChatTurn) -> None:
        raise NotImplementedError
