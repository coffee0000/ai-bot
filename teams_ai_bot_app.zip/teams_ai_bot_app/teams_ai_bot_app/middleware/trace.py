import uuid
from aiohttp import web

TRACE_HEADER = "X-Trace-Id"

@web.middleware
async def trace_middleware(request: web.Request, handler):
    trace_id = request.headers.get(TRACE_HEADER) or str(uuid.uuid4())
    request["trace_id"] = trace_id
    resp = await handler(request)
    resp.headers[TRACE_HEADER] = trace_id
    return resp
