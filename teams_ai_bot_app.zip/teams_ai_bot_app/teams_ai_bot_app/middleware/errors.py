import logging
from aiohttp import web

log = logging.getLogger("teams_ai_bot_app.errors")

@web.middleware
async def error_middleware(request: web.Request, handler):
    try:
        return await handler(request)
    except web.HTTPException:
        raise
    except Exception:
        log.exception("unhandled_exception", extra={"trace_id": request.get("trace_id","-")})
        return web.json_response({"error": "サーバーエラーが発生しました。"}, status=500)
