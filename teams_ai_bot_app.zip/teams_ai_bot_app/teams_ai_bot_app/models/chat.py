from pydantic import BaseModel
from datetime import datetime

class ChatMessage(BaseModel):
    role: str
    content: str
    created_at: datetime

class ChatTurn(BaseModel):
    trace_id: str
    conversation_id: str
    user_id: str
    user_text: str
    assistant_text: str
    created_at: datetime
