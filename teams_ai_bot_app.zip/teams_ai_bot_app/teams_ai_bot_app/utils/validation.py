from dataclasses import dataclass

@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    message: str = ""

def validate_user_text(text: str, max_chars: int) -> ValidationResult:
    if text is None:
        return ValidationResult(False, "入力が存在しません。")
    t = text.strip()
    if not t:
        return ValidationResult(False, "入力が空です。")
    if len(t) > max_chars:
        return ValidationResult(False, "入力が長すぎます。")
    return ValidationResult(True, "")
