from botbuilder.integration.aiohttp import CloudAdapter, ConfigurationBotFrameworkAuthentication
from .config import settings

def create_adapter() -> CloudAdapter:
    auth = ConfigurationBotFrameworkAuthentication(settings)
    return CloudAdapter(auth)
