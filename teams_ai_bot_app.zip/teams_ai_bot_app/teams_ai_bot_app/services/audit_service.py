import logging
log = logging.getLogger("teams_ai_bot_app.audit")

class AuditService:
    async def record(self, trace_id: str, event: str, detail: dict):
        log.info("audit event=%s detail=%s", event, detail, extra={"trace_id": trace_id})
