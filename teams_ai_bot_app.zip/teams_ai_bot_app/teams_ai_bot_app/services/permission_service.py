class PermissionService:
    async def ensure_allowed(self, user_id: str) -> None:
        # TODO: integrate your internal authorization
        return
