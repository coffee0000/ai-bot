from datetime import datetime, timezone
from ..config import settings
from ..models.chat import ChatTurn
from ..repositories.history_repository import HistoryRepository
from ..llm.azure_openai_client import AzureOpenAIClient

class ChatService:
    def __init__(self, history_repo: HistoryRepository, llm: AzureOpenAIClient) -> None:
        self._repo = history_repo
        self._llm = llm

    async def generate_reply(self, trace_id: str, conversation_id: str, user_id: str, user_text: str) -> tuple[str, ChatTurn]:
        history = await self._repo.load_messages(conversation_id, settings.history_limit)
        assistant_text = await self._llm.chat(user_text=user_text, history=history)
        now = datetime.now(timezone.utc)
        turn = ChatTurn(
            trace_id=trace_id,
            conversation_id=conversation_id,
            user_id=user_id,
            user_text=user_text,
            assistant_text=assistant_text,
            created_at=now,
        )
        return assistant_text, turn
