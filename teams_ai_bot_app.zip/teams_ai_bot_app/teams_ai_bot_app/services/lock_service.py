import asyncio
from contextlib import asynccontextmanager

class LockService:
    def __init__(self) -> None:
        self._locks: dict[str, asyncio.Lock] = {}

    @asynccontextmanager
    async def acquire(self, conversation_id: str):
        lock = self._locks.setdefault(conversation_id, asyncio.Lock())
        await lock.acquire()
        try:
            yield
        finally:
            lock.release()
