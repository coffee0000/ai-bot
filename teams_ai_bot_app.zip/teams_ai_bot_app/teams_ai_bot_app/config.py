import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "3978"))

    microsoft_app_id: str = os.getenv("MICROSOFT_APP_ID", "")
    microsoft_app_password: str = os.getenv("MICROSOFT_APP_PASSWORD", "")
    microsoft_app_tenant_id: str = os.getenv("MICROSOFT_APP_TENANT_ID", "")
    microsoft_app_type: str = os.getenv("MICROSOFT_APP_TYPE", "MultiTenant")

    azure_openai_endpoint: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    azure_openai_deployment: str = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
    azure_openai_api_version: str = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")
    system_prompt: str = os.getenv("SYSTEM_PROMPT", "You are a helpful assistant.")

    cosmos_endpoint: str = os.getenv("COSMOS_ENDPOINT", "")
    cosmos_database: str = os.getenv("COSMOS_DATABASE", "")
    cosmos_container: str = os.getenv("COSMOS_CONTAINER", "")

    max_input_chars: int = int(os.getenv("MAX_INPUT_CHARS", "8000"))
    history_limit: int = int(os.getenv("HISTORY_LIMIT", "10"))
    ai_timeout_seconds: int = int(os.getenv("AI_TIMEOUT_SECONDS", "60"))

settings = Settings()
