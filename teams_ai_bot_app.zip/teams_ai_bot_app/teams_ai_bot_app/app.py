import logging
from datetime import datetime
from aiohttp import web
from botbuilder.core import TurnContext
from botbuilder.schema import Activity, ActivityTypes
from botbuilder.core.integration import aiohttp_error_middleware

from .logging_setup import setup_logging
from .adapters import create_adapter
from .bots.ai_chat_bot import AIChatBot
from .middleware.trace import trace_middleware
from .middleware.errors import error_middleware
from .config import settings

setup_logging()
log = logging.getLogger("teams_ai_bot_app.app")

ADAPTER = create_adapter()
BOT = AIChatBot()

async def on_error(context: TurnContext, error: Exception):
    log.exception("on_turn_error", extra={"trace_id": context.turn_state.get("trace_id","-")})
    await context.send_activity("サーバーエラーが発生しました。")
    if context.activity.channel_id == "emulator":
        trace_activity = Activity(
            label="TurnError",
            name="on_turn_error Trace",
            timestamp=datetime.utcnow(),
            type=ActivityTypes.trace,
            value=f"{error}",
            value_type="https://www.botframework.com/schemas/error",
        )
        await context.send_activity(trace_activity)

ADAPTER.on_turn_error = on_error

async def messages(req: web.Request) -> web.Response:
    trace_id = req.get("trace_id", "-")

    async def _logic(turn_context: TurnContext):
        turn_context.turn_state["trace_id"] = trace_id
        await BOT.on_turn(turn_context)

    return await ADAPTER.process(req, _logic)

def create_app() -> web.Application:
    app = web.Application(middlewares=[trace_middleware, error_middleware, aiohttp_error_middleware])
    app.router.add_post("/api/messages", messages)
    return app

if __name__ == "__main__":
    web.run_app(create_app(), host=settings.host, port=settings.port)
