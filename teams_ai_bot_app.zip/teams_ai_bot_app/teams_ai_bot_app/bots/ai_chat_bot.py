import logging
from botbuilder.core import ActivityHandler, TurnContext
from ..config import settings
from ..utils.validation import validate_user_text
from ..services.permission_service import PermissionService
from ..services.lock_service import LockService
from ..services.audit_service import AuditService
from ..services.chat_service import ChatService
from ..repositories.cosmos_history_repository import CosmosHistoryRepository
from ..llm.azure_openai_client import AzureOpenAIClient

log = logging.getLogger("teams_ai_bot_app.bot")

class AIChatBot(ActivityHandler):
    def __init__(self) -> None:
        self._permission = PermissionService()
        self._locks = LockService()
        self._audit = AuditService()
        self._history_repo = CosmosHistoryRepository()
        self._llm = AzureOpenAIClient()
        self._chat = ChatService(self._history_repo, self._llm)

    async def on_message_activity(self, turn_context: TurnContext):
        trace_id = turn_context.turn_state.get("trace_id", "-")

        user_text = (turn_context.activity.text or "").strip()
        vr = validate_user_text(user_text, settings.max_input_chars)
        if not vr.ok:
            await turn_context.send_activity(vr.message)
            return

        conversation_id = getattr(turn_context.activity.conversation, "id", "") or ""
        user_id = getattr(turn_context.activity.from_property, "id", "") or ""

        await self._permission.ensure_allowed(user_id)

        async with self._locks.acquire(conversation_id):
            assistant_text, turn = await self._chat.generate_reply(
                trace_id=trace_id,
                conversation_id=conversation_id,
                user_id=user_id,
                user_text=user_text,
            )
            await turn_context.send_activity(assistant_text)
            await self._history_repo.save_turn(turn)
            await self._audit.record(trace_id, "chat_turn_completed", {"conversation_id": conversation_id, "user_id": user_id})
