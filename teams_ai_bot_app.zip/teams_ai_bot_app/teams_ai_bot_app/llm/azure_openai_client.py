from typing import List
import asyncio
from langchain_openai import AzureChatOpenAI
from langchain.schema import SystemMessage, HumanMessage, AIMessage
from ..config import settings
from ..models.chat import ChatMessage

class AzureOpenAIClient:
    def __init__(self) -> None:
        self._llm = AzureChatOpenAI(
            azure_endpoint=settings.azure_openai_endpoint,
            azure_deployment=settings.azure_openai_deployment,
            api_version=settings.azure_openai_api_version,
            temperature=0.2,
        )

    async def chat(self, user_text: str, history: List[ChatMessage]) -> str:
        messages = [SystemMessage(content=settings.system_prompt)]
        for m in history:
            if m.role == "user":
                messages.append(HumanMessage(content=m.content))
            elif m.role == "assistant":
                messages.append(AIMessage(content=m.content))
        messages.append(HumanMessage(content=user_text))

        def _invoke():
            return self._llm.invoke(messages).content

        return await asyncio.to_thread(_invoke)
