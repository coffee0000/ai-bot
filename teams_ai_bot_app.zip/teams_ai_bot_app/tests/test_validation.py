from teams_ai_bot_app.utils.validation import validate_user_text

def test_validate_user_text_empty():
    assert not validate_user_text("   ", 10).ok

def test_validate_user_text_too_long():
    assert not validate_user_text("x"*11, 10).ok

def test_validate_user_text_ok():
    assert validate_user_text("hello", 10).ok
