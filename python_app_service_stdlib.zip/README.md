# Python Stdlib App Service

Zero dependency Python app for Azure App Service.
