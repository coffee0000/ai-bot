import os
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8000"))

class AppHandler(BaseHTTPRequestHandler):
    def _send(self, status: int, data: dict):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_GET(self):
        if self.path in ("/", "/health"):
            self._send(200, {
                "status": "ok",
                "service": "python-stdlib-app-service"
            })
        else:
            self._send(404, {
                "error": "not_found",
                "path": self.path
            })

    def log_message(self, format, *args):
        return

def main():
    server = HTTPServer((HOST, PORT), AppHandler)
    print(f"Server started on {HOST}:{PORT}")
    server.serve_forever()

if __name__ == "__main__":
    main()
