from __future__ import annotations

import os
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class Settings(BaseModel):
    # Bot Framework
    AZURE_APP_ID: str = Field(default="")
    AZURE_APP_PASSWORD: str = Field(default="")
    AZURE_APP_TYPE: str = Field(default="SingleTenant")

    # App
    DEV_FLG: bool = Field(default=False)

    # Azure Auth (local)
    AZURE_AUTH_TENANT_ID: str = Field(default="")
    AZURE_AUTH_CLIENT_ID: str = Field(default="")
    AZURE_AUTH_CLIENT_SECRET: str = Field(default="")

    # Azure OpenAI
    AZURE_OPENAI_ENDPOINT: str = Field(default="")
    AZURE_OPENAI_DEPLOYMENT: str = Field(default="")
    AZURE_OPENAI_API_VERSION: str = Field(default="2024-10-21")
    AZURE_OPENAI_SYSTEM_PROMPT: str = Field(
        default=(
            "あなたは正確で信頼できるAIアシスタントとして、ユーザーの指示を最優先に、推測を避け、"
            "簡潔かつ論理的で実用的な回答のみを提供してください。"
        )
    )
    AZURE_OPENAI_MAX_TOKEN: Optional[int] = Field(default=None)

    # Cosmos DB
    AZURE_COSMOSDB_ENDPOINT: str = Field(default="")
    AZURE_COSMOSDB_DATABASE_NAME: str = Field(default="")
    AZURE_COSMOSDB_CONTAINER_BUSINESS: str = Field(default="")
    AZURE_COSMOSDB_CONTAINER_ARCHIVE: str = Field(default="")
    AZURE_COSMOSDB_CONTAINER_BUSINESS_PARTITION_KEY: str = Field(default="conversation_id")
    AZURE_COSMOSDB_CONTAINER_ARCHIVE_PARTITION_KEY: str = Field(default="user")

    # Chat
    TEAMS_AI_BOT_WELCOME_MESSAGE: str = Field(
        default="こちらはTeams AI Botです、はじめまして！ \n何についてお話ししましょうか？"
    )
    TEAMS_AI_BOT_AUTO_REPLY_MESSAGE: str = Field(default="AIの回答を生成しています。しばらくお待ちください。")
    AI_CHAT_HISTORY_LIMIT: int = Field(default=10)
    CHAT_HISTORY_RETENTION_DAYS: int = Field(default=30)
    AI_PROCESSING_TIMEOUT_SECONDS: int = Field(default=600)
    BOT_USER_INPUT_MAX_LENGTH: int = Field(default=20000)

    # Logging
    LOG_LEVEL: str = Field(default="INFO")

    @field_validator("TEAMS_AI_BOT_WELCOME_MESSAGE", mode="before")
    @classmethod
    def convert_newline(cls, v: str) -> str:
        if isinstance(v, str):
            return v.replace("\\n", "\n")
        return v

    @staticmethod
    def load_from_env() -> "Settings":
        """環境変数から設定を読み込み、型変換は Pydantic に任せる。

        - ローカル: VS Code などから .env を事前に読み込んで環境変数化していれば、その値を使用
        - 本番(App Service): ポータル上で設定した環境変数をそのまま使用
        - 未設定の項目は上記 Field で定義したデフォルト値を使用
        """

        data: dict[str, str] = {}
        for name in Settings.model_fields.keys():
            if name in os.environ:
                data[name] = os.environ[name]

        return Settings(**data)
