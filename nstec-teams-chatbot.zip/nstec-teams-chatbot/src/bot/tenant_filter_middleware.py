from __future__ import annotations

import logging
from typing import Iterable

from botbuilder.core import Middleware, TurnContext

logger = logging.getLogger(__name__)


class TenantFilterMiddleware(Middleware):
    """特定の Azure AD テナントのみが Bot を利用できるように制限するミドルウェア。

    - `allowed_tenant_ids` は許可されたテナント ID（GUID）の配列を想定。
      例: ["aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", "ffffffff-gggg-hhhh-iiii-jjjjjjjjjjjj"]
                - 許可されていないテナント、もしくはテナントIDが取得できない場合は、Bot のロジック（挨拶メッセージ等）を
                    一切実行せずに処理を中断し、ログのみを出力する。
                    ※ Teams 側のユーザーには何もメッセージを返さない。
    """

    def __init__(self, allowed_tenant_ids: Iterable[str]) -> None:
        # 許可テナントIDを小文字に正規化して集合で保持
        tenants: set[str] = set()
        for tid in allowed_tenant_ids:
            if isinstance(tid, str):
                v = tid.strip()
                if v:
                    tenants.add(v.lower())

        self._allowed_tenant_ids: set[str] = tenants

    async def on_turn(self, context: TurnContext, logic):
        activity = context.activity
        if activity is None:
            # プロアクティブなど、アクティビティなしのケースはそのまま通す
            await logic()
            return

        tenant_id: str | None = None

        # Teams では conversation.tenant_id に入っていることが多い
        conversation = getattr(activity, "conversation", None)
        if conversation is not None:
            tenant_id = getattr(conversation, "tenant_id", None)

        # 無ければ channel_data["tenant"]["id"] を見る
        if not tenant_id:
            channel_data = getattr(activity, "channel_data", None)
            if isinstance(channel_data, dict):
                tenant = channel_data.get("tenant")
                if isinstance(tenant, dict):
                    tenant_id = tenant.get("id")

        # テナントIDが取れない or 許可されたテナントと異なる場合は、
        # Bot のロジックを一切実行せずに処理を中断し、ログのみを出力する。
        if not tenant_id:
            logger.warning("TenantFilterMiddleware: テナントIDが取得できないためアクセスを拒否しました。")
            # ユーザーには何も返さず、ここで処理を終了する
            return

        tenant_id_norm = str(tenant_id).strip().lower()

        if tenant_id_norm not in self._allowed_tenant_ids:
            logger.warning(
                "TenantFilterMiddleware: 許可されていないテナントからのアクセスを拒否しました。tenant_id=%s",
                tenant_id,
            )
            # ユーザーには何も返さず、ここで処理を終了する
            return

        # 許可されたテナントなので、後続の bot ロジックを実行
        await logic()
