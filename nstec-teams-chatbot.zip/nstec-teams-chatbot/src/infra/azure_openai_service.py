from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from azure.identity import get_bearer_token_provider
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import Runnable
from langchain_openai import AzureChatOpenAI

from src.config.settings import Settings


@dataclass(frozen=True)
class AiResponse:
    content: str
    response_metadata: dict[str, Any]
    id: str
    usage_metadata: dict[str, Any]


class AzureOpenAIService:
    """Azure OpenAI 呼び出し（LangChain 経由）

    - 認証: azure.identity の credential から token provider を作って AzureChatOpenAI に渡す
    - Prompt: system + history + user input を ChatPromptTemplate で構成
    - 実行: chain.invoke(...) を呼び出す（呼び出し側は to_thread で非同期化）
    """

    def __init__(self, settings: Settings, credential) -> None:
        token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")

        self._deployment = settings.AZURE_OPENAI_DEPLOYMENT
        self._max_tokens = settings.AZURE_OPENAI_MAX_TOKEN
        self._system_prompt = settings.AZURE_OPENAI_SYSTEM_PROMPT

        # LLM (LangChain)
        llm_kwargs = dict(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_deployment=self._deployment,
            azure_ad_token_provider=token_provider,
        )
        if self._max_tokens is not None:
            llm_kwargs["max_tokens"] = self._max_tokens

        self._llm = AzureChatOpenAI(**llm_kwargs)

        # Prompt: system + history + input
        self._prompt = ChatPromptTemplate.from_messages(
            [
                ("system", self._system_prompt),
                MessagesPlaceholder("history"),
                ("human", "{input}"),
            ]
        )

        # Chain: prompt | llm
        self._chain: Runnable = self._prompt | self._llm

    def _to_history_messages(self, history: list[dict[str, str]]) -> list[BaseMessage]:
        """DB の履歴（role/content）を LangChain の messages に変換する。
        想定 role: user / assistant（それ以外は user 扱い）
        """
        lc: list[BaseMessage] = []
        for h in history:
            role = (h.get("role") or "").strip().lower()
            content = h.get("content") or ""
            if role == "assistant":
                lc.append(AIMessage(content=content))
            else:
                lc.append(HumanMessage(content=content))
        return lc

    def chat(self, history: list[dict[str, str]], user_text: str) -> AiResponse:
        """LangChain chain.invoke で実行し、AiResponse に整形して返す（同期）。

        引数:
            history: DB から取得した過去の会話履歴（user / assistant 混在、最大 N 件）
            user_text: 現在のユーザー入力
        """

        lc_history = self._to_history_messages(history)

        # invoke
        result: AIMessage = self._chain.invoke({"history": lc_history, "input": user_text or ""})

        # content
        content = getattr(result, "content", "") or ""

        # metadata / usage
        response_meta = {}
        usage_meta = {}
        run_id = ""

        # LangChain message has response_metadata in .response_metadata (dict) on many integrations
        rm = getattr(result, "response_metadata", None)
        if isinstance(rm, dict):
            response_meta = rm

            # try extract usage
            usage = rm.get("token_usage") or rm.get("usage") or rm.get("usage_metadata")
            if isinstance(usage, dict):
                usage_meta = {
                    "prompt_tokens": usage.get("prompt_tokens"),
                    "completion_tokens": usage.get("completion_tokens"),
                    "total_tokens": usage.get("total_tokens"),
                }

            # sometimes id / model are in response_metadata
            run_id = str(rm.get("id") or rm.get("request_id") or "")

        return AiResponse(
            content=content,
            response_metadata=response_meta,
            id=run_id,
            usage_metadata=usage_meta,
        )
