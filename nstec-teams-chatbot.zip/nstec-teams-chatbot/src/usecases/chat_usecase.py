from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone

from src.common.errors import DbError
from src.common.utils import new_uuid
from src.infra.azure_openai_service import AiResponse, AzureOpenAIService
from src.repositories.audit_repository import AuditRepository
from src.repositories.conversation_repository import ConversationRepository
from src.repositories.status_repository import StatusRepository

logger = logging.getLogger(__name__)

WAITING_MESSAGE = "回答が返ってくるまで、少々お待ちください。"
DB_ERROR_MESSAGE = "データベース処理中に例外が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード：{request_id}"
AI_ERROR_MESSAGE = "AIの処理中に問題が発生しました。しばらくしてから再試行するか、管理者にお問い合わせください。エラーコード：{request_id}"


@dataclass(frozen=True)
class ChatResult:
    message: str


class ChatUsecase:
    def __init__(
        self,
        openai_service: AzureOpenAIService,
        conv_repo: ConversationRepository,
        status_repo: StatusRepository,
        audit_repo: AuditRepository,
        history_limit: int,
        retention_days: int,
        timeout_seconds: int,
    ) -> None:
        self._openai = openai_service
        self._conv_repo = conv_repo
        self._status_repo = status_repo
        self._audit_repo = audit_repo
        self._history_limit = history_limit
        self._retention_days = retention_days
        self._timeout_seconds = timeout_seconds

    async def handle(self, user_id: str, conversation_id: str, user_text: str) -> ChatResult:
        logger.info("******* Teams AI Bot 業務処理 started *******")
        # ③-1 過去履歴クリア：2つのスキーマの期限切れデータを削除する
        # 1. 会話履歴（conversation_history）を削除
        try:
            await self._conv_repo.delete_old_history(user_id, self._retention_days)
        except DbError as ex:
            request_id = new_uuid()
            logger.exception("DB error (delete_old_history) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # 2. AI処理ステータス（ai_processing_status）を削除
        try:
            await self._status_repo.delete_old_status(self._retention_days)
        except DbError as ex:
            request_id = new_uuid()
            logger.exception("DB error (delete_old_status) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-2 AI会話状態抽出
        try:
            status = await self._status_repo.get_by_conversation_id(conversation_id)
            if status is None:
                status = await self._status_repo.create_if_missing(conversation_id)
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (get/create status) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-3 排他制御チェック
        if status.processing_flg == "1":
            # locked_at との差分を秒で評価
            try:
                locked_at = (
                    datetime.fromisoformat(status.locked_at.replace("Z", "+00:00")) if status.locked_at else None
                )
            except ValueError:
                locked_at = None

            if locked_at is not None:
                diff = (datetime.now(timezone.utc) - locked_at).total_seconds()
                if diff <= self._timeout_seconds:
                    return ChatResult(message=WAITING_MESSAGE)

            # timeout 超過 → 会話自体は継続可能とし、ステータスのみ解放して後続処理を継続する
            try:
                await self._status_repo.update_processing_flg(status, "0")
            except DbError:
                request_id = new_uuid()
                logger.exception("DB error (reset status after timeout) request_id=%s", request_id)
                return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))
            # ステータス解放後は、そのまま後続の入力保存・AI 呼び出し処理へ進む

        # ③-4 会話履歴取得（最新のユーザー入力を保存する前時点までの履歴を取得）
        try:
            history = await self._conv_repo.list_recent_history(
                user_id=user_id,
                conversation_id=conversation_id,
                limit=self._history_limit,
            )
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (list history) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-5 ユーザー入力保存（role="user"）
        try:
            await self._conv_repo.insert_message(
                user_id=user_id,
                conversation_id=conversation_id,
                message_id=new_uuid(),
                role="user",
                content=user_text,
            )
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (insert user msg) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-6 AI会話状態ロック（processing_flg="1"）
        try:
            await self._status_repo.update_processing_flg(status, "1")
            # upsert のため locked_at が更新されるので再取得しても良いが、ここでは不要
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (lock status) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-7 AIへ送信&回答取得（ブロッキングI/Oなので thread に逃がす）
        try:
            ai_resp: AiResponse = await asyncio.to_thread(self._openai.chat, history, user_text)
        except Exception:
            request_id = new_uuid()
            logger.exception("AI error request_id=%s", request_id)
            try:
                # AI エラー時も会話を継続可能とするため、ロックを解除しておく
                await self._status_repo.update_processing_flg(status, "0")
            except DbError:
                logger.exception("DB error (unlock status after AI error) request_id=%s", request_id)
                return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))
            return ChatResult(message=AI_ERROR_MESSAGE.format(request_id=request_id))

        # ③-8 ロック解除（processing_flg="0"）
        try:
            await self._status_repo.update_processing_flg(status, "0")
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (unlock status) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-9 AI応答保存（role="assistant"）
        try:
            await self._conv_repo.insert_message(
                user_id=user_id,
                conversation_id=conversation_id,
                message_id=new_uuid(),
                role="assistant",
                content=ai_resp.content,
            )
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (insert assistant msg) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-10 審査ログ保存
        try:
            total_tokens = ai_resp.usage_metadata.get("total_tokens")
            await self._audit_repo.insert_audit(
                user=user_id,
                tokens=total_tokens,
                user_input=user_text,
                response=ai_resp.content,
            )
        except DbError:
            request_id = new_uuid()
            logger.exception("DB error (insert audit) request_id=%s", request_id)
            return ChatResult(message=DB_ERROR_MESSAGE.format(request_id=request_id))

        # ③-11 返却
        logger.info("******* Teams AI Bot 業務処理 finished *******")
        return ChatResult(message=ai_resp.content)
